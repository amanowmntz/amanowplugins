/* AmanowTools CEP — UI glue. Calls host.jsx functions via evalScript. */
(function(){
  var cs = new CSInterface();

  function esc(s){ return String(s).replace(/\\/g,"\\\\").replace(/"/g,'\\"'); }
  function call(expr){ try{ cs.evalScript(expr, function(r){}); }catch(e){} }
  function num(id, def){ var el=document.getElementById(id); var v=parseFloat(String(el?el.value:"").replace(",",".")); return isNaN(v)?def:v; }
  function clamp(v,a,b){ return v<a?a:(v>b?b:v); }

  /* ---- tabs (live query so dynamically-added custom tabs work too) ---- */
  function switchTab(t){
    var tabs=document.querySelectorAll(".tab"), panes=document.querySelectorAll(".tabpane");
    for(var a=0;a<tabs.length;a++) tabs[a].classList.toggle("active", tabs[a].getAttribute("data-tab")===t);
    for(var b=0;b<panes.length;b++) panes[b].classList.toggle("active", panes[b].getAttribute("data-pane")===t);
  }
  function bindTab(el){ el.addEventListener("click", function(){ switchTab(this.getAttribute("data-tab")); }); }
  (function(){ var t0=document.querySelectorAll(".tab"); for(var i=0;i<t0.length;i++) bindTab(t0[i]); })();

  /* ---- anchor 3x3 ---- */
  var grid=document.getElementById("anchorGrid");
  var coords=[[0,0],[0.5,0],[1,0],[0,0.5],[0.5,0.5],[1,0.5],[0,1],[0.5,1],[1,1]];
  for(var c=0;c<9;c++){
    (function(gx,gy){
      var cell=document.createElement("div");
      cell.className="cell"+((gx===0.5&&gy===0.5)?" on":"");
      cell.addEventListener("click", function(){
        var cells=grid.querySelectorAll(".cell");
        for(var k=0;k<cells.length;k++) cells[k].classList.remove("on");
        cell.classList.add("on");
        call('setAnchorGrid('+gx+','+gy+')');
      });
      grid.appendChild(cell);
    })(coords[c][0],coords[c][1]);
  }

  /* ---- ease rows (slider + number + steppers apply ease; shape btn sets key shape) ---- */
  var rows=document.querySelectorAll(".ease-row");
  for(var e=0;e<rows.length;e++){
    (function(row){
      var mode=row.getAttribute("data-mode");
      var sl=row.querySelector(".ease-sl");
      var nm=row.querySelector(".ease-num");
      var up=row.querySelector(".stp.up");
      var dn=row.querySelector(".stp.dn");
      var shape=row.querySelector(".shape");
      function paint(){ sl.style.setProperty("--p", clamp(parseInt(sl.value,10)||0,0,100)+"%"); }
      function applyVal(v){ v=clamp(Math.round(v),0,100); sl.value=v; nm.value=v; paint(); call('applyEase("'+mode+'",'+v+')'); }
      paint();
      sl.addEventListener("input", function(){ nm.value=Math.round(sl.value); paint(); });   // live display
      sl.addEventListener("change", function(){ applyVal(parseInt(sl.value,10)||0); });        // apply on release
      nm.addEventListener("change", function(){ applyVal(parseFloat(String(nm.value).replace(",","."))||0); });
      up.addEventListener("click", function(){ applyVal((parseInt(nm.value,10)||0)+1); });
      dn.addEventListener("click", function(){ applyVal((parseInt(nm.value,10)||0)-1); });
      shape.addEventListener("click", function(){ call('setKeyShape("'+shape.getAttribute("data-shape")+'")'); });
    })(rows[e]);
  }

  /* ---- motion ---- */
  var motBtns=document.querySelectorAll("[data-motion]");
  for(var m=0;m<motBtns.length;m++){
    motBtns[m].addEventListener("click", function(){
      call('applyMotion("'+this.getAttribute("data-motion")+'")');
    });
  }

  /* global Bounce on/off for text animations (default on) */
  var amBounceOn=true;
  (function(){ var cb=document.getElementById("amBounce"); if(cb){ amBounceOn=cb.checked; cb.addEventListener("change", function(){ amBounceOn=cb.checked; }); } })();
  function tuneGalleryBounce(freq,bounce){
    var f=parseFloat(freq), b=parseFloat(bounce);
    if(isNaN(f)) f=2;
    if(isNaN(b)) b=0;
    if(amBounceOn){
      if(Math.abs(f-2)<0.0001) f=3;
      if(Math.abs(b-45)<0.0001) b=60;
      else if(Math.abs(b)<0.0001) b=20;
    }
    return {freq:f,bounce:b};
  }

  /* ---- sequence (Off, Step->keepCount, mode buttons) ---- */
  var seqMode="right";
  var modeBtns=document.querySelectorAll("[data-seqmode]");
  for(var s=0;s<modeBtns.length;s++){
    modeBtns[s].addEventListener("click", function(){
      seqMode=this.getAttribute("data-seqmode");
      for(var k=0;k<modeBtns.length;k++) modeBtns[k].classList.toggle("on", modeBtns[k]===this);
    });
  }
  document.getElementById("seqBtn").addEventListener("click", function(){
    call('sequenceLayers('+num("seqOff",5)+','+num("seqStep",1)+',"'+esc(seqMode)+'")');
  });

  /* ---- CREATE tab ---- */
  function hexToRGB(hex){ hex=String(hex).replace("#",""); 
    var r=parseInt(hex.substr(0,2),16)/255, g=parseInt(hex.substr(2,2),16)/255, b=parseInt(hex.substr(4,2),16)/255;
    return "["+r.toFixed(4)+","+g.toFixed(4)+","+b.toFixed(4)+"]"; }
  var crBtns=document.querySelectorAll("[data-create]");
  for(var q=0;q<crBtns.length;q++){ crBtns[q].addEventListener("click", function(){
    var k=this.getAttribute("data-create");
    if(k==="Solid"){ var sc=document.getElementById("solidColor"); if(sc){ sc.click(); } return; }
    call('quickCreate("'+k+'")');
  }); }
  (function(){
    var sc=document.getElementById("solidColor"); if(!sc) return;
    sc.addEventListener("change", function(){
      var hex=sc.value||"#808080";
      var r=parseInt(hex.substr(1,2),16)/255, g=parseInt(hex.substr(3,2),16)/255, b=parseInt(hex.substr(5,2),16)/255;
      call('createSolidColor('+r.toFixed(4)+','+g.toFixed(4)+','+b.toFixed(4)+')');
    });
  })();
  var boxBtns=document.querySelectorAll("[data-box]");
  for(var bx=0;bx<boxBtns.length;bx++){ boxBtns[bx].addEventListener("click", function(){ call('createTextBox('+(parseInt(this.getAttribute("data-box"),10)||0)+')'); }); }
  var gB=document.getElementById("glassBtn"); if(gB) gB.addEventListener("click", function(){ call('createLiquidGlass()'); });
  var dB=document.getElementById("dottedBtn"); if(dB) dB.addEventListener("click", function(){ call('createDottedBox()'); });
  var hC=document.getElementById("hndCreate"); if(hC) hC.addEventListener("click", function(){
    var sz=num("hndSize",12); var col=hexToRGB(document.getElementById("hndColor").value);
    call('app.beginUndoGroup("AM Handles");createHandles('+sz+','+col+');app.endUndoGroup();');
  });
  var hOn=document.getElementById("hndOn"); if(hOn) hOn.addEventListener("click", function(){
    call('(function(){var c=actComp();if(!c)return;var h=findHandles2(c);if(h){app.beginUndoGroup("On");h.enabled=true;app.endUndoGroup();}})()');
  });
  var hOff=document.getElementById("hndOff"); if(hOff) hOff.addEventListener("click", function(){
    call('(function(){var c=actComp();if(!c)return;var h=findHandles2(c);if(h){app.beginUndoGroup("Off");h.enabled=false;app.endUndoGroup();}})()');
  });


  /* ---- helpers ---- */
  function getv(id){ var el=document.getElementById(id); return el?el.value:""; }

  /* ---- TEXT: generic data-call buttons (animator grid) ---- */
  var dcBtns=document.querySelectorAll("[data-call]");
  for(var d2=0;d2<dcBtns.length;d2++){ dcBtns[d2].addEventListener("click", function(){ call(this.getAttribute("data-call")); }); }

  /* ---- TEXT: counter ---- */
  var ctA=document.getElementById("ctApply");
  if(ctA) ctA.addEventListener("click", function(){
    var S=num("ctS",0), E=num("ctE",100);
    var dur=Math.max(0.05,num("ctDur",1.2)), bl=Math.max(0,num("ctBlur",16)), ea=Math.max(0.1,num("ctEase",2));
    call('ct_apply({startVal:'+S+',endVal:'+E+',duration:'+dur+',blur:'+bl+',easePow:'+ea+',prefix:"'+esc(getv("ctPre"))+'",suffix:"'+esc(getv("ctSuf"))+'"})');
  });

  /* ---- TEXT: letter morph ---- */
  var lmA=document.getElementById("lmApply");
  if(lmA) lmA.addEventListener("click", function(){
    var dir=parseInt(getv("lmDir"),10)||0;
    var dexpr=(dir===3)?"Math.floor(Math.random()*3)":String(dir);
    var dur=Math.max(0.05,num("lmDur",1.2)), bl=Math.max(0,num("lmBlur",12));
    call('lm_apply("'+esc(getv("lmStart"))+'","'+esc(getv("lmEnd"))+'",'+dur+','+bl+','+dexpr+')');
  });


  /* ---- auto numeric steppers (input.step gets up/down buttons) ---- */
  function attachSteppers(){
    var holdTimer=null, holdActive=false, holdFn=null, holdStarted=0;
    function stopHold(){
      holdActive=false; holdFn=null;
      if(holdTimer!==null){ clearTimeout(holdTimer); holdTimer=null; }
    }
    function repeatHold(){
      if(!holdActive||!holdFn) return;
      holdFn();
      var elapsed=Date.now()-holdStarted;
      var delay=elapsed>1600?32:(elapsed>800?48:75);
      holdTimer=setTimeout(repeatHold,delay);
    }
    function startHold(fn,ev){
      stopHold(); holdFn=fn; holdActive=true; holdStarted=Date.now();
      fn(); holdTimer=setTimeout(repeatHold,320);
      if(ev&&ev.preventDefault) ev.preventDefault();
    }
    document.addEventListener("mouseup",stopHold);
    document.addEventListener("touchend",stopHold);
    document.addEventListener("touchcancel",stopHold);
    window.addEventListener("blur",stopHold);
    var ins=document.querySelectorAll("input.step");
    for(var i=0;i<ins.length;i++){
      (function(inp){
        if(inp.parentNode && inp.parentNode.className && inp.parentNode.className.indexOf("numstep")>=0) return;
        var step=parseFloat(inp.getAttribute("data-step")); if(isNaN(step)) step=1;
        var dec=parseInt(inp.getAttribute("data-dec"),10); if(isNaN(dec)) dec=(step<1?1:0);
        var mn=inp.getAttribute("data-min"); mn=(mn===null)?-1e12:parseFloat(mn);
        var mx=inp.getAttribute("data-max"); mx=(mx===null)?1e12:parseFloat(mx);
        var wrap=document.createElement("div"); wrap.className="numstep";
        var w=inp.getAttribute("data-w"); if(w){ wrap.style.width=w+"px"; wrap.style.flex="none"; }
        inp.parentNode.insertBefore(wrap, inp); wrap.appendChild(inp);
        var steps=document.createElement("div"); steps.className="steps";
        var up=document.createElement("button"); up.className="stp up"; up.innerHTML="&#9650;"; up.type="button";
        var dn=document.createElement("button"); dn.className="stp dn"; dn.innerHTML="&#9660;"; dn.type="button";
        steps.appendChild(up); steps.appendChild(dn); wrap.appendChild(steps);
        function cur(){ var v=parseFloat(String(inp.value).replace(",",".")); return isNaN(v)?0:v; }
        function setv(v){ v=Math.min(mx,Math.max(mn,v)); inp.value=(dec>0)?v.toFixed(dec):String(Math.round(v)); try{ inp.dispatchEvent(new Event("change")); }catch(e){} }
        function plus(){ setv(cur()+step); }
        function minus(){ setv(cur()-step); }
        up.addEventListener("mousedown",function(e){ startHold(plus,e); });
        dn.addEventListener("mousedown",function(e){ startHold(minus,e); });
        up.addEventListener("touchstart",function(e){ startHold(plus,e); });
        dn.addEventListener("touchstart",function(e){ startHold(minus,e); });
        up.addEventListener("mouseleave",stopHold);
        dn.addEventListener("mouseleave",stopHold);
        up.addEventListener("keydown",function(e){ if(e.keyCode===13||e.keyCode===32){ plus(); e.preventDefault(); } });
        dn.addEventListener("keydown",function(e){ if(e.keyCode===13||e.keyCode===32){ minus(); e.preventDefault(); } });
      })(ins[i]);
    }
  }
  attachSteppers();

  /* Manual Animation Properties keeps a separate remembered Delay for each
     Based-on type: Words/Lines default to 8; Character modes stay at 2. */
  (function(){
    var based=document.getElementById("an_based"), delay=document.getElementById("an_delay");
    if(!based||!delay) return;
    var remembered=[2,2,8,8], previous=parseInt(based.value,10)||0;
    remembered[previous]=parseFloat(delay.value);
    based.addEventListener("focus",function(){ previous=parseInt(based.value,10)||0; });
    based.addEventListener("change",function(){
      var oldValue=parseFloat(delay.value); if(!isNaN(oldValue)) remembered[previous]=oldValue;
      var next=parseInt(based.value,10)||0;
      delay.value=String(remembered[next]);
      previous=next;
    });
  })();


  /* ---- ANIM tab ---- */
  function callR(expr, cb){ try{ cs.evalScript(expr, function(r){ cb(r); }); }catch(e){ cb(""); } }
  function escS(x){ return String(x).replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\r/g,"").replace(/\n/g,"\\n"); }
  function radio(name){ var els=document.getElementsByName(name); for(var i=0;i<els.length;i++) if(els[i].checked) return els[i].value; return ""; }
  function setRadio(name,val){ var els=document.getElementsByName(name); for(var i=0;i<els.length;i++) els[i].checked=(els[i].value===String(val)); }
  function chk(id){ var el=document.getElementById(id); return !!(el&&el.checked); }
  function setChk(id,b){ var el=document.getElementById(id); if(el) el.checked=!!b; }
  var ANPROPS=[["pos",["x","y","z"]],["anc",["x","y","z"]],["rot",["x","y","z"]],["scl",["x","y"]],["skew",["a","ax"]],["trk",["v"]],["blur",["v"]],["opac",["v"]]];

  function animParamsStr(){
    var based=(parseInt(getv("an_based"),10)||0)+1;
    var dir=parseInt(getv("an_dir"),10)||0;
    var mode=parseInt(radio("an_io"),10)||0;
    var shoot=radio("an_shoot")||"overshoot";
    var bnc=chk("an_bounce_cb")?num("an_bounce",60):0;
    var is3D=chk("an_3d");
    var freq=(mode===2)?2:num("an_freq",2), decay=num("an_decay",7), dur=num("an_dur",1), delay=num("an_delay",2);
    function pr(k,ax){ var on=chk("an_"+k+"_cb"); var v=[]; for(var i=0;i<ax.length;i++) v.push(num("an_"+k+"_"+ax[i],0)); return "{on:"+on+",v:["+v.join(",")+"]}"; }
    return "{based:"+based+",dir:"+dir+",mode:"+mode+",engine:\""+anEngine+"\",shoot:\""+shoot+"\",bounce:{on:"+(bnc>0)+",v:"+bnc+"},overshoot:"+(shoot==="overshoot")+",is3D:"+is3D+
      ",freq:"+freq+",decay:"+decay+",dur:"+dur+",delay:"+delay+
      ",pos:"+pr("pos",["x","y","z"])+",anc:"+pr("anc",["x","y","z"])+",rot:"+pr("rot",["x","y","z"])+
      ",scl:"+pr("scl",["x","y"])+",skew:"+pr("skew",["a","ax"])+",trk:"+pr("trk",["v"])+",blur:{on:"+chk("an_blur_cb")+",v:["+num("an_blur_v",0)+"],dur:"+num("an_blur_dur",0.5)+"},opac:{on:"+chk("an_opac_cb")+",v:["+num("an_opac_v",0)+"],dur:"+num("an_opac_dur",0.5)+"}}";
  }
  var anEngine="expr";
  (function(){
    var ex=document.getElementById("an_eng_expr"), kf=document.getElementById("an_eng_kfrm");
    function setEng(v){ anEngine=v; if(ex) ex.classList.toggle("active", v==="expr"); if(kf) kf.classList.toggle("active", v==="kfrm"); }
    if(ex) ex.addEventListener("click", function(){ setEng("expr"); });
    if(kf) kf.addEventListener("click", function(){ setEng("kfrm"); });
  })();
  var anHelp=document.getElementById("an_help");
  if(anHelp) anHelp.addEventListener("click", function(){
    window.alert("AmanowText\n\nAnimation Properties: Based on, Direction, Frequency, Decay, Duration, Delay, Bounce.\nIn / In/Out / Out chooses the phase.\nEXPR = live expression, editable in Effect Controls (AM Frequency / Decay / Duration / Delay / Bounce). TR In marks the exact end of the entrance; TR Out marks the exact start of the exit.\nKFRM = only the required baked keyframes; it does not create TR markers.\nEnable Position / Scale / Blur / Opacity, then press Animate.");
  });
  var anA=document.getElementById("an_apply");
  if(anA) anA.addEventListener("click", function(){ call('applyAnimCEP('+animParamsStr()+')'); });

  function gatherAnim(){
    var L=[];
    L.push("based="+(parseInt(getv("an_based"),10)||0));
    L.push("dir="+(parseInt(getv("an_dir"),10)||0));
    L.push("freq="+num("an_freq",2)); L.push("decay="+num("an_decay",7)); L.push("dur="+num("an_dur",1)); L.push("delay="+num("an_delay",2)); L.push("bounce="+num("an_bounce",60)); L.push("bounceOn="+(chk("an_bounce_cb")?1:0));
    L.push("io="+(parseInt(radio("an_io"),10)||0));
    L.push("engine="+anEngine); L.push("d3="+(chk("an_3d")?1:0)); L.push("shoot="+(radio("an_shoot")||"overshoot"));
    for(var i=0;i<ANPROPS.length;i++){ var k=ANPROPS[i][0],ax=ANPROPS[i][1]; var v=[chk("an_"+k+"_cb")?1:0]; for(var j=0;j<ax.length;j++) v.push(num("an_"+k+"_"+ax[j],0)); L.push(k+"="+v.join(",")); }
    return L.join("\n");
  }
  function applyAnimMap(txt){
    var map={}; var lines=String(txt).split(/\r?\n/);
    for(var i=0;i<lines.length;i++){ var eq=lines[i].indexOf("="); if(eq>0) map[lines[i].substr(0,eq)]=lines[i].substr(eq+1); }
    function setSel(id,v){ var el=document.getElementById(id); if(el&&v!==undefined) el.value=String(parseInt(v,10)||0); }
    function setIn(id,v){ var el=document.getElementById(id); if(el&&v!==undefined) el.value=v; }
    setSel("an_based",map.based); setSel("an_dir",map.dir);
    setIn("an_freq",map.freq); setIn("an_decay",map.decay); setIn("an_dur",map.dur); setIn("an_delay",map.delay); setIn("an_bounce",(map.bounce!==undefined?map.bounce:"60"));
    setChk("an_bounce_cb",map.bounceOn!=="0");
    if(map.engine){ anEngine=(map.engine==="kfrm")?"kfrm":"expr"; var _ex=document.getElementById("an_eng_expr"),_kf=document.getElementById("an_eng_kfrm"); if(_ex)_ex.classList.toggle("active",anEngine==="expr"); if(_kf)_kf.classList.toggle("active",anEngine==="kfrm"); }
    setRadio("an_io", (map.io!==undefined)?String(parseInt(map.io,10)||0):"0");
    setChk("an_3d", map.d3==="1");
    var sh=map.shoot; if(sh==="1")sh="overshoot"; else if(sh==="0")sh="normal"; if(!sh)sh="overshoot"; setRadio("an_shoot", sh);
    for(var i=0;i<ANPROPS.length;i++){ var k=ANPROPS[i][0],ax=ANPROPS[i][1]; if(map[k]!==undefined){ var parts=map[k].split(","); setChk("an_"+k+"_cb", parts[0]==="1"); for(var j=0;j<ax.length;j++){ if(parts[j+1]!==undefined) setIn("an_"+k+"_"+ax[j], parts[j+1]); } } }
  }
  function animRefresh(){ callR('animPresetList()', function(r){ var sel=document.getElementById("an_preset"); if(!sel) return; sel.innerHTML=""; var names=String(r||"").split(/\r?\n/); for(var i=0;i<names.length;i++){ if(names[i]){ var o=document.createElement("option"); o.value=names[i]; o.textContent=names[i]; sel.appendChild(o); } } }); }
  var anSave=document.getElementById("an_save");
  if(anSave) anSave.addEventListener("click", function(){ var nm=window.prompt("Preset name:",""); if(!nm) return; callR('animPresetSave("'+escS(nm)+'","'+escS(gatherAnim())+'")', function(r){ animRefresh(); }); });
  var anLoad=document.getElementById("an_load");
  if(anLoad) anLoad.addEventListener("click", function(){ var sel=document.getElementById("an_preset"); var nm=sel&&sel.value; if(!nm) return; callR('animPresetLoad("'+escS(nm)+'")', function(r){ if(r) applyAnimMap(r); }); });
  var anDel=document.getElementById("an_del");
  if(anDel) anDel.addEventListener("click", function(){ var sel=document.getElementById("an_preset"); var nm=sel&&sel.value; if(!nm) return; callR('animPresetDelete("'+escS(nm)+'")', function(r){ animRefresh(); }); });
  var anRef=document.getElementById("an_refresh");
  if(anRef) anRef.addEventListener("click", function(){ call('am_resetAnim()'); });
  animRefresh();


  /* ================= ANIMATION GALLERY ================= */
  var SAMPLE="AMANOW TOOLS ANIMATION";
  var N="cubic-bezier(.22,.78,.28,1)",B="cubic-bezier(.34,1.56,.64,1)",S="cubic-bezier(.25,.66,.3,1)",BO="cubic-bezier(.28,1.5,.5,1.04)",EL="cubic-bezier(.5,1.72,.4,1)";
  var SPB={freq:2.2,decay:1.7}, SPE={freq:3.2,decay:1.4};

  // each type: [name, previewKeyframe, ease, props, opts?]  (opts: is3D, dir, stagger, freq, decay)
  var T_TYPES=[
   ["Position Down Overshoot","pv-su",B,{opac:0,pos:[0,95,0]}],
   ["Position Up Overshoot","pv-sd",B,{opac:0,pos:[0,-95,0]}],
   ["Position Left Overshoot","pv-sl",B,{opac:0,pos:[120,0,0]}],
   ["Position Right Overshoot","pv-sr",B,{opac:0,pos:[-120,0,0]}],
   ["Scale In Pop","pv-pop",B,{opac:0,scl:[0,0]}],
   ["Scale Out Compress","pv-scaledn",N,{opac:0,scl:[200,200]}],
   ["Scale X Reveal","pv-scalex",B,{opac:0,scl:[0,100]}],
   ["Scale Y Reveal","pv-scaley",B,{opac:0,scl:[100,0]}],
   ["Rotate Z Basic","pv-rot",N,{opac:0,rot:[0,0,50]}],
   ["Position Scale Reveal","pv-risescale",N,{opac:0,pos:[0,60,0],scl:[40,40]},{freq:2.5,decay:5.1,dur:1,delay:7,bounce:0}],
   ["Rotate X Flip","pv-flipx",B,{opac:0,rot:[90,0,0]},{is3D:true}],
   ["Rotate Y Flip","pv-flipy",B,{opac:0,rot:[0,90,0]},{is3D:true}],
   ["Fade Sequential","pv-fade",N,{opac:0},{stagger:0.12,noBounce:true,decay:4,delay:4}],
   ["Fade Blur","pv-blur",N,{opac:0,blur:30},{stagger:0.1,noBounce:true,decay:4,delay:4}],
   ["Fade Dark To Bright","pv-fadedim",N,{opac:25},{stagger:0.12,noBounce:true,decay:4,delay:4}],
   ["Fade Random Order","pv-fade",N,{opac:0},{dir:4,stagger:0.08,noBounce:true,decay:4,delay:4}]
  ];
  var TEXT_ANIMS=(function(){
    var out=[]; var bn={1:"Letters",2:"Character",3:"Words",4:"Lines"};
    function catGroup(n){ if(/Position/.test(n))return "Position"; if(/Scale/.test(n))return "Scale"; if(/Rotate/.test(n))return "Rotation"; return "Fade"; }
    function grp(based,gran){ T_TYPES.forEach(function(r){
      var o=r[4]||{};
      out.push({id:"t_"+out.length, name:bn[based]+" \u2022 "+r[0], cat:"Text / "+bn[based]+" / "+catGroup(r[0]),
        anim:r[1], ease:r[2], gran:gran, based:based, props:r[3],
        is3D:!!o.is3D, dir:(o.dir||0), stagger:o.stagger,
        shoot:(/Bounce/.test(r[0])?"bounce":/Overshoot|Pop/.test(r[0])?"overshoot":"normal"),
        freq:o.freq, decay:o.decay, dur:o.dur, delay:o.delay, bounce:o.bounce, noBounce:!!o.noBounce});
    });}
    grp(3,"word"); grp(4,"line"); grp(2,"char");
    return out;
  })();

  var SHAPE_ANIMS=(function(){
    var out=[]; var D=320;
    function add(name,anim,ease,cfg,group){ out.push({id:"s_"+out.length,name:name,cat:"Shape / "+group,anim:anim,ease:ease,cfg:cfg,group:group}); }
    var dirs=[["Down",0,-D,"pv-down"],["Up",0,D,"pv-up"],["Left",D,0,"pv-left"],["Right",-D,0,"pv-right"]];
    dirs.forEach(function(d){ add("Bounce \u2022 "+d[0], d[3], BO, {dx:d[1],dy:d[2],fade:true,variant:"bounce"}, "position"); });
    add("Rotate X","pv-flipx",N,{rotX:90,fade:true,variant:"normal"},"rotate");
    add("Rotate Y","pv-flipy",N,{rotY:90,fade:true,variant:"normal"},"rotate");
    add("Rotate XY","pv-flipxy",N,{rotX:75,rotY:75,fade:true,variant:"normal"},"rotate");
    add("Scale In","pv-scale",N,{sx:0,sy:0,fade:true,variant:"normal"},"scale");
    add("Scale Out","pv-scaledn",N,{sx:200,sy:200,fade:true,variant:"normal"},"scale");
    add("Scale X","pv-scalex",N,{sx:0,sy:100,fade:true,variant:"normal"},"scale");
    add("Scale Y","pv-scaley",N,{sx:100,sy:0,fade:true,variant:"normal"},"scale");
    return out;
  })();

  var anSub="text", curItem=null, curTile=null, textGroup="all", shapeGroup="all";
  function favGet(){ try{ return JSON.parse(localStorage.getItem("amanow_fav")||"[]"); }catch(e){ return []; } }
  function favSet(a){ try{ localStorage.setItem("amanow_fav", JSON.stringify(a)); }catch(e){} }
  function favHas(id){ var f=favGet(); for(var i=0;i<f.length;i++) if(f[i]===id) return true; return false; }
  function favToggle(id){ var f=favGet(), i=f.indexOf(id); if(i>=0) f.splice(i,1); else f.push(id); favSet(f); }

  function buildTextParams(c, mode){
    var pr=c.props||{};
    var sh=(c.shoot||"normal"), ov=!!c.overshoot;
    var baseFreq=(c.freq!==undefined)?c.freq:2;
    var baseBounce=(c.bounce!==undefined)?c.bounce:(sh==="bounce"?60:sh==="overshoot"?30:sh==="elastic"?45:0);
    /* A dedicated Out animation always uses the non-enhanced Bounce values
       and Frequency 2, regardless of the gallery Bounce switch. */
    var isOutMode=(mode===2||mode==="2");
    var tuned=c.noBounce?{freq:(isOutMode?2:baseFreq),bounce:0}:(isOutMode?{freq:2,bounce:baseBounce}:tuneGalleryBounce(baseFreq,baseBounce));
    var based=(c.based||1), isWord=(based===3), isLine=(based===4), isChar=(based===2);
    var baseDur=(c.dur!==undefined?c.dur:0.8);
    var baseDelay=((isWord||isLine)?8:(c.delay!==undefined?c.delay:2));
    var durIn=baseDur, durOut=baseDur, delayIn=baseDelay, delayOut=baseDelay;
    var opacIn=0.5, opacOut=0.5, blurIn=0.5, blurOut=0.5;
    /* The four Fade presets in Words/Lines intentionally retain the v1.16
       values. Every other preset uses the new phase-specific defaults. */
    var preserveWordLineFade=!!c.noBounce&&(isWord||isLine);
    if(!preserveWordLineFade){
      if(isWord){ opacIn=0.3; opacOut=0.1; delayIn=6; delayOut=4; durOut=0.6; }
      else if(isLine){ opacIn=0.3; opacOut=0.1; delayIn=8; delayOut=4; durOut=0.6; }
      else if(isChar){ opacIn=0.1; opacOut=0.1; durOut=0.6; }
    }
    if(isChar&&pr.blur!==undefined){ blurIn=0.3; blurOut=0.3; }
    var selectedDur=isOutMode?durOut:durIn;
    var selectedDelay=isOutMode?delayOut:delayIn;
    var o={
      based:based, dir:(c.dir||0), mode:mode, shoot:sh, overshoot:ov, markers:false, is3D:!!c.is3D,
      freq:tuned.freq, decay:(c.decay!==undefined?c.decay:5), dur:selectedDur, durIn:durIn, durOut:durOut,
      delay:selectedDelay, delayIn:delayIn, delayOut:delayOut, amp:(c.amp!==undefined?c.amp:100),
      bounce:{on:tuned.bounce>0,v:tuned.bounce},
      pos:{on:!!pr.pos,v:pr.pos||[0,0,0]}, anc:{on:false,v:[0,0,0]}, rot:{on:!!pr.rot,v:pr.rot||[0,0,0]},
      scl:{on:!!pr.scl,v:pr.scl?[pr.scl[0]-100,pr.scl[1]-100]:[0,0]}, skew:{on:!!pr.skew,v:pr.skew||[0,0]},
      trk:{on:(pr.trk!==undefined),v:[pr.trk||0]},
      blur:{on:(pr.blur!==undefined),v:[pr.blur||0],dur:(isOutMode?blurOut:blurIn),inDur:blurIn,outDur:blurOut},
      opac:{on:(pr.opac!==undefined),v:[pr.opac||0],dur:(isOutMode?opacOut:opacIn),inDur:opacIn,outDur:opacOut}
    };
    return o;
  }
  function applyMode(mode){
    if(!curItem) return; var mmap={in:0,both:1,out:2};
    if(curItem.cfg){ var shapeCfg={}; for(var k in curItem.cfg){ if(curItem.cfg.hasOwnProperty(k)) shapeCfg[k]=curItem.cfg[k]; } call('shapeAnimCEP('+JSON.stringify(shapeCfg)+',"'+mode+'",1,75)'); }
    else { call('applyAnimCEP('+JSON.stringify(buildTextParams(curItem, mmap[mode]))+')'); }
  }
  var animateBar=document.getElementById("animateBar"), abName=document.getElementById("abName");
  function pvUnitsFor(gran){
    if(gran==="line") return [["AMANOW TOOLS"],["ANIMATION"]];
    if(gran==="word") return [["AMANOW","TOOLS"],["ANIMATION"]];
    return [["A","M","A","N","O","W"," ","T","O","O","L","S"],["A","N","I","M","A","T","I","O","N"]];
  }
  function buildPreview(item){
    var stage=document.getElementById("animPreview"); if(!stage) return;
    stage.innerHTML="";
    if(!item){ var idle=document.createElement("div"); idle.className="pv-idle"; idle.textContent="Select an animation to preview"; stage.appendChild(idle); return; }
    var anim=item.anim||"pv-fade", ease=item.ease||N;
    if(item.cfg){ /* shape preset -> animate a rounded box */
      var box=document.createElement("div"); box.className="pv-shape";
      box.style.setProperty("--anim",anim); box.style.setProperty("--ease",ease); box.style.setProperty("--d","0s");
      stage.appendChild(box); return;
    }
    var gran=item.gran||"char";
    var lines=pvUnitsFor(gran);
    var stg=item.stagger||(gran==="char"?0.05:gran==="word"?0.1:0.16);
    var flat=[]; for(var li=0;li<lines.length;li++){ for(var ui=0;ui<lines[li].length;ui++) flat.push(1); }
    var order=[]; for(var oi=0;oi<flat.length;oi++) order.push(oi);
    if(item.dir===4){ for(var s=order.length-1;s>0;s--){ var rr=Math.floor(Math.random()*(s+1)); var tm=order[s]; order[s]=order[rr]; order[rr]=tm; } }
    else if(item.dir===1){ order.reverse(); }
    var slotOf={}; for(var q=0;q<order.length;q++) slotOf[order[q]]=q;
    var idx=0;
    for(var l=0;l<lines.length;l++){
      var row=document.createElement("div"); row.className="pv-row";
      for(var u=0;u<lines[l].length;u++){
        var txt=lines[l][u];
        var el=document.createElement("span"); el.className="ch";
        el.innerHTML=(txt===" ")?"&nbsp;":txt;
        if(txt!==" "){ el.style.setProperty("--anim",anim); el.style.setProperty("--ease",ease); el.style.setProperty("--d",(slotOf[idx]*stg).toFixed(2)+"s"); }
        else { el.className="ch pv-sp"; }
        row.appendChild(el);
        if(gran==="word" && u<lines[l].length-1){ var sp=document.createElement("span"); sp.className="ch pv-sp"; sp.innerHTML="&nbsp;"; row.appendChild(sp); }
        idx++;
      }
      stage.appendChild(row);
    }
  }

  function showBar(item, tileEl){
    curItem=item; if(curTile) curTile.classList.remove("sel"); curTile=tileEl; if(curTile) curTile.classList.add("sel");
    if(abName) abName.textContent=item.name; if(animateBar) animateBar.classList.add("show");
    buildPreview(item);
  }
  function hideBar(){ curItem=null; if(curTile){curTile.classList.remove("sel");curTile=null;} if(animateBar) animateBar.classList.remove("show"); }

  function buildSample(item){
    var wrap=document.createElement("div"); wrap.className="sample"+(item.gran==="line"?" lines":"")+(item.container?" cont":"");
    var stg=item.stagger||(item.gran==="ch"?0.045:item.gran==="word"?0.09:0.14);
    var units = item.gran==="word"?SAMPLE.split(" ") : item.gran==="line"?["AMANOW TOOLS","ANIMATION"] : SAMPLE.split("");
    var rand=(item.dir===4);
    var order=[]; for(var oi=0;oi<units.length;oi++) order.push(oi);
    if(rand){ for(var s=units.length-1;s>0;s--){ var rr=Math.floor(Math.random()*(s+1)); var tm=order[s]; order[s]=order[rr]; order[rr]=tm; } }
    var k=0;
    for(var i=0;i<units.length;i++){
      var u=units[i], el=document.createElement(item.gran==="line"?"div":"span"); el.className="ch";
      var slot=rand?order[i]:k;
      el.innerHTML=(u===" ")?"&nbsp;":u; el.style.setProperty("--d",(slot*stg).toFixed(2)+"s"); k++; wrap.appendChild(el);
      if(item.gran==="word" && i<units.length-1){ var sp=document.createElement("span"); sp.innerHTML="&nbsp;"; wrap.appendChild(sp); }
    }
    return wrap;
  }
  function buildIcon(item){
    var isShape=!!item.cfg;
    var n=" "+String(item.name).toLowerCase()+" ";
    function motionOf(s){
      if(/position scale|scale reveal/.test(s)) return "pop";
      if(/scale x/.test(s)) return "scalex";
      if(/scale y/.test(s)) return "scaley";
      if(/compress|scale out/.test(s)) return "compress";
      if(/scale in|in pop/.test(s)) return "pop";
      if(/rotate xy/.test(s)) return "rotate";
      if(/rotate x|spin x|x flip|x fast|x long/.test(s)) return "flipx";
      if(/rotate y|spin y|y flip|y fast|y long/.test(s)) return "flipy";
      if(/rotate|spin/.test(s)) return "rotate";
      if(/fade/.test(s)) return "fade";
      if(/down/.test(s)) return "down";
      if(/ up /.test(s)) return "up";
      if(/left/.test(s)) return "left";
      if(/right/.test(s)) return "right";
      return "rotate";
    }
    var m=motionOf(n);
    var AC="var(--accent,#3b82f6)", AR="#9aa6b6";
    var glyph;
    if(isShape){
      glyph='<rect x="33" y="18" width="22" height="18" rx="4" fill="none" stroke="'+AC+'" stroke-width="3.2"/>';
    } else if(item.gran==="line"){
      glyph='<g fill="'+AC+'"><rect x="30" y="20" width="28" height="4.6" rx="2.3"/><rect x="30" y="27" width="28" height="4.6" rx="2.3"/><rect x="30" y="34" width="20" height="4.6" rx="2.3"/></g>';
    } else {
      var letter = item.gran==="word"?"W" : (item.based===2?"C":"L");
      glyph='<text x="44" y="38" text-anchor="middle" font-family="Arial,Helvetica,sans-serif" font-size="27" font-weight="800" fill="'+AC+'">'+letter+'</text>';
    }
    var ah='stroke="'+AR+'" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" fill="none"';
    var ov="";
    if(m==="down") ov='<path '+ah+' d="M44 6 V18 M44 18 L40 14 M44 18 L48 14"/>';
    else if(m==="up") ov='<path '+ah+' d="M44 18 V6 M44 6 L40 10 M44 6 L48 10"/>';
    else if(m==="left") ov='<path '+ah+' d="M58 10 H30 M30 10 L35 6 M30 10 L35 14"/>';
    else if(m==="right") ov='<path '+ah+' d="M30 10 H58 M58 10 L53 6 M58 10 L53 14"/>';
    else if(m==="pop") ov='<path '+ah+' d="M31 21 L21 11 M21 11 H27 M21 11 V17 M57 21 L67 11 M67 11 H61 M67 11 V17 M31 33 L21 43 M21 43 H27 M21 43 V37 M57 33 L67 43 M67 43 H61 M67 43 V37"/>';
    else if(m==="compress") ov='<path '+ah+' d="M15 27 H29 M29 27 L25 23 M29 27 L25 31 M73 27 H59 M59 27 L63 23 M59 27 L63 31"/>';
    else if(m==="scalex") ov='<path '+ah+' d="M27 11 H61 M27 11 L32 7 M27 11 L32 15 M61 11 L56 7 M61 11 L56 15"/>';
    else if(m==="scaley") ov='<path '+ah+' d="M44 17 V5 M44 5 L40 9 M44 5 L48 9 M44 35 V47 M44 47 L40 43 M44 47 L48 43"/>';
    else if(m==="rotate") ov='<path '+ah+' d="M56 13 A20 20 0 1 1 44 7"/><path '+ah+' d="M44 7 L49 5 M44 7 L48 11"/>';
    else if(m==="flipx") ov='<path stroke="'+AR+'" stroke-width="1.5" stroke-dasharray="3 3" fill="none" d="M16 27 H72"/><path '+ah+' d="M30 27 C30 14 58 14 58 27 M58 27 L54 23 M58 27 L62 23"/>';
    else if(m==="flipy") ov='<path stroke="'+AR+'" stroke-width="1.5" stroke-dasharray="3 3" fill="none" d="M44 7 V47"/><path '+ah+' d="M44 15 C58 15 58 39 44 39 M44 39 L48 35 M44 39 L48 43"/>';
    else if(m==="fade") ov='<g fill="'+AR+'"><circle cx="13" cy="44" r="1.7" opacity="0.3"/><circle cx="19" cy="44" r="1.7" opacity="0.6"/><circle cx="25" cy="44" r="1.7" opacity="0.95"/></g>';
    return '<svg viewBox="0 0 88 52" xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" preserveAspectRatio="xMidYMid meet">'+glyph+ov+'</svg>';
  }
  function makeTile(item){
    var t=document.createElement("div"); t.className="tile";
    var star=document.createElement("div"); star.className="star"+(favHas(item.id)?" on":""); star.innerHTML="&#9733;";
    star.addEventListener("click", function(ev){ ev.stopPropagation(); favToggle(item.id); star.classList.toggle("on"); if(anSub==="fav") renderGallery(); });
    t.appendChild(star);
    var delx=document.createElement("div"); delx.className="del-x"; delx.innerHTML="&#10005;"; delx.title="Hide";
    delx.addEventListener("click", function(ev){ ev.stopPropagation(); hideItem(item.id); });
    t.appendChild(delx);
    var prev=document.createElement("div"); prev.className="tile-prev tile-icon";
    prev.innerHTML=buildIcon(item);
    t.appendChild(prev);
    t.title=item.name;
    t.addEventListener("click", function(){ showBar(item, t); });
    return t;
  }
  function renderGallery(){
    hideBar();
    var g=document.getElementById("gallery"); if(!g) return; g.innerHTML="";
    var list;
    if(anSub==="text") list=TEXT_ANIMS.slice();
    else if(anSub==="shape") list=SHAPE_ANIMS.slice();
    else { var all=TEXT_ANIMS.concat(SHAPE_ANIMS); list=[]; for(var i=0;i<all.length;i++) if(favHas(all[i].id)) list.push(all[i]); }
    list=list.filter(function(a){ return !isHidden(a.id); });
    if(anSub==="text" && textGroup!=="all"){ list=list.filter(function(a){ return String(a.based)===String(textGroup); }); }
    if(anSub==="shape" && shapeGroup!=="all"){ list=list.filter(function(a){ return a.group===shapeGroup; }); }
    if(list.length===0){ var e=document.createElement("div"); e.className="empty"; e.textContent=(anSub==="fav")?"No favorites yet. Tap \u2605 on an animation.":"Empty."; g.appendChild(e); return; }
    for(var j=0;j<list.length;j++) g.appendChild(makeTile(list[j]));
  }
  var subBtns=document.querySelectorAll(".subtab");
  function syncGroupRows(){
    var tg=document.getElementById("textGroups"), sg=document.getElementById("shapeGroups");
    if(tg) tg.style.display=(anSub==="text")?"flex":"none";
    if(sg) sg.style.display=(anSub==="shape")?"flex":"none";
  }
  for(var su=0;su<subBtns.length;su++){ subBtns[su].addEventListener("click", function(){
    anSub=this.getAttribute("data-sub");
    for(var a=0;a<subBtns.length;a++) subBtns[a].classList.toggle("active", subBtns[a]===this);
    syncGroupRows(); renderGallery(); }); }
  syncGroupRows();
  var tgChips=document.querySelectorAll("[data-tg]");
  for(var tgi=0;tgi<tgChips.length;tgi++){ tgChips[tgi].addEventListener("click", function(){
    textGroup=this.getAttribute("data-tg");
    for(var a=0;a<tgChips.length;a++) tgChips[a].classList.toggle("active", tgChips[a]===this); renderGallery(); }); }
  var sgChips=document.querySelectorAll("[data-sg]");
  for(var sgi=0;sgi<sgChips.length;sgi++){ sgChips[sgi].addEventListener("click", function(){
    shapeGroup=this.getAttribute("data-sg");
    for(var a=0;a<sgChips.length;a++) sgChips[a].classList.toggle("active", sgChips[a]===this); renderGallery(); }); }
  /* ---- Layer Color: dynamic, user-editable palette ---- */
  (function(){
    var rowEl=document.getElementById("swatchRow"); if(!rowEl) return;
    var picker=document.getElementById("swatchColor");
    var DEFAULTS=[
      {c:"#e94b4b",t:"Red"},{c:"#e6c84f",t:"Yellow"},{c:"#6bc8c8",t:"Aqua"},{c:"#e791c5",t:"Pink"},
      {c:"#aaa0e6",t:"Lavender"},{c:"#eba178",t:"Peach"},{c:"#7ac49e",t:"Sea Foam"},{c:"#5a84e4",t:"Blue"},
      {c:"#5fab5f",t:"Green"},{c:"#a05ac8",t:"Purple"},{c:"#e18c3c",t:"Orange"},{c:"#966646",t:"Brown"},
      {c:"#d854b4",t:"Fuchsia"},{c:"#50aac8",t:"Cyan"},{c:"#c8af82",t:"Sandstone"},{c:"#3c7850",t:"Dark Green"}
    ];
    function toRGB(hex){ hex=String(hex).replace("#",""); if(hex.length===3) hex=hex.charAt(0)+hex.charAt(0)+hex.charAt(1)+hex.charAt(1)+hex.charAt(2)+hex.charAt(2);
      return [parseInt(hex.substr(0,2),16)||0,parseInt(hex.substr(2,2),16)||0,parseInt(hex.substr(4,2),16)||0]; }
    function nearestLabel(hex){ var c=toRGB(hex),best=1,bd=1e12; for(var i=0;i<DEFAULTS.length;i++){ var d=toRGB(DEFAULTS[i].c),
      dd=(c[0]-d[0])*(c[0]-d[0])+(c[1]-d[1])*(c[1]-d[1])+(c[2]-d[2])*(c[2]-d[2]); if(dd<bd){ bd=dd; best=i+1; } } return best; }
    function swGet(){ try{ var s=localStorage.getItem("amanow_swatches"); if(s){ var a=JSON.parse(s); if(a&&a.length) return a; } }catch(e){}
      var def=[]; for(var i=0;i<DEFAULTS.length;i++) def.push({c:DEFAULTS[i].c,t:DEFAULTS[i].t,label:i+1}); return def; }
    function swSet(a){ try{ localStorage.setItem("amanow_swatches", JSON.stringify(a)); }catch(e){} }
    function render(){
      var a=swGet(); rowEl.innerHTML="";
      for(var i=0;i<a.length;i++){ (function(sw, idx){
        var b=document.createElement("button"); b.className="swatch"; b.style.setProperty("--c", sw.c); b.title=sw.t||sw.c;
        b.addEventListener("click", function(){ call('setLayerColor('+(parseInt(sw.label,10)||0)+')'); });
        b.addEventListener("contextmenu", function(ev){ ev.preventDefault(); var arr=swGet(); arr.splice(idx,1); swSet(arr); render(); });
        rowEl.appendChild(b);
      })(a[i], i); }
      var add=document.createElement("button"); add.className="swatch swatch-add"; add.title="Add a custom color"; add.innerHTML="+";
      add.addEventListener("click", function(){ if(picker) picker.click(); });
      rowEl.appendChild(add);
    }
    if(picker) picker.addEventListener("change", function(){
      var hex=picker.value||"#5a84e4"; var a=swGet(); a.push({c:hex, t:"Custom "+hex.toUpperCase(), label:nearestLabel(hex)}); swSet(a); render();
    });
    render();
  })();
  var abBtns=document.querySelectorAll(".ab-btn");
  for(var ab=0;ab<abBtns.length;ab++){ abBtns[ab].addEventListener("click", function(){ applyMode(this.getAttribute("data-anmode")); }); }
  var abClose=document.getElementById("abClose"); if(abClose) abClose.addEventListener("click", hideBar);
  var animReset=document.getElementById("animReset");
  if(animReset) animReset.addEventListener("click", function(){ call('am_resetAnim()'); });
  var tileSize=document.getElementById("tileSize");
  if(tileSize){ var g0=document.getElementById("gallery");
    function applyCols(){ if(g0) g0.style.setProperty("--cols", tileSize.value); }
    tileSize.addEventListener("input", applyCols); applyCols();
  }
  renderGallery();

  /* Keep the editable Duration sliders and TR markers in lockstep. ExtendScript
     cannot observe a marker drag by itself, so the CEP panel performs a light,
     serialized sync while it is open. */
  (function(){
    var durationSyncBusy=false, durationSyncStopped=false;
    function syncDurations(){
      if(durationSyncBusy||durationSyncStopped) return;
      durationSyncBusy=true;
      callR("am_syncDurationControls()", function(){ durationSyncBusy=false; });
    }
    var durationSyncTimer=setInterval(syncDurations,400);
    setTimeout(syncDurations,120);
    window.addEventListener("beforeunload",function(){
      durationSyncStopped=true;
      clearInterval(durationSyncTimer);
    });
  })();

  /* ===== links + edit / hide / restore ===== */
  function openURL(u){
    try{ if(window.cep&&window.cep.util&&window.cep.util.openURLInDefaultBrowser){ window.cep.util.openURLInDefaultBrowser(u); return; } }catch(e){}
    try{ if(typeof require==="function"){ var c=require("cep"); if(c&&c.util&&c.util.openURLInDefaultBrowser){ c.util.openURLInDefaultBrowser(u); return; } } }catch(e2){}
    try{ window.open(u,"_blank"); }catch(e3){}
  }
  var TG_URL="https://t.me/amanow_abd",
      IG_URL="https://www.instagram.com/amanow.abd?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==";
  var elTg=document.getElementById("icoTg"); if(elTg) elTg.addEventListener("click",function(){ openURL(TG_URL); });
  var elKey=document.getElementById("icoKey"); if(elKey) elKey.addEventListener("click", function(){ am_openGate(); });
  var elLater=document.getElementById("licLater"); if(elLater) elLater.addEventListener("click", function(){ am_unlock(); });
  var elIg=document.getElementById("icoIg"); if(elIg) elIg.addEventListener("click",function(){ openURL(IG_URL); });

  function hidGet(){ try{ return JSON.parse(localStorage.getItem("amanow_hidden")||"[]"); }catch(e){ return []; } }
  function hidSet(a){ try{ localStorage.setItem("amanow_hidden", JSON.stringify(a)); }catch(e){} }
  function isHidden(id){ var h=hidGet(); for(var i=0;i<h.length;i++) if(h[i]===id) return true; return false; }
  function hideItem(id){ var h=hidGet(); if(h.indexOf(id)<0){ h.push(id); hidSet(h); } applyHidden(); renderGallery(); }
  function restoreItem(id){ var h=hidGet(), i=h.indexOf(id); if(i>=0){ h.splice(i,1); hidSet(h); } applyHidden(); applyTabHidden(); if(window.amApplyDock) window.amApplyDock(); renderGallery(); buildRestore(); }

  var SECMAP={};
  (function(){
    var secs=document.querySelectorAll(".section");
    for(var i=0;i<secs.length;i++){
      var sec=secs[i], tt=sec.querySelector(".section-title");
      var nm=tt?tt.textContent.replace(/\s+/g," ").trim():("Section "+(i+1));
      var id="sec_"+i; sec.setAttribute("data-secid",id); SECMAP[id]={name:nm, el:sec};
      var d=document.createElement("div"); d.className="del-x"; d.innerHTML="&#10005;"; d.title="Hide section";
      (function(secId){ d.addEventListener("click", function(ev){ ev.stopPropagation(); hideItem(secId); }); })(id);
      sec.appendChild(d);
    }
  })();
  function applyHidden(){ for(var id in SECMAP){ if(SECMAP.hasOwnProperty(id)){ SECMAP[id].el.classList.toggle("sec-hidden", isHidden(id)); } } }
  applyHidden();

  /* ---- hide whole tabs (Tools/Create/Text/Animation) via the pencil ---- */
  var TABMAP={};
  (function(){
    var tb=document.querySelectorAll(".tab");
    for(var i=0;i<tb.length;i++){
      var t=tb[i], key=t.getAttribute("data-tab"), id="tab_"+key;
      TABMAP[id]={name:t.textContent.replace(/\s+/g," ").trim(), el:t, key:key};
      var d=document.createElement("div"); d.className="del-x"; d.innerHTML="&#10005;"; d.title="Hide tab";
      (function(tid){ d.addEventListener("click", function(ev){ ev.stopPropagation(); hideTab(tid); }); })(id);
      t.appendChild(d);
    }
  })();
  function visTabs(){ var n=0; for(var id in TABMAP){ if(TABMAP.hasOwnProperty(id) && !isHidden(id)) n++; } return n; }
  function applyTabHidden(){
    var firstVisKey=null;
    for(var id in TABMAP){ if(!TABMAP.hasOwnProperty(id)) continue; var hid=isHidden(id); TABMAP[id].el.classList.toggle("tab-hidden", hid); if(!hid && firstVisKey===null) firstVisKey=TABMAP[id].key; }
    var act=document.querySelector(".tab.active");
    if(act){ var aid="tab_"+act.getAttribute("data-tab"); if(isHidden(aid) && firstVisKey) switchTab(firstVisKey); }
  }
  function hideTab(id){ if(visTabs()<=1) return; var h=hidGet(); if(h.indexOf(id)<0){ h.push(id); hidSet(h); } applyTabHidden(); }
  applyTabHidden();

  var elEdit=document.getElementById("icoEdit");
  if(elEdit) elEdit.addEventListener("click", function(){
    document.body.classList.toggle("editing");
    elEdit.classList.toggle("on", document.body.classList.contains("editing"));
  });

  function animById(id){ var all=TEXT_ANIMS.concat(SHAPE_ANIMS); for(var i=0;i<all.length;i++) if(all[i].id===id) return all[i]; return null; }
  function buildRestore(){
    var list=document.getElementById("restoreList"); if(!list) return; list.innerHTML="";
    var h=hidGet();
    if(h.length===0){ var e=document.createElement("div"); e.className="restore-empty"; e.textContent="Nothing hidden."; list.appendChild(e); return; }
    for(var i=0;i<h.length;i++){
      var id=h[i], name, cat="";
      if(SECMAP[id]){ name=SECMAP[id].name; cat="Section"; }
      else if(TABMAP[id]){ name=TABMAP[id].name; cat="Tab"; }
      else if(id==="dock_bar"){ name="Bottom dock"; cat="Dock"; }
      else { var a=animById(id); if(a){ name=a.name; cat=a.cat; } else { name=id; } }
      var row=document.createElement("div"); row.className="restore-row";
      var nm=document.createElement("div"); nm.className="rr-name"; nm.textContent=name; row.appendChild(nm);
      if(cat){ var c=document.createElement("div"); c.className="rr-cat"; c.textContent=cat; row.appendChild(c); }
      var b=document.createElement("div"); b.className="rr-add"; b.textContent="Restore";
      (function(rid){ b.addEventListener("click", function(){ restoreItem(rid); }); })(id);
      row.appendChild(b); list.appendChild(row);
    }
  }
  var elAdd=document.getElementById("icoAdd"), rModal=document.getElementById("restoreModal"), rClose=document.getElementById("restoreClose");

  /* ---- modal segmented control: Sections | Restore ---- */
  var segEls=document.querySelectorAll(".cust-seg");
  function showSeg(seg){
    for(var i=0;i<segEls.length;i++) segEls[i].classList.toggle("active", segEls[i].getAttribute("data-seg")===seg);
    var cv=document.getElementById("custView"), rl=document.getElementById("restoreList");
    if(cv) cv.style.display=(seg==="custom")?"block":"none";
    if(rl) rl.style.display=(seg==="restore")?"block":"none";
  }
  for(var sgI=0;sgI<segEls.length;sgI++){ (function(el){ el.addEventListener("click", function(){ showSeg(el.getAttribute("data-seg")); }); })(segEls[sgI]); }

  if(elAdd) elAdd.addEventListener("click", function(){ buildRestore(); renderCustom(); showSeg("custom"); if(rModal) rModal.classList.add("show"); });
  if(rClose) rClose.addEventListener("click", function(){ if(rModal) rModal.classList.remove("show"); });
  if(rModal) rModal.addEventListener("click", function(ev){ if(ev.target===rModal) rModal.classList.remove("show"); });

  /* ===== custom sections: user-defined tabs assembled from existing section blocks ===== */
  function csGet(){ try{ return JSON.parse(localStorage.getItem("amanow_customsecs")||"[]"); }catch(e){ return []; } }
  function csSet(a){ try{ localStorage.setItem("amanow_customsecs", JSON.stringify(a)); }catch(e){} }
  var csNextId=1;
  (function(){ var a=csGet(); for(var i=0;i<a.length;i++){ var n=parseInt(String(a[i].id).replace("custom_",""),10); if(!isNaN(n)&&n>=csNextId) csNextId=n+1; } })();

  function paneOf(el){ var p=el.parentNode; while(p&&p!==document){ if(p.classList&&p.classList.contains("tabpane")) return p; p=p.parentNode; } return null; }
  function paneFor(pid){ return document.querySelector('.tabpane[data-pane="'+pid+'"]'); }

  /* remember each section's home pane BEFORE any move happens */
  for(var _sid in SECMAP){ if(SECMAP.hasOwnProperty(_sid)){ var _pn=paneOf(SECMAP[_sid].el); SECMAP[_sid].origPane=_pn?_pn.getAttribute("data-pane"):"tools"; } }

  function makeCustomTab(cs){
    var tabsRow=document.querySelector(".tabs");
    var tab=document.createElement("div"); tab.className="tab tab-custom"; tab.setAttribute("data-tab", cs.id); tab.textContent=cs.name;
    bindTab(tab); tabsRow.appendChild(tab);
    var pane=document.createElement("div"); pane.className="tabpane"; pane.setAttribute("data-pane", cs.id);
    var allP=document.querySelectorAll(".tabpane"); var lastP=allP[allP.length-1];
    lastP.parentNode.insertBefore(pane, lastP.nextSibling);
    return pane;
  }
  function moveInto(secId, pane){ var s=SECMAP[secId]; if(s&&pane) pane.appendChild(s.el); }
  function moveBack(secId){ var s=SECMAP[secId]; if(!s) return; var op=paneFor(s.origPane); if(op) op.appendChild(s.el); }
  function usedMembers(){ var a=csGet(), u=[]; for(var i=0;i<a.length;i++){ var m=a[i].members||[]; for(var k=0;k<m.length;k++) u.push(m[k]); } return u; }

  function createCustom(name){
    name=String(name||"").replace(/\s+/g," ").trim(); if(!name) return;
    var a=csGet(); var cs={id:"custom_"+(csNextId++), name:name, members:[]}; a.push(cs); csSet(a);
    makeCustomTab(cs); renderCustom();
  }
  function deleteCustom(id){
    var a=csGet(), keep=[], target=null;
    for(var i=0;i<a.length;i++){ if(a[i].id===id) target=a[i]; else keep.push(a[i]); }
    if(target){ var m=target.members||[]; for(var k=0;k<m.length;k++) moveBack(m[k]); }
    csSet(keep);
    var tab=document.querySelector('.tab[data-tab="'+id+'"]'), pane=paneFor(id);
    var wasActive=tab&&tab.classList.contains("active");
    if(tab&&tab.parentNode) tab.parentNode.removeChild(tab);
    if(pane&&pane.parentNode) pane.parentNode.removeChild(pane);
    if(wasActive) switchTab("tools");
    renderCustom();
  }
  function addMember(csId, secId){
    var a=csGet(); for(var i=0;i<a.length;i++){ if(a[i].id===csId){ a[i].members=a[i].members||[]; if(a[i].members.indexOf(secId)<0) a[i].members.push(secId); } }
    csSet(a); var pane=paneFor(csId); if(pane) moveInto(secId, pane); renderCustom();
  }
  function removeMember(csId, secId){
    var a=csGet(); for(var i=0;i<a.length;i++){ if(a[i].id===csId){ var m=a[i].members||[]; var ix=m.indexOf(secId); if(ix>=0) m.splice(ix,1); a[i].members=m; } }
    csSet(a); moveBack(secId); renderCustom();
  }

  function renderCustom(){
    var list=document.getElementById("custList"); if(!list) return; list.innerHTML="";
    var a=csGet();
    if(a.length===0){ var e=document.createElement("div"); e.className="cust-empty"; e.textContent="No custom sections yet. Type a name above, press Create, then add blocks into it."; list.appendChild(e); return; }
    for(var i=0;i<a.length;i++){ (function(cs){
      var card=document.createElement("div"); card.className="cust-item";
      var head=document.createElement("div"); head.className="cust-item-head";
      var nm=document.createElement("div"); nm.className="cust-item-name"; nm.textContent=cs.name;
      var del=document.createElement("div"); del.className="cust-del"; del.innerHTML="&#10005;"; del.title="Delete this section";
      del.addEventListener("click", function(){ deleteCustom(cs.id); });
      head.appendChild(nm); head.appendChild(del); card.appendChild(head);
      var members=cs.members||[];
      var mem=document.createElement("div"); mem.className="cust-mem";
      for(var k=0;k<members.length;k++){ (function(secId){
        var s=SECMAP[secId]; if(!s) return;
        var r=document.createElement("div"); r.className="cust-mem-row";
        var t=document.createElement("span"); t.className="cust-mem-name"; t.textContent=s.name; r.appendChild(t);
        var x=document.createElement("span"); x.className="cust-mem-x"; x.innerHTML="&#10005;"; x.title="Remove from section";
        x.addEventListener("click", function(){ removeMember(cs.id, secId); });
        r.appendChild(x); mem.appendChild(r);
      })(members[k]); }
      if(members.length===0){ var em=document.createElement("div"); em.className="cust-mem-empty"; em.textContent="Empty — add blocks below."; mem.appendChild(em); }
      card.appendChild(mem);
      var sel=document.createElement("select"); sel.className="cust-add-sel";
      var o0=document.createElement("option"); o0.value=""; o0.textContent="+ Add a block\u2026"; sel.appendChild(o0);
      var used=usedMembers();
      for(var sid in SECMAP){ if(!SECMAP.hasOwnProperty(sid)) continue; if(used.indexOf(sid)>=0) continue;
        var o=document.createElement("option"); o.value=sid; o.textContent=SECMAP[sid].name; sel.appendChild(o); }
      sel.addEventListener("change", function(){ if(sel.value) addMember(cs.id, sel.value); });
      card.appendChild(sel);
      list.appendChild(card);
    })(a[i]); }
  }

  var custCreateBtn=document.getElementById("custCreate"), custNameInput=document.getElementById("custName");
  if(custCreateBtn) custCreateBtn.addEventListener("click", function(){ if(custNameInput){ createCustom(custNameInput.value); custNameInput.value=""; } });
  if(custNameInput) custNameInput.addEventListener("keydown", function(ev){ if(ev.keyCode===13){ ev.preventDefault(); createCustom(custNameInput.value); custNameInput.value=""; } });

  /* rebuild saved custom tabs and re-home their member blocks on load */
  (function(){ var a=csGet(); for(var i=0;i<a.length;i++){ var cs=a[i]; var pane=makeCustomTab(cs); var m=cs.members||[]; for(var k=0;k<m.length;k++) moveInto(m[k], pane); } })();

  /* ---- Counter: place In/Out markers ---- */

  /* ---- UI size (button size) via the pencil ---- */
  (function(){
    var sl=document.getElementById("uiScale"); if(!sl) return;
    function applyScale(v){ try{ document.body.style.zoom = (v/100); }catch(e){} }
    var saved=null; try{ saved=localStorage.getItem("amanow_uiscale"); }catch(e){}
    if(saved){ sl.value=saved; }
    applyScale(parseInt(sl.value,10)||100);
    sl.addEventListener("input", function(){ var v=parseInt(this.value,10)||100; applyScale(v); try{ localStorage.setItem("amanow_uiscale", String(v)); }catch(e){} });
  })();

  /* ---- Create: Adjustment Layer + Pre-compose ---- */
  var adjB=document.getElementById("adjBtn"); if(adjB) adjB.addEventListener("click", function(){ call('createAdjLayer()'); });
  var pcB=document.getElementById("precompBtn"); if(pcB) pcB.addEventListener("click", function(){ call('preCompose()'); });
  var upcB=document.getElementById("unprecompBtn"); if(upcB) upcB.addEventListener("click", function(){ call('unPreCompose()'); });
  var cenB=document.getElementById("centerBtn"); if(cenB) cenB.addEventListener("click", function(ev){ call('centerLayers('+((ev.ctrlKey||ev.metaKey)?1:0)+')'); });

  /* ---- Text Exploder (EXP): split a text layer into character/word/line/paragraph layers ---- */
  (function(){
    var b=document.getElementById("expBtn");
    if(b) b.addEventListener("click", function(){ var m=document.getElementById("expModal"); if(m) m.classList.add("show"); });
    document.addEventListener("click", function(e){
      var m=document.getElementById("expModal"); if(!m||!m.classList.contains("show")) return;
      if(e.target===m){ m.classList.remove("show"); return; }
      var c=e.target.closest?e.target.closest("#expClose"):null;
      if(c){ m.classList.remove("show"); return; }
      var o=e.target.closest?e.target.closest(".exp-opt"):null;
      if(o){ var md=o.getAttribute("data-exp")||"words"; call('am_explodeText("'+md+'")'); m.classList.remove("show"); }
    });
  })();

  /* ---- FX: Squash & Stretch + Shape Morph ---- */
  (function(){
    function fnum(id,df){ var el=document.getElementById(id); var v=el?parseFloat(String(el.value).replace(",",".")):NaN; return isNaN(v)?df:v; }
    var sq=document.getElementById("mlSquash");
    if(sq) sq.addEventListener("click", function(){ call('am_squashStretch('+fnum("mlSqX",120)+','+fnum("mlSqY",80)+','+fnum("mlSqDur",0.6)+')'); });
    var sqR=document.getElementById("mlSqReset");
    if(sqR) sqR.addEventListener("click", function(){ call('am_squashReset()'); });
  })();

  /* ---- Comp Resize (Tools) ---- */
  (function(){
    var rz=document.querySelectorAll("[data-resize]");
    for(var r=0;r<rz.length;r++){
      rz[r].addEventListener("click", function(){
        var p=(this.getAttribute("data-resize")||"1920x1080").split("x");
        call('am_resizeComp('+parseInt(p[0],10)+','+parseInt(p[1],10)+')');
      });
    }
  })();

  /* ---- Colors tab: solids + presets (named, deletable) ---- */
  (function(){
    var mode="fill";
    var K_SOL="amanow_palette", K_PRE="amanow_col_presets";
    function jget(k){ try{ var a=JSON.parse(localStorage.getItem(k)||"[]"); return (a&&a.length!==undefined)?a:[]; }catch(e){ return []; } }
    function jset(k,a){ try{ localStorage.setItem(k, JSON.stringify(a)); }catch(e){} }
    function norm(h){ h=String(h).replace(/[^0-9a-fA-F]/g,""); if(h.length===3) h=h.charAt(0)+h.charAt(0)+h.charAt(1)+h.charAt(1)+h.charAt(2)+h.charAt(2); if(h.length<6) return null; return "#"+h.substr(0,6).toLowerCase(); }
    function hex2rgb(h){ var n2=norm(h); if(!n2) return null; var n=parseInt(n2.substr(1),16); return [(n>>16)&255,(n>>8)&255,n&255]; }
    var SOLIDS=["#ffffff","#e5e7eb","#9ca3af","#4b5563","#111827","#000000","#ef4444","#f97316","#f59e0b","#eab308","#84cc16","#22c55e","#10b981","#14b8a6","#06b6d4","#0ea5e9","#3b82f6","#6366f1","#8b5cf6","#a855f7","#d946ef","#ec4899","#f43f5e","#fb7185","#fca5a5","#fdba74","#fde047","#bef264","#86efac","#67e8f9","#93c5fd","#c4b5fd","#f0abfc","#f9a8d4","#7f1d1d","#78350f","#365314","#064e3b","#0c4a6e","#1e3a8a"];
    function paint(hx){ var c=hex2rgb(hx); if(!c) return; call('am_applyBrandColor('+c[0]+','+c[1]+','+c[2]+',"'+mode+'")'); }

    var solidsWrap=document.getElementById("colSolids");
    /* swatch size slider (persisted) */
    (function(){
      var sz=document.getElementById("colSize"); if(!sz||!solidsWrap) return;
      var saved=null; try{ saved=localStorage.getItem("amanow_sw_size"); }catch(e){}
      if(saved){ sz.value=saved; }
      function apply(){ solidsWrap.style.setProperty("--sw", sz.value+"px"); }
      apply();
      sz.addEventListener("input", function(){ apply(); try{ localStorage.setItem("amanow_sw_size", sz.value); }catch(e){} });
    })();
    function renderSolids(){
      if(!solidsWrap) return; solidsWrap.innerHTML="";
      var custom=jget(K_SOL), all=SOLIDS.concat(custom);
      for(var i=0;i<all.length;i++){(function(hx,isCustom,cidx){
        var d=document.createElement("div"); d.className="col-sw"; d.style.background=hx; d.title=hx;
        d.addEventListener("click", function(){ paint(hx); });
        if(isCustom) d.addEventListener("contextmenu", function(ev){ ev.preventDefault(); var arr=jget(K_SOL); arr.splice(cidx,1); jset(K_SOL,arr); renderSolids(); });
        solidsWrap.appendChild(d);
      })(all[i], i>=SOLIDS.length, i-SOLIDS.length);}
    }
    renderSolids();

    /* add solid: hex field + ADD, and the + native picker */
    var hexIn=document.getElementById("colHex"), addBtn=document.getElementById("colAdd");
    function addHex(v){ var n2=norm(v); if(!n2) return; var arr=jget(K_SOL); arr.push(n2); jset(K_SOL,arr); renderSolids(); if(hexIn) hexIn.value=""; }
    if(addBtn) addBtn.addEventListener("click", function(){ if(hexIn) addHex(hexIn.value); });
    if(hexIn) hexIn.addEventListener("keydown", function(e){ if(e.keyCode===13&&hexIn) addHex(hexIn.value); });
    var pickBtn=document.getElementById("colPick"), picker=document.getElementById("colPicker");
    if(pickBtn&&picker){ pickBtn.addEventListener("click", function(){ picker.click(); }); picker.addEventListener("change", function(){ addHex(picker.value); }); }

    /* presets: named Save / dropdown / X delete / Load / Reset */
    var preSel=document.getElementById("colPresets"), nameIn=document.getElementById("colName");
    function renderPresets(selIdx){
      if(!preSel) return; preSel.innerHTML="";
      var ps=jget(K_PRE);
      if(ps.length===0){ var o=document.createElement("option"); o.value=""; o.textContent="(no presets)"; preSel.appendChild(o); return; }
      for(var i=0;i<ps.length;i++){ var op=document.createElement("option"); op.value=String(i); op.textContent=ps[i].name||("Preset "+(i+1)); preSel.appendChild(op); }
      if(selIdx!==undefined && selIdx!==null && selIdx>=0 && selIdx<ps.length) preSel.value=String(selIdx);
    }
    renderPresets();
    var saveB=document.getElementById("colSave"), loadB=document.getElementById("colLoad"), resetB=document.getElementById("colReset"), delB=document.getElementById("colDel");
    if(saveB) saveB.addEventListener("click", function(){
      var ps=jget(K_PRE);
      var nm=nameIn?String(nameIn.value).replace(/^\s+|\s+$/g,""):"";
      if(!nm) nm="Preset "+(ps.length+1);
      ps.push({name:nm, solids:jget(K_SOL)});
      jset(K_PRE,ps); renderPresets(ps.length-1); if(nameIn) nameIn.value="";
    });
    if(loadB) loadB.addEventListener("click", function(){
      var ps=jget(K_PRE); if(!preSel||preSel.value==="") return; var idx=parseInt(preSel.value,10); var p=ps[idx]; if(!p) return;
      jset(K_SOL, p.solids||[]); renderSolids();
    });
    if(delB) delB.addEventListener("click", function(){
      var ps=jget(K_PRE); if(!preSel||preSel.value==="") return; var idx=parseInt(preSel.value,10); if(isNaN(idx)||idx<0||idx>=ps.length) return;
      ps.splice(idx,1); jset(K_PRE,ps); renderPresets(idx>=ps.length?ps.length-1:idx);
    });
    if(resetB) resetB.addEventListener("click", function(){ jset(K_SOL,[]); renderSolids(); });

    /* fill / stroke mode */
    var cf=document.getElementById("colFill"), cs=document.getElementById("colStroke");
    function setMode(m2){ mode=m2; if(cf) cf.classList.toggle("active",m2==="fill"); if(cs) cs.classList.toggle("active",m2==="stroke"); }
    if(cf) cf.addEventListener("click", function(){ setMode("fill"); });
    if(cs) cs.addEventListener("click", function(){ setMode("stroke"); });
  })();

  /* ---- Copy / Paste Curves (temporal ease only) ---- */
  function flashBtn(b, txt){ if(!b)return; var orig=b.getAttribute("data-orig")||b.textContent; b.setAttribute("data-orig",orig); b.textContent=txt; b.classList.add("ok-flash"); setTimeout(function(){ b.textContent=orig; b.classList.remove("ok-flash"); }, 950); }
  var copyCurvesBtn=document.getElementById("copyCurves");
  if(copyCurvesBtn) copyCurvesBtn.addEventListener("click", function(){ var b=this; callR('copyCurves()', function(r){ var n=parseInt(r,10)||0; if(n>0) flashBtn(b, "Copied "+n); }); });
  var pasteCurvesBtn=document.getElementById("pasteCurves");
  if(pasteCurvesBtn) pasteCurvesBtn.addEventListener("click", function(){ var b=this; callR('pasteCurves()', function(r){ var n=parseInt(r,10)||0; if(n>0) flashBtn(b, "Pasted "+n); }); });

  /* ---- Bottom dock (Align / Duplicate / Import) ---- */
  (function(){
    var TOOLS={
      align:{label:"Align", svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 6h16M4 12h11M4 18h14"/></svg>'},
      dub:{label:"Duplicate", svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round"><rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 4H4v12"/></svg>'},
      import:{label:"Import", svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v11M8 10l4 4 4-4M5 20h14"/></svg>'},
      export:{label:"Export", svg:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 15V4M8 8l4-4 4 4M5 20h14"/></svg>'}
    };
    var dockTools=document.getElementById("dockTools"), dockAdd=document.getElementById("dockAdd"),
        dockMenu=document.getElementById("dockMenu"), alignSub=document.getElementById("alignSub"),
        dockDel=document.getElementById("dockDel"), dock=document.getElementById("dock");
    if(!dock) return;
    function dockGet(){ try{ return JSON.parse(localStorage.getItem("amanow_dock")||"[]"); }catch(e){ return []; } }
    function dockSet(a){ try{ localStorage.setItem("amanow_dock", JSON.stringify(a)); }catch(e){} }
    function addTool(id){ var a=dockGet(); if(a.indexOf(id)<0){ a.push(id); dockSet(a); } renderDock(); }
    function removeTool(id){ var a=dockGet(), i=a.indexOf(id); if(i>=0){ a.splice(i,1); dockSet(a); } if(id==="align" && alignSub) alignSub.classList.remove("show"); renderDock(); }
    function onTool(id){
      if(id==="align"){ if(alignSub) alignSub.classList.toggle("show"); }
      else if(id==="dub"){ call('duplicateLayers()'); }
      else if(id==="import"){ call('importFiles()'); }
      else if(id==="export"){ call('exportComp()'); }
    }
    function renderDock(){
      var a=dockGet(); dockTools.innerHTML="";
      for(var i=0;i<a.length;i++){ (function(id){
        var T=TOOLS[id]; if(!T) return;
        var ic=document.createElement("div"); ic.className="dock-ic dock-tool"; ic.title=T.label; ic.innerHTML=T.svg;
        ic.addEventListener("click", function(){ onTool(id); });
        var x=document.createElement("div"); x.className="del-x dock-icx"; x.innerHTML="&#10005;";
        x.addEventListener("click", function(ev){ ev.stopPropagation(); removeTool(id); });
        ic.appendChild(x); dockTools.appendChild(ic);
      })(a[i]); }
      if(dockMenu){ var mis=dockMenu.querySelectorAll(".dock-mi"); for(var j=0;j<mis.length;j++){ var mid=mis[j].getAttribute("data-add"); mis[j].style.display=(a.indexOf(mid)>=0)?"none":"block"; } }
    }
    if(dockAdd) dockAdd.addEventListener("click", function(ev){ ev.stopPropagation(); if(dockMenu) dockMenu.classList.toggle("show"); });
    if(dockMenu){ var mi=dockMenu.querySelectorAll(".dock-mi"); for(var k=0;k<mi.length;k++){ (function(el){ el.addEventListener("click", function(ev){ ev.stopPropagation(); addTool(el.getAttribute("data-add")); dockMenu.classList.remove("show"); }); })(mi[k]); } }
    document.addEventListener("click", function(){ if(dockMenu) dockMenu.classList.remove("show"); });
    if(alignSub){ var ai=alignSub.querySelectorAll("[data-align]"); for(var z=0;z<ai.length;z++){ (function(el){ el.addEventListener("click", function(){ call('alignLayers("'+el.getAttribute("data-align")+'")'); }); })(ai[z]); } }
    function applyDockHidden(){ dock.classList.toggle("dock-hidden", isHidden("dock_bar")); }
    window.amApplyDock=applyDockHidden;
    if(dockDel) dockDel.addEventListener("click", function(ev){ ev.stopPropagation(); var h=hidGet(); if(h.indexOf("dock_bar")<0){ h.push("dock_bar"); hidSet(h); } applyDockHidden(); });
    applyDockHidden(); renderDock();
  })();

  /* ---- Dock collapse / expand: one handle, swaps > and < at the same spot ---- */
  (function(){
    var dock=document.getElementById("dock"), handle=document.getElementById("dockHandle");
    if(!dock||!handle) return;
    function setCollapsed(v){ try{ localStorage.setItem("amanow_dockcollapsed", v?"1":"0"); }catch(e){} dock.classList.toggle("collapsed", v); handle.title=v?"Show panel":"Hide panel"; }
    handle.addEventListener("click", function(ev){ ev.stopPropagation(); setCollapsed(!dock.classList.contains("collapsed")); });
    var v=false; try{ v=localStorage.getItem("amanow_dockcollapsed")==="1"; }catch(e){}
    setCollapsed(v);
  })();

  /* ===================== LICENSE / ACTIVATION ===================== */
  /* Key validation now happens on the server. No secret and no key-generation algorithm ship in the plugin. */
  function am_sha256(asciiOrBytes){
    function utf8(s){var b=[];for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)b.push(c);else if(c<2048){b.push(192|(c>>6));b.push(128|(c&63));}else{b.push(224|(c>>12));b.push(128|((c>>6)&63));b.push(128|(c&63));}}return b;}
    var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
    var bytes=(typeof asciiOrBytes==="string")?utf8(asciiOrBytes):asciiOrBytes;
    var l=bytes.length,w1=bytes.slice();w1.push(0x80);while(w1.length%64!=56)w1.push(0);
    var bl=l*8;for(var i=7;i>=0;i--){w1.push((bl/Math.pow(2,i*8))&255);}
    var H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
    function rotr(x,n){return (x>>>n)|(x<<(32-n));}
    for(var off=0;off<w1.length;off+=64){
      var w=[];for(var t=0;t<16;t++){w[t]=(w1[off+t*4]<<24)|(w1[off+t*4+1]<<16)|(w1[off+t*4+2]<<8)|(w1[off+t*4+3]);}
      for(var t=16;t<64;t++){var s0=rotr(w[t-15],7)^rotr(w[t-15],18)^(w[t-15]>>>3);var s1=rotr(w[t-2],17)^rotr(w[t-2],19)^(w[t-2]>>>10);w[t]=(w[t-16]+s0+w[t-7]+s1)|0;}
      var a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
      for(var t=0;t<64;t++){var S1=rotr(e,6)^rotr(e,11)^rotr(e,25);var ch=(e&f)^((~e)&g);var t1=(h+S1+ch+K[t]+w[t])|0;var S0=rotr(a,2)^rotr(a,13)^rotr(a,22);var maj=(a&b)^(a&c)^(b&c);var t2=(S0+maj)|0;h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;}
      H[0]=(H[0]+a)|0;H[1]=(H[1]+b)|0;H[2]=(H[2]+c)|0;H[3]=(H[3]+d)|0;H[4]=(H[4]+e)|0;H[5]=(H[5]+f)|0;H[6]=(H[6]+g)|0;H[7]=(H[7]+h)|0;
    }
    var out="";for(var i=0;i<8;i++){var hx=(H[i]>>>0).toString(16);while(hx.length<8)hx="0"+hx;out+=hx;}return out;
  }
  function am_devCode(raw){ return am_sha256(String(raw)).toUpperCase().substr(0,16); }
  function am_fmtDev(d){ return d.substr(0,4)+"-"+d.substr(4,4)+"-"+d.substr(8,4)+"-"+d.substr(12,4); }
  function am_normKey(k){ return String(k).toUpperCase().replace(/[^A-Z0-9-]/g,""); }
  function am_storedKey(){ try{ return localStorage.getItem("amanow_license")||""; }catch(e){ return ""; } }
  function am_saveKey(k){ try{ localStorage.setItem("amanow_license", k); }catch(e){} }
  var AM_DEV="";
  var AM_TRIAL_DAYS=3;
  var am_activated=false;

  /* ===== Server licensing (device-bound trial; cannot be reset by re-install) ===== */
  /* >>> After you deploy the Worker, paste its URL here (no trailing slash): <<< */
  var AM_SERVER = "https://amanowtools.aamanow1509.workers.dev";   /* e.g. "https://amanowtools.yourname.workers.dev"  (leave "" to use the local trial only) */
  function am_srvCacheGet(){ try{ return JSON.parse(localStorage.getItem("amanow_srv")||"null"); }catch(e){ return null; } }
  function am_srvCacheSet(o){ try{ localStorage.setItem("amanow_srv", JSON.stringify(o)); }catch(e){} }
  function am_post(path, body, cb){
    if(!AM_SERVER){ cb(null); return; }
    try{
      var x=new XMLHttpRequest();
      x.open("POST", AM_SERVER.replace(/\/+$/,"")+path, true);
      x.setRequestHeader("Content-Type","application/json");
      x.timeout=8000;
      x.onreadystatechange=function(){ if(x.readyState===4){ var r=null; try{ r=JSON.parse(x.responseText); }catch(e){ r=null; } cb(r); } };
      x.ontimeout=function(){ cb(null); };
      x.onerror=function(){ cb(null); };
      x.send(JSON.stringify(body));
    }catch(e){ cb(null); }
  }
  function am_gateText(status){
    var sub=document.getElementById("licSub"); if(!sub) return;
    if(status==="expired") sub.textContent="Your free trial has ended on this device. Enter your personal key to continue, or contact the seller.";
    else sub.textContent="Start your free "+AM_TRIAL_DAYS+"-day trial: enter the trial code below. When it ends, enter the personal key from the seller.";
  }
  function am_applyServerStatus(res){
    am_srvCacheSet({ status:res.status, expires:res.expires||0, ts:Date.now() });
    if(res.status==="licensed"){ am_activated=true; am_unlock(); am_trialBadge(-1); }
    else if(res.status==="trial"){ am_unlock(); am_trialBadge(res.daysLeft||1); }
    else { am_lock(); am_trialBadge(0); am_gateText(res.status); }   /* expired or unknown */
  }
  function am_offlineFallback(){
    var c=am_srvCacheGet();
    if(c && c.status){
      if(c.status==="licensed"){ am_unlock(); am_trialBadge(-1); return; }
      if(c.status==="trial"){
        if(!c.expires || Date.now()<c.expires){ var dl=c.expires?Math.max(1,Math.ceil((c.expires-Date.now())/86400000)):1; am_unlock(); am_trialBadge(dl); return; }
        am_lock(); am_trialBadge(0); am_gateText("expired"); return;
      }
      if(c.status==="expired"){ am_lock(); am_trialBadge(0); am_gateText("expired"); return; }
    }
    /* STRICT: no internet and nothing verified yet -> must connect once before the plugin can run */
    am_lock();
    am_trialBadge(0);
    var sub=document.getElementById("licSub");
    if(sub) sub.textContent="Connect to the internet once to start AmanowTools. After the first activation it also works offline.";
    var msg=document.getElementById("licMsg");
    if(msg){ msg.className="lic-msg err"; msg.textContent="No internet connection. Go online once, then enter the trial code or your key."; }
  }
  function am_unlock(){ var g=document.getElementById("licenseGate"); if(g) g.classList.remove("show"); }
  function am_lock(){ var g=document.getElementById("licenseGate"); if(g) g.classList.add("show"); var lt=document.getElementById("licLater"); if(lt) lt.style.display="none"; }
  function am_hasAccess(){
    if(am_activated) return true;
    if(!AM_SERVER) return true;                      /* local-trial mode: allow dismissing */
    var c=am_srvCacheGet();
    if(c && c.status==="licensed") return true;
    if(c && c.status==="trial" && (!c.expires || Date.now()<c.expires)) return true;
    return false;
  }
  function am_openGate(){                              /* opened by the key icon */
    if(am_activated){ var m0=document.getElementById("licMsg"); if(m0){ m0.className="lic-msg ok"; m0.textContent="This copy is already activated."; } }
    var g=document.getElementById("licenseGate"); if(g) g.classList.add("show");
    var lt=document.getElementById("licLater"); if(lt) lt.style.display=am_hasAccess()?"block":"none";
    var sub=document.getElementById("licSub"); if(sub) sub.textContent="Have a key? Enter it below to activate the full version now \u2014 or tap Later to keep using the trial.";
    var m=document.getElementById("licMsg"); if(m && !am_activated){ m.className="lic-msg"; m.textContent=""; }
  }

  /* trial timestamp is mirrored in localStorage; the durable copy lives in the AE user folder (host) */
  function am_lsTrialGet(){ try{ return localStorage.getItem("amanow_trial")||""; }catch(e){ return ""; } }
  function am_lsTrialSet(v){ try{ localStorage.setItem("amanow_trial", v); }catch(e){} }

  function am_trialPill(){
    var p=document.getElementById("amTrialPill");
    if(!p){
      p=document.createElement("div"); p.id="amTrialPill"; p.title="Click to enter your key";
      p.addEventListener("click", function(){ am_lock(); var sub=document.getElementById("licSub"); if(sub) sub.textContent="Enter your key to activate the full version (your free trial is still running)."; });
      document.body.appendChild(p);
    }
    return p;
  }
  function am_trialBadge(daysLeft){
    var p=am_trialPill();
    if(daysLeft<0){ p.classList.remove("show"); return; }   /* activated */
    if(daysLeft<=0){ p.classList.remove("show"); return; }   /* expired: the gate takes over */
    p.textContent="Trial \u00b7 "+daysLeft+(daysLeft===1?" day left":" days left");
    p.classList.add("show");
  }

  function am_applyTrial(){
    callR('amTrialStamp()', function(ts){
      var now=Date.now();
      var fI=0,fL=0; if(ts&&ts.indexOf("|")>=0){ var p=ts.split("|"); fI=parseFloat(p[0])||0; fL=parseFloat(p[1])||0; }
      var ls=am_lsTrialGet(), lI=0,lL=0; if(ls&&ls.indexOf("|")>=0){ var q=ls.split("|"); lI=parseFloat(q[0])||0; lL=parseFloat(q[1])||0; }
      /* earliest install + latest last-seen, so clearing one store alone can't reset the trial */
      var install=Math.min(fI||now, lI||now);
      var last=Math.max(fL||now, lL||now, now);
      am_lsTrialSet(install+"|"+last);
      call('amTrialSet('+install+','+last+')');
      var used=(last-install)/86400000;
      var left=Math.ceil(AM_TRIAL_DAYS-used);
      if(used<AM_TRIAL_DAYS){ am_unlock(); am_trialBadge(left); }
      else {
        var sub=document.getElementById("licSub");
        if(sub) sub.textContent="Your "+AM_TRIAL_DAYS+"-day free trial has ended. Send your device code to the seller to get your personal key, then paste it below.";
        am_lock(); am_trialBadge(0);
      }
    });
  }

  function am_initLicense(){
    callR('amDeviceRaw()', function(raw){
      raw=(raw&&String(raw).length)?String(raw):"UNKNOWN-DEVICE";
      AM_DEV=am_devCode(raw);
      var dc=document.getElementById("licDevice"); if(dc) dc.textContent=am_fmtDev(AM_DEV);
      if(!AM_SERVER){ am_activated=false; am_applyTrial(); return; }   /* no server URL set -> local trial */
      am_gateText("unknown");
      var afterCheck=function(){
        am_post("/check", { device:AM_DEV }, function(res){
          if(!res || !res.status){ am_offlineFallback(); return; }
          am_applyServerStatus(res);
        });
      };
      var stored=am_storedKey();
      if(stored){
        /* migrate a previously-activated customer: let the server confirm their old key */
        am_post("/activate", { device:AM_DEV, key:am_normKey(stored) }, function(res){
          if(res && res.status==="licensed"){ am_applyServerStatus(res); return; }
          afterCheck();
        });
      } else { afterCheck(); }
    });
  }
  (function(){
    var btn=document.getElementById("licActivate"), inp=document.getElementById("licKey"), msg=document.getElementById("licMsg"), cp=document.getElementById("licCopy");
    if(cp) cp.addEventListener("click", function(){ try{ var t=document.getElementById("licDevice").textContent; if(navigator.clipboard) navigator.clipboard.writeText(t); }catch(e){} });
    function doActivate(){
      if(!msg) return;
      var k=inp?am_normKey(inp.value):"";
      if(!AM_DEV){ msg.className="lic-msg err"; msg.textContent="Device code not ready yet \u2014 wait a second and retry."; return; }
      if(!k){ msg.className="lic-msg err"; msg.textContent="Enter your key."; return; }
      if(!AM_SERVER){ msg.className="lic-msg err"; msg.textContent="Activation server is not configured."; return; }
      msg.className="lic-msg"; msg.textContent="Checking\u2026";
      am_post("/activate", { device:AM_DEV, key:k }, function(res){
        if(!res){ msg.className="lic-msg err"; msg.textContent="No connection. Go online and try again."; return; }
        if(res.status==="licensed"){ am_saveKey(k); am_activated=true; am_srvCacheSet({status:"licensed",expires:0,ts:Date.now()}); am_trialBadge(-1); msg.className="lic-msg ok"; msg.textContent="Activated. Welcome!"; setTimeout(am_unlock, 600); return; }
        if(res.error==="bad_key"){ msg.className="lic-msg err"; msg.textContent="Invalid key for this device."; return; }
        msg.className="lic-msg err"; msg.textContent="Activation failed. Try again.";
      });
    }
    if(btn) btn.addEventListener("click", doActivate);
    if(inp) inp.addEventListener("keydown", function(e){ if(e.key==="Enter") doActivate(); });

    var tBtn=document.getElementById("licTrialBtn"), tInp=document.getElementById("licTrialCode");
    function doTrial(){
      if(!msg) return;
      var code=tInp?String(tInp.value).replace(/^\s+|\s+$/g,""):"";
      if(!AM_DEV){ msg.className="lic-msg err"; msg.textContent="Device code not ready yet \u2014 wait a second and retry."; return; }
      if(!code){ msg.className="lic-msg err"; msg.textContent="Enter the trial code."; return; }
      if(!AM_SERVER){ msg.className="lic-msg err"; msg.textContent="Trial server is not configured."; return; }
      msg.className="lic-msg"; msg.textContent="Checking\u2026";
      am_post("/trial/start", { device:AM_DEV, code:code }, function(res){
        if(!res){ msg.className="lic-msg err"; msg.textContent="No connection. Connect to the internet and try again."; return; }
        if(res.error==="bad_code"){ msg.className="lic-msg err"; msg.textContent="Invalid trial code."; return; }
        if(res.status==="licensed"){ am_applyServerStatus(res); return; }
        if(res.status==="trial"){ am_srvCacheSet({status:"trial",expires:res.expires||0,ts:Date.now()}); msg.className="lic-msg ok"; msg.textContent=res.already?("Trial already active \u2014 "+(res.daysLeft||1)+" day(s) left."):"Trial started! Enjoy."; am_trialBadge(res.daysLeft||1); setTimeout(am_unlock, 700); return; }
        if(res.status==="expired"){ am_srvCacheSet({status:"expired",expires:res.expires||0,ts:Date.now()}); msg.className="lic-msg err"; msg.textContent="This device's trial has already been used."; am_gateText("expired"); return; }
        msg.className="lic-msg err"; msg.textContent="Could not start the trial.";
      });
    }
    if(tBtn) tBtn.addEventListener("click", doTrial);
    if(tInp) tInp.addEventListener("keydown", function(e){ if(e.key==="Enter") doTrial(); });
  })();
  am_initLicense();

  /* ===================== AUTO-UPDATE (panel side) =====================
     The plugin checks AM_UPDATE_URL quietly (at most every 6 hours).
     update.json:
       { "version":"1.19.0",
         "notes":"What is new",
         "url":"https://.../AmanowTools.zxp",     <- direct file link  = "Update now" installs in place
         "page":"https://t.me/amanow_channel/21/41?single",  <- fallback / channel button
         "required":false }
     Both update paths live side by side:
       1) "Update now"  - downloads and replaces the plugin files itself (no reinstall);
       2) "Open Telegram channel" - your channel post with the release.            */
  /* Where the plugin looks for the update notice. It tries them IN ORDER and takes
     the first one that answers with valid JSON — so you can host the notice either
     on Cloudflare Pages or on your Worker, and switch later without re-sending
     the plugin to anybody. */
  var AM_UPDATE_URLS = [
    "https://amanow-updates.pages.dev/update.json",
    "https://amanowtools.aamanow1509.workers.dev/update"
  ];
  var AM_UPDATE_PAGE = "https://t.me/amanow_channel/21/41?single";
  var AM_UPD_EVERY  = 6*60*60*1000;
  var amVerNow="", amUpdData=null;

  function amVerCmp(a,b){
    var A=String(a||"0").split("."), B=String(b||"0").split(".");
    for(var i=0;i<Math.max(A.length,B.length);i++){
      var x=parseInt(A[i],10)||0, y=parseInt(B[i],10)||0;
      if(x>y) return 1;
      if(x<y) return -1;
    }
    return 0;
  }
  function amU(id){ return document.getElementById(id); }
  function amUpdBadge(on){ var b=amU("updBadge"); if(b) b.className="upd-badge"+(on?" show":""); }
  function amUpdPage(){ return (amUpdData&&amUpdData.page)||AM_UPDATE_PAGE; }

  function amUpdOvSet(cls, title, ver, notes, msg){
    var ov=amU("updOv"); if(!ov) return;
    ov.className="updov show"+(cls?" "+cls:"");
    var t=amU("updOvTitle"); if(t) t.textContent=title;
    var v=amU("updOvVer");   if(v) v.textContent=ver||"";
    var n=amU("updOvNotes"); if(n) n.textContent=notes||"";
    var m=amU("updOvMsg");   if(m) m.textContent=msg||"";
  }
  function amUpdOvClose(){ var ov=amU("updOv"); if(ov) ov.className="updov"; }

  function amUpdOpenNotice(){
    if(!amUpdData) return;
    var d=amUpdData;
    amUpdOvSet("", "Update available", "v"+(amVerNow||"?")+"  \u2192  v"+d.version,
      d.notes||"A new version of AmanowTools is ready.",
      "");
    var go=amU("updOvGo");
    if(go){ go.style.display=d.url?"":"none"; go.disabled=false; go.textContent="Update now"; }
    /* no direct file link -> Telegram becomes the main (blue) button */
    var lk=amU("updOvLink");
    if(lk){ lk.style.display=""; lk.textContent="Get it on Telegram"; lk.className="updov-link"+(d.url?"":" solo"); }
    var x=amU("updOvX"); if(x) x.style.display=(d.required?"none":"");
  }
  function amUpdDismiss(){
    amUpdOvClose();
    if(amUpdData){
      try{ localStorage.setItem("amanow_upd_seen", String(amUpdData.version)); }catch(e){}
      amUpdBadge(true);            /* the red "1" on the header icon = reminder */
    }
  }
  function amUpdInstall(){
    if(!amUpdData||!amUpdData.url) return;
    var go=amU("updOvGo"); if(go){ go.disabled=true; go.textContent="Installing\u2026"; }
    var x=amU("updOvX"); if(x) x.style.display="none";
    amUpdOvSet("busy","Installing update","v"+amUpdData.version,
      "Downloading and replacing the plugin files. This takes a few seconds.","");
    var u=String(amUpdData.url).replace(/"/g,"");
    callR('am_selfUpdate("'+u+'")', function(res){
      res=String(res||"");
      var x2=amU("updOvX"); if(x2) x2.style.display="";
      if(res.indexOf("OK")===0){
        amUpdBadge(false);
        try{ localStorage.setItem("amanow_upd_seen", String(amUpdData.version)); }catch(e){}
        amUpdOvSet("done","Update installed","v"+amUpdData.version,
          "Close After Effects completely and open it again \u2014 the new version will load.","");
        var g=amU("updOvGo"); if(g) g.style.display="none";
        var lk=amU("updOvLink"); if(lk) lk.style.display="none";
      } else {
        /* no rights / no network -> the Telegram way still works */
        amUpdOvSet("err","Automatic update failed","v"+amUpdData.version,
          "Get the new version from the Telegram channel instead \u2014 one tap below.",
          res.replace(/^ERR:\s*/,""));
        var g2=amU("updOvGo"); if(g2){ g2.style.display="none"; }
      }
    });
  }
  function amUpdApply(d, manual){
    if(!d||!d.version){ if(manual) amUpdOvSet("err","Update check failed","", "Could not reach the update server.",""); return; }
    if(amVerCmp(d.version, amVerNow)<=0){
      amUpdData=null; amUpdBadge(false);
      if(manual) amUpdOvSet("done","You are up to date","v"+(amVerNow||"?"),"This is the latest version.","");
      return;
    }
    amUpdData=d;
    var seen="";
    try{ seen=localStorage.getItem("amanow_upd_seen")||""; }catch(e){}
    if(manual){ amUpdOpenNotice(); return; }
    if(d.required || seen!==String(d.version)) amUpdOpenNotice();   /* full-screen once per version */
    else amUpdBadge(true);                                          /* already dismissed -> just the badge */
  }
  function amUpdFetch(list, i, cb){
    if(i>=list.length){ cb(null); return; }
    var next=function(){ amUpdFetch(list, i+1, cb); };
    try{
      var u=list[i];
      var x=new XMLHttpRequest();
      x.open("GET", u+(u.indexOf("?")<0?"?":"&")+"t="+Date.now(), true);
      x.timeout=8000;
      x.onreadystatechange=function(){
        if(x.readyState!==4) return;
        var d=null; try{ d=JSON.parse(x.responseText); }catch(e){ d=null; }
        if(d&&d.version) cb(d); else next();
      };
      x.ontimeout=next;
      x.onerror=next;
      x.send();
    }catch(e){ next(); }
  }
  function amUpdCheck(manual){
    if(!manual){
      try{
        var last=parseInt(localStorage.getItem("amanow_upd_ts")||"0",10)||0;
        if(Date.now()-last < AM_UPD_EVERY) return;
      }catch(e){}
    }
    try{ localStorage.setItem("amanow_upd_ts", String(Date.now())); }catch(e){}
    var ico=amU("icoUpd"); if(manual&&ico) ico.className="hicon spin";
    amUpdFetch(AM_UPDATE_URLS, 0, function(d){
      if(ico) ico.className="hicon";
      amUpdApply(d, manual);
    });
  }
  (function amUpdInit(){
    var go=amU("updOvGo");   if(go) go.addEventListener("click", amUpdInstall);
    var lk=amU("updOvLink"); if(lk) lk.addEventListener("click", function(){ openURL(amUpdPage()); });
    var xb=amU("updOvX");    if(xb) xb.addEventListener("click", amUpdDismiss);
    var ico=amU("icoUpd");
    if(ico) ico.addEventListener("click", function(){
      if(amUpdData) amUpdOpenNotice();     /* reminder click -> show the notice again */
      else amUpdCheck(true);               /* nothing pending -> check right now */
    });
   var amExtensionRoot = cs.getSystemPath("extension") || "";

callR(
  'am_pluginVersion("' + esc(amExtensionRoot) + '")',
  function(v){
    amVerNow = String(v || "").replace(/[^0-9.]/g, "");

    var ic = amU("icoUpd");

    if(ic && amVerNow){
      ic.title = "Check for updates (v" + amVerNow + ")";
    }

    amUpdCheck(false);
  }
);
  })();

    /* ---- Free edit mode: drag body to move, drag the corner handle to resize (real width/height) ---- */
  (function(){
    var LS="amanow_freelayout";
    function load(){ try{ return JSON.parse(localStorage.getItem(LS)||"{}")||{}; }catch(e){ return {}; } }
    function save(o){ try{ localStorage.setItem(LS, JSON.stringify(o)); }catch(e){} }
    var store=load();

    var GRID=6;     /* position snap grid (px) */
    var HOME=12;    /* snap back to home spot within this radius (px) */
    var SZGRID=4;   /* size snap grid (px) */
    var SZHOME=10;  /* snap back to natural size within this much (px) */
    var MINW=40, MINH=22, MAXW=620, MAXH=240;

    function slug(s){ return String(s||"").toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,"").substring(0,22); }
    function paneOf(el){ var p=el; while(p&&p!==document){ if(p.classList&&p.classList.contains("tabpane")) return p.getAttribute("data-pane")||"x"; p=p.parentNode; } return "x"; }

    /* tag every real action button inside the tab panes (modals / license / dock / tiles excluded) */
    var btns=[], counts={};
    var all=document.querySelectorAll(".tabpane .btn");
    for(var i=0;i<all.length;i++){
      var b=all[i];
      if(b.closest && (b.closest(".restore-modal")||b.closest(".lic-gate")||b.closest(".modal"))) continue;
      var pane=paneOf(b);
      var idx=(counts[pane]=(counts[pane]||0)+1)-1;
      b.setAttribute("data-fk", pane+"#"+(b.id||slug(b.textContent)||("b"+idx))+"#"+idx);
      b.classList.add("freebtn");
      if(!b.querySelector(".free-rz")){ var h=document.createElement("span"); h.className="free-rz"; h.setAttribute("aria-hidden","true"); b.appendChild(h); }
      btns.push(b);
    }
    if(btns.length===0) return;

    function clean(c){ if(!c.dx) c.dx=0; if(!c.dy) c.dy=0; if(!c.w) c.w=0; if(!c.h) c.h=0; }
    function applySize(b,c){
      if(c.w>0 && c.h>0){
        b.style.flex="0 0 auto";
        b.style.width=c.w+"px"; b.style.minWidth=c.w+"px"; b.style.maxWidth=c.w+"px";
        b.style.height=c.h+"px"; b.style.minHeight=c.h+"px";
      } else {
        b.style.flex=""; b.style.width=""; b.style.minWidth=""; b.style.maxWidth=""; b.style.height=""; b.style.minHeight="";
      }
    }
    function applyPos(b,c){ b.style.transform = (c.dx||c.dy) ? ("translate("+(c.dx||0)+"px,"+(c.dy||0)+"px)") : ""; }
    function xform(b,c){ applySize(b,c); applyPos(b,c); b.classList.toggle("moved", !!(c.dx||c.dy||c.w||c.h)); }
    function cfg(b){ var k=b.getAttribute("data-fk"); return store[k]||(store[k]={dx:0,dy:0,w:0,h:0}); }
    function persist(b){ var k=b.getAttribute("data-fk"), c=store[k]; if(c){ clean(c); if(!c.dx&&!c.dy&&!c.w&&!c.h) delete store[k]; } save(store); }

    /* exact screen-px per 1 local-px (covers body zoom / any ancestor scale) */
    function probe(b,c){
      var t0=b.style.transform;
      var r0=b.getBoundingClientRect();
      b.style.transform="translate("+((c.dx||0)+100)+"px,"+(c.dy||0)+"px)";
      var r1=b.getBoundingClientRect();
      b.style.transform=t0;
      var f=(r1.left-r0.left)/100;
      return (f>0.05)?f:1;
    }
    /* natural (un-resized) size in local px, used to snap back to original size */
    function natSize(b,f){
      var sw=b.style.width,smw=b.style.minWidth,sxw=b.style.maxWidth,sh=b.style.height,smh=b.style.minHeight,sfl=b.style.flex;
      b.style.flex="";b.style.width="";b.style.minWidth="";b.style.maxWidth="";b.style.height="";b.style.minHeight="";
      var r=b.getBoundingClientRect();
      b.style.flex=sfl;b.style.width=sw;b.style.minWidth=smw;b.style.maxWidth=sxw;b.style.height=sh;b.style.minHeight=smh;
      return { w:r.width/f, h:r.height/f };
    }

    /* apply saved layout with no fly-in animation on load */
    (function(){
      for(var i=0;i<btns.length;i++){ btns[i].style.transition="none"; xform(btns[i], store[btns[i].getAttribute("data-fk")]||{}); }
      void document.body.offsetHeight;
      requestAnimationFrame(function(){ for(var i=0;i<btns.length;i++) btns[i].style.transition=""; });
    })();

    var drag=null, raf=0, lastEv=null;

    function onDown(ev){
      if(!document.body.classList.contains("editing")) return;
      var tgt=ev.target;
      var onHandle=!!(tgt && tgt.classList && tgt.classList.contains("free-rz"));
      var b=tgt && tgt.closest ? tgt.closest(".freebtn") : null;
      if(!b) return;
      ev.preventDefault(); ev.stopPropagation();
      var c=cfg(b); clean(c);
      b.style.transition="none";
      var f=probe(b,c);
      var rect=b.getBoundingClientRect();
      if(onHandle){
        drag={mode:"size", b:b, c:c, sx:ev.clientX, sy:ev.clientY, f:f, w0:rect.width/f, h0:rect.height/f, nat:natSize(b,f)};
        b.classList.add("sizing");
      } else {
        drag={mode:"move", b:b, c:c, sx:ev.clientX, sy:ev.clientY, dx0:(c.dx||0), dy0:(c.dy||0), f:f};
        b.classList.add("dragging");
      }
      window.addEventListener("mousemove", onMove, true);
      window.addEventListener("mouseup", onUp, true);
    }

    function apply(){
      raf=0; if(!drag||!lastEv) return;
      var c=drag.c, ev=lastEv;
      if(drag.mode==="move"){
        c.dx=drag.dx0+(ev.clientX-drag.sx)/drag.f;
        c.dy=drag.dy0+(ev.clientY-drag.sy)/drag.f;
      } else {
        var w=drag.w0+(ev.clientX-drag.sx)/drag.f;
        var h=drag.h0+(ev.clientY-drag.sy)/drag.f;
        if(w<MINW)w=MINW; if(w>MAXW)w=MAXW;
        if(h<MINH)h=MINH; if(h>MAXH)h=MAXH;
        c.w=w; c.h=h;
      }
      xform(drag.b, c);
    }
    function onMove(ev){ if(!drag) return; ev.preventDefault(); lastEv=ev; if(!raf) raf=requestAnimationFrame(apply); }

    function settle(b,c){
      if(drag && drag.mode==="size"){
        var nat=drag.nat;
        if(nat && Math.abs(c.w-nat.w)<=SZHOME && Math.abs(c.h-nat.h)<=SZHOME){ c.w=0; c.h=0; }
        else { c.w=Math.round(c.w/SZGRID)*SZGRID; c.h=Math.round(c.h/SZGRID)*SZGRID; }
      } else {
        var nx=Math.round(c.dx/GRID)*GRID, ny=Math.round(c.dy/GRID)*GRID;
        if(Math.abs(c.dx)<=HOME && Math.abs(c.dy)<=HOME){ nx=0; ny=0; }
        c.dx=nx; c.dy=ny;
      }
      b.style.transition="transform .16s cubic-bezier(.34,1.4,.5,1), width .16s cubic-bezier(.34,1.4,.5,1), height .16s cubic-bezier(.34,1.4,.5,1)";
      xform(b,c);
      setTimeout(function(){ b.style.transition=""; }, 190);
    }

    function onUp(){
      window.removeEventListener("mousemove", onMove, true);
      window.removeEventListener("mouseup", onUp, true);
      if(raf){ cancelAnimationFrame(raf); raf=0; }
      if(!drag) return;
      if(lastEv) apply();
      var b=drag.b;
      settle(b, drag.c);
      b.classList.remove("dragging"); b.classList.remove("sizing");
      persist(b); drag=null; lastEv=null;
    }
    document.addEventListener("mousedown", onDown, true);

    /* double-click resets a button's position + size (in edit mode) */
    document.addEventListener("dblclick", function(ev){
      if(!document.body.classList.contains("editing")) return;
      var b=ev.target && ev.target.closest ? ev.target.closest(".freebtn") : null;
      if(!b) return;
      ev.preventDefault(); ev.stopPropagation();
      delete store[b.getAttribute("data-fk")]; save(store);
      b.style.transition="transform .18s cubic-bezier(.34,1.4,.5,1), width .18s, height .18s";
      xform(b, {});
      setTimeout(function(){ b.style.transition=""; }, 220);
    }, true);

    /* while editing, a click on a button arranges it instead of firing its action */
    document.addEventListener("click", function(e){
      if(!document.body.classList.contains("editing")) return;
      var b=e.target && e.target.closest ? e.target.closest(".freebtn") : null;
      if(b){ e.stopPropagation(); e.preventDefault(); }
    }, true);

    /* Reset button (shown in edit mode): clear every size + position change */
    window.amResetFreeLayout=function(){
      store={}; save(store);
      for(var i=0;i<btns.length;i++){ (function(bb){
        bb.style.transition="transform .2s cubic-bezier(.34,1.4,.5,1), width .2s, height .2s";
        xform(bb,{});
        setTimeout(function(){ bb.style.transition=""; }, 240);
      })(btns[i]); }
    };
    var _rb=document.getElementById("freeReset");
    if(_rb) _rb.addEventListener("click", function(ev){ ev.stopPropagation(); if(window.amResetFreeLayout) window.amResetFreeLayout(); });
  })();

  /* ===== Edit mode: drag a WHOLE section by its title to reorder it in the tab ===== */
  (function(){
    var LSO="amanow_secorder";
    function oGet(){ try{ return JSON.parse(localStorage.getItem(LSO)||"{}")||{}; }catch(e){ return {}; } }
    function oSet(o){ try{ localStorage.setItem(LSO, JSON.stringify(o)); }catch(e){} }
    function sectionsIn(pane){ var out=[], ch=pane.children; for(var i=0;i<ch.length;i++){ if(ch[i].classList && ch[i].classList.contains("section")) out.push(ch[i]); } return out; }
    function paneKey(pane){ return pane.getAttribute("data-pane")||""; }

    /* remember the factory order so Reset can bring it back */
    var INIT={};
    (function(){ var panes=document.querySelectorAll(".tabpane"); for(var p=0;p<panes.length;p++){ var ids=[], L=sectionsIn(panes[p]); for(var i=0;i<L.length;i++){ var id=L[i].getAttribute("data-secid"); if(id) ids.push(id); } INIT[paneKey(panes[p])]=ids; } })();

    /* put every pane's sections into the order the person saved last time */
    (function(){
      var o=oGet(), panes=document.querySelectorAll(".tabpane");
      for(var p=0;p<panes.length;p++){
        var ids=o[paneKey(panes[p])]; if(!ids||!ids.length) continue;
        for(var i=0;i<ids.length;i++){
          var sec=panes[p].querySelector('.section[data-secid="'+ids[i]+'"]');
          if(sec) panes[p].appendChild(sec);
        }
      }
    })();

    function saveOrder(pane){
      var o=oGet(), ids=[], L=sectionsIn(pane);
      for(var i=0;i<L.length;i++){ var id=L[i].getAttribute("data-secid"); if(id) ids.push(id); }
      o[paneKey(pane)]=ids; oSet(o);
    }

    var drag=null, raf=0, lastY=0;
    function onDown(ev){
      if(!document.body.classList.contains("editing")) return;
      var t=ev.target;
      if(t.closest && (t.closest(".del-x")||t.closest(".freebtn")||t.closest("input")||t.closest("select"))) return;
      var title=t.closest ? t.closest(".section-title") : null; if(!title) return;
      var sec=title.closest(".section"); if(!sec) return;
      var pane=sec.parentNode; if(!pane||!pane.classList||!pane.classList.contains("tabpane")) return;
      ev.preventDefault(); ev.stopPropagation();
      drag={sec:sec, pane:pane};
      sec.classList.add("sec-drag");
      window.addEventListener("mousemove", onMove, true);
      window.addEventListener("mouseup", onUp, true);
    }
    function apply(){
      raf=0; if(!drag) return;
      var sec=drag.sec, pane=drag.pane, L=sectionsIn(pane);
      for(var i=0;i<L.length;i++){
        var s=L[i]; if(s===sec) continue;
        var r=s.getBoundingClientRect(); if(r.height<2) continue;          /* skip hidden sections */
        var mid=r.top+r.height/2, sr=sec.getBoundingClientRect();
        if(lastY<mid && sr.top>r.top){ pane.insertBefore(sec, s); break; }
        if(lastY>mid && sr.top<r.top){ pane.insertBefore(sec, s.nextSibling); break; }
      }
    }
    function onMove(ev){ if(!drag) return; ev.preventDefault(); lastY=ev.clientY; if(!raf) raf=requestAnimationFrame(apply); }
    function onUp(){
      window.removeEventListener("mousemove", onMove, true);
      window.removeEventListener("mouseup", onUp, true);
      if(raf){ cancelAnimationFrame(raf); raf=0; }
      if(!drag) return;
      drag.sec.classList.remove("sec-drag");
      saveOrder(drag.pane);
      drag=null;
    }
    document.addEventListener("mousedown", onDown, true);

    /* the pencil-bar Reset also restores the factory section order */
    window.amResetSecOrder=function(){
      oSet({});
      var panes=document.querySelectorAll(".tabpane");
      for(var p=0;p<panes.length;p++){
        var ids=INIT[paneKey(panes[p])]||[];
        for(var i=0;i<ids.length;i++){
          var sec=panes[p].querySelector('.section[data-secid="'+ids[i]+'"]');
          if(sec) panes[p].appendChild(sec);
        }
      }
    };
    var srb=document.getElementById("freeReset");
    if(srb) srb.addEventListener("click", function(){ if(window.amResetSecOrder) window.amResetSecOrder(); });
  })();


})();
