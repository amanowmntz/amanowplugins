/* Minimal CSInterface for evalScript bridge (AmanowTools CEP) */
function CSInterface() {}
CSInterface.prototype._cep = function(){ return (typeof window!=="undefined") ? window.__adobe_cep__ : null; };
CSInterface.prototype.evalScript = function (script, callback) {
    if (callback === null || callback === undefined) callback = function (r) {};
    var cep = this._cep();
    if (cep) { cep.evalScript(script, callback); }
    else { callback("EvalScript error: CEP not available."); }
};
CSInterface.prototype.getHostEnvironment = function () {
    var cep = this._cep();
    try { return JSON.parse(cep.getHostEnvironment()); } catch(e){ return {}; }
};
CSInterface.prototype.getApplicationID = function () {
    var env = this.getHostEnvironment(); return env ? env.appName : "";
};
CSInterface.prototype.openURLInDefaultBrowser = function (url) {
    try { return window.cep.util.openURLInDefaultBrowser(url); } catch(e){}
};
CSInterface.prototype.getSystemPath = function (pathType) {
    var cep = this._cep();
    try { return decodeURI(cep.getSystemPath(pathType)); } catch(e){ return ""; }
};
