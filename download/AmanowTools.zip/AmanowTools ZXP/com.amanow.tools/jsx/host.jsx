/* AmanowTools CEP host — Tools functions (ported 1:1, untouched logic) */

function isComp(it){ return it && (it instanceof CompItem); }
function actComp(){
    var c = app.project.activeItem;
    if (!isComp(c)) { alert("AmanowTools\n\nOpen a composition."); return null; }
    return c;
}
function alertU(m){ alert("AmanowTools\n\n" + m); }
function clampN(n,a,b){ return n<a?a:(n>b?b:n); }
function pnum(s,f){ var n=parseFloat(String(s).replace(",",".")); return isNaN(n)?f:n; }

function layerOfProp(p){ try{ return p.propertyGroup(p.propertyDepth); }catch(e){ return null; } }

function selectedKeyableProps(comp){
    var out=[]; var props=comp.selectedProperties;
    for(var i=0;i<props.length;i++){
        var p=props[i];
        if(p && p.canSetExpression!==undefined && p.numKeys>0){ out.push(p); }
    }
    return out;
}

// ---- EASE (curve control) ----
function easeKeyOn(prop, idx, inInf, outInf){
    var dims=1;
    try{ var v=prop.keyValue(idx); if(v instanceof Array) dims=v.length; }catch(e){}
    function arr(inf){ var a=[],d; for(d=0;d<dims;d++){ a.push(new KeyframeEase(0, clampN(inf,0.1,100))); } return a; }
    function currentIn(){
        try{ return prop.keyInTemporalEase(idx); }catch(e){}
        return arr(33);
    }
    function currentOut(){
        try{ return prop.keyOutTemporalEase(idx); }catch(e){}
        return arr(33);
    }
    try{ prop.setInterpolationTypeAtKey(idx, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); }catch(e1){}
    var inEase=(inInf===null)?currentIn():arr(inInf);
    var outEase=(outInf===null)?currentOut():arr(outInf);
    try{ prop.setTemporalEaseAtKey(idx, inEase, outEase); }
    catch(e2){
        try{
            prop.setTemporalEaseAtKey(
                idx,
                (inInf===null)?currentIn():[new KeyframeEase(0,clampN(inInf,0.1,100))],
                (outInf===null)?currentOut():[new KeyframeEase(0,clampN(outInf,0.1,100))]
            );
        }catch(e3){}
    }
}
function applyEase(mode, infl){
    var comp=actComp(); if(!comp) return;
    var targets=selectedKeyableProps(comp);
    if(targets.length===0){ alertU("Select keyframes (or a keyed property): Position, Scale, Opacity, etc."); return; }
    var inI = (mode==="out") ? null : infl;
    var outI= (mode==="in")  ? null : infl;
    app.beginUndoGroup("AmanowTools Ease");
    for(var i=0;i<targets.length;i++){
        var p=targets[i];
        var keys=[]; var sel=p.selectedKeys;
        if(sel && sel.length>0){ keys=sel; } else { for(var k=1;k<=p.numKeys;k++) keys.push(k); }
        for(var j=0;j<keys.length;j++){ easeKeyOn(p, keys[j], inI, outI); }
    }
    app.endUndoGroup();
}
function setKeyShape(kind){
    var comp=actComp(); if(!comp) return;
    var targets=selectedKeyableProps(comp);
    if(targets.length===0){ alertU("Select keyframes or animated properties."); return; }
    app.beginUndoGroup("AmanowTools Key Shape");
    for(var i=0;i<targets.length;i++){
        var p=targets[i];
        var keys=[]; var sel=p.selectedKeys;
        if(sel && sel.length>0){ keys=sel; } else { for(var k=1;k<=p.numKeys;k++) keys.push(k); }
        for(var j=0;j<keys.length;j++){
            var idx=keys[j];
            try{
                if(kind==="square"){
                    p.setInterpolationTypeAtKey(idx,KeyframeInterpolationType.HOLD,KeyframeInterpolationType.HOLD);
                }else if(kind==="circle"){
                    p.setInterpolationTypeAtKey(idx,KeyframeInterpolationType.BEZIER,KeyframeInterpolationType.BEZIER);
                    easeKeyOn(p,idx,50,50);
                    try{ p.setTemporalContinuousAtKey(idx,true); }catch(e1){}
                    try{ p.setTemporalAutoBezierAtKey(idx,true); }catch(e2){}
                    try{ p.setSpatialContinuousAtKey(idx,true); }catch(e3){}
                    try{ p.setSpatialAutoBezierAtKey(idx,true); }catch(e4){}
                    try{ if(idx>1 && idx<p.numKeys) p.setRovingAtKey(idx,true); }catch(e5){}
                }else{
                    p.setInterpolationTypeAtKey(idx,KeyframeInterpolationType.LINEAR,KeyframeInterpolationType.LINEAR);
                }
            }catch(e){}
        }
    }
    app.endUndoGroup();
}

// ---- ANCHOR 3x3 ----
function setAnchorGrid(gx, gy){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers;
    if(sel.length===0){ alertU("Select layer(s)."); return; }
    app.beginUndoGroup("AmanowTools Anchor");
    for(var i=0;i<sel.length;i++){
        var L=sel[i];
        try{
            var r=L.sourceRectAtTime(comp.time,false);
            var ap=L.property("ADBE Transform Group").property("ADBE Anchor Point");
            var pp=L.property("ADBE Transform Group").property("ADBE Position");
            var sc=L.property("ADBE Transform Group").property("ADBE Scale").value;
            var oldA=ap.value, oldP=pp.value;
            var nx=r.left+r.width*gx, ny=r.top+r.height*gy;
            var dx=(nx-oldA[0])*(sc[0]/100), dy=(ny-oldA[1])*(sc[1]/100);
            if(oldA.length>2){ ap.setValue([nx,ny,oldA[2]]); } else { ap.setValue([nx,ny]); }
            if(oldP.length>2){ pp.setValue([oldP[0]+dx,oldP[1]+dy,oldP[2]]); } else { pp.setValue([oldP[0]+dx,oldP[1]+dy]); }
        }catch(e){}
    }
    app.endUndoGroup();
}

// ---- ELASTIC / BOUNCE ----
function ensureSlider(layer,name,val){
    var fx=layer.property("ADBE Effect Parade");
    var ex=null;
    try{ ex=fx.property(name); }catch(e){}
    if(!ex){ ex=fx.addProperty("ADBE Slider Control"); ex.name=name; ex.property(1).setValue(val); }
    return ex;
}
function elasticExpr(){
    return 'amp = effect("Amplitude")(1)/100;\n'+
    'freq = effect("Frequency")(1);\n'+
    'decay = effect("Decay")(1)/10;\n'+
    'n = 0;\n'+
    'if (numKeys > 0){ n = nearestKey(time).index; if (key(n).time > time) n--; }\n'+
    'if (n > 0){\n'+
    '  t = time - key(n).time;\n'+
    '  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n'+
    '  f = amp*Math.sin(t*freq*Math.PI*2)/Math.exp(t*decay)/Math.max(0.001,freq);\n'+
    '  value + v*f;\n'+
    '} else { value }';
}
function bounceExpr(){
    return 'amp = effect("Amplitude")(1)/100;\n'+
    'freq = effect("Frequency")(1);\n'+
    'decay = effect("Decay")(1)/10;\n'+
    'n = 0;\n'+
    'if (numKeys > 0){ n = nearestKey(time).index; if (key(n).time > time) n--; }\n'+
    'if (n > 0){\n'+
    '  t = time - key(n).time;\n'+
    '  v = velocityAtTime(key(n).time - thisComp.frameDuration/10);\n'+
    '  f = amp*Math.abs(Math.sin(t*freq*Math.PI*2))/Math.exp(t*decay)/Math.max(0.001,freq);\n'+
    '  value - v*f;\n'+
    '} else { value }';
}
function applyMotion(kind){
    var comp=actComp(); if(!comp) return;
    var targets=selectedKeyableProps(comp);
    if(targets.length===0){ alertU("Select a keyed property (Position, Scale, Rotation...)."); return; }
    app.beginUndoGroup("AmanowTools "+kind);
    for(var i=0;i<targets.length;i++){
        var p=targets[i]; var L=layerOfProp(p); if(!L) continue;
        try{
            ensureSlider(L,"Amplitude",20);
            ensureSlider(L,"Frequency",4);
            ensureSlider(L,"Decay",60);
            if(kind==="Elastic"){
                p.expression=elasticExpr();
            } else {
                p.expression=bounceExpr();
            }
        }catch(e){}
    }
    app.endUndoGroup();
}

// ---- SEQUENCE ----
function sequenceLayers(offsetFrames, keepCount, mode){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers.slice(0);
    if(sel.length<2){ alertU("Select 2+ layers to sequence."); return; }
    sel.sort(function(a,b){ return a.index-b.index; });
    var fd=comp.frameDuration;
    var keep=Math.max(0,Math.min(sel.length,Math.round(keepCount)));
    var affected=sel.slice(0, Math.max(0, sel.length-keep));
    if(affected.length===0){ alertU("Step leaves no layer to move."); return; }
    var off=offsetFrames*fd;
    app.beginUndoGroup("AmanowTools Sequence");
    for(var i=0;i<affected.length;i++){
        var dir=1;
        if(mode==="left") dir=-1;
        else if(mode==="center"){
            var mid=(affected.length-1)/2;
            if(i===mid){ dir=0; }
            else { dir=(i<mid)?-1:1; }
        }
        var mult=(affected.length-i);
        if(mode==="center"){
            var dist=Math.abs(i-((affected.length-1)/2));
            mult=Math.max(1, Math.round(dist+0.5));
        }
        try{ affected[i].startTime += off*mult*dir; }catch(e){}
    }
    app.endUndoGroup();
}


/* ===================== CREATE MODULE (ported 1:1) ===================== */
function deselectAll(comp){ for(var i=1;i<=comp.numLayers;i++) comp.layer(i).selected=false; }

// ---- LIQUID GLASS ----
function setMatteSolid(shapeLayer){
    // make alpha = full rounded rect: fill opacity 100, stroke opacity 0
    try{
        var root=shapeLayer.property("ADBE Root Vectors Group");
        for(var i=1;i<=root.numProperties;i++){
            var grp=root.property(i);
            var vs=null; try{ vs=grp.property("ADBE Vectors Group"); }catch(e){}
            if(!vs) continue;
            for(var j=1;j<=vs.numProperties;j++){
                var p=vs.property(j);
                if(p.matchName==="ADBE Vector Graphic - Fill"){ p.property("ADBE Vector Fill Color").setValue([1,1,1]); p.property("ADBE Vector Fill Opacity").setValue(100); }
                if(p.matchName==="ADBE Vector Graphic - Stroke"){ p.property("ADBE Vector Stroke Opacity").setValue(0); }
            }
        }
    }catch(e){}
}
function createLiquidGlass(){
    var comp=actComp(); if(!comp) return;
    app.beginUndoGroup("AmanowTools Glass");
    try{
        var W=comp.width, H=comp.height;
        var gw=Math.round(W*0.55), gh=Math.round(H*0.30);
        var rad=Math.round(Math.min(gw,gh)*0.22);
        var cx=W/2, cy=H/2;
        function uniqLayerName(c,b){ var ex=function(nm){ for(var k=1;k<=c.numLayers;k++){ if(c.layer(k).name===nm) return true; } return false; }; if(!ex(b)) return b; var n=2; while(ex(b+" "+n)) n++; return b+" "+n; }
        var baseName=uniqLayerName(comp,"AM Liquid Glass");
        var suffix=baseName.substr("AM Liquid Glass".length);

        // 1) MAIN (visible) — serves as the Stroke / glass edge; holds the master Rectangle Path
        var glass=comp.layers.addShape(); glass.name=baseName;
        var root=glass.property("ADBE Root Vectors Group");
        var grp=root.addProperty("ADBE Vector Group"); grp.name="Glass";
        var vs=grp.property("ADBE Vectors Group");
        var rect=vs.addProperty("ADBE Vector Shape - Rect"); rect.name="Rectangle Path 1";
        rect.property("ADBE Vector Rect Size").setValue([gw,gh]);
        rect.property("ADBE Vector Rect Roundness").setValue(rad);
        var fill=vs.addProperty("ADBE Vector Graphic - Fill");
        fill.property("ADBE Vector Fill Color").setValue([1,1,1]);
        fill.property("ADBE Vector Fill Opacity").setValue(0);
        var stroke=vs.addProperty("ADBE Vector Graphic - Stroke");
        stroke.property("ADBE Vector Stroke Color").setValue([1,1,1]);
        stroke.property("ADBE Vector Stroke Opacity").setValue(60);
        stroke.property("ADBE Vector Stroke Width").setValue(2);
        glass.property("ADBE Transform Group").property("ADBE Position").setValue([cx,cy]);
        // glass-edge effects: Bevel Alpha + Fast Box Blur
        var gfx=glass.property("ADBE Effect Parade");
        var bev=null; try{ bev=gfx.addProperty("ADBE Bevel Alpha"); }catch(e){}
        if(bev){ try{ bev.property(1).setValue(91.8); }catch(e){} try{ bev.property(2).setValue(-60); }catch(e){} try{ bev.property(4).setValue(1); }catch(e){} }
        var sfb=null; try{ sfb=gfx.addProperty("ADBE Box Blur2"); }catch(e){}
        if(sfb){ try{ sfb.property(1).setValue(1); }catch(e){} try{ sfb.property(2).setValue(3); }catch(e){} try{ sfb.property(4).setValue(1); }catch(e){} }

        // 2) MATTE: full-alpha rounded rect; its rect is LINKED to the main rect (resize together)
        var matte=glass.duplicate(); matte.name="AM Glass Matte"+suffix;
        try{ var mfx=matte.property("ADBE Effect Parade"); for(var mi=mfx.numProperties;mi>=1;mi--) mfx.property(mi).remove(); }catch(e){}
        setMatteSolid(matte);
        try{
            var mg=matte.property("ADBE Root Vectors Group").property(1).property("ADBE Vectors Group");
            var mrect=null;
            for(var k=1;k<=mg.numProperties;k++){ if(mg.property(k).matchName==="ADBE Vector Shape - Rect"){ mrect=mg.property(k); break; } }
            if(mrect){
                var Ln=baseName.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
                var ref='thisComp.layer("'+Ln+'").content("Glass").content("Rectangle Path 1")';
                mrect.property("ADBE Vector Rect Size").expression=ref+'.size';
                mrect.property("ADBE Vector Rect Roundness").expression=ref+'.roundness';
                mrect.property("ADBE Vector Rect Position").expression=ref+'.position';
            }
        }catch(eL){}

        // 3) BLUR: adjustment layer with glass effect stack
        var adj=comp.layers.addSolid([0,0,0],"AM Glass Blur"+suffix,W,H,1);
        adj.adjustmentLayer=true;
        var fxp=adj.property("ADBE Effect Parade");
        var bc=null; try{ bc=fxp.addProperty("ADBE Brightness & Contrast 2"); }catch(e){}
        if(bc){ try{ bc.property(1).setValue(10); bc.property(2).setValue(41); }catch(e){} }
        var fbb=null; try{ fbb=fxp.addProperty("ADBE Box Blur2"); }catch(e){}
        if(fbb){ try{ fbb.property(1).setValue(9); }catch(e){} try{ fbb.property(2).setValue(1); }catch(e){} try{ fbb.property(4).setValue(1); }catch(e){} }
        var td=null; try{ td=fxp.addProperty("ADBE Turbulent Displace"); }catch(e){}
        if(td){ try{ td.property(1).setValue(1); }catch(e){} try{ td.property(2).setValue(-8); }catch(e){} try{ td.property(3).setValue(564); }catch(e){} try{ td.property(5).setValue(1); }catch(e){} }
        var gl=null; try{ gl=fxp.addProperty("ADBE Glo2"); }catch(e1){ try{ gl=fxp.addProperty("ADBE Glow"); }catch(e2){} }
        if(gl){ try{ gl.property(1).setValue(2); }catch(e){} try{ gl.property(2).setValue(39.1); }catch(e){} try{ gl.property(3).setValue(259); }catch(e){} try{ gl.property(4).setValue(0.1); }catch(e){} }

        // order: main (top) / matte / blur ; matte alpha-mattes the blur
        matte.moveBefore(adj);
        glass.moveBefore(matte);
        var ok=false;
        try{ adj.setTrackMatte(matte, TrackMatteType.ALPHA); ok=true; }catch(e){}
        if(!ok){ try{ adj.trackMatteType=TrackMatteType.ALPHA; }catch(e){} }
        // parent matte + blur to main, so moving/resizing the main moves the whole glass
        try{ matte.parent=glass; }catch(e){}
        try{ adj.parent=glass; }catch(e){}
        try{ adj.setTrackMatte(matte, TrackMatteType.ALPHA); }catch(e){}
        try{ adj.adjustmentLayer=true; }catch(e){}

        deselectAll(comp); glass.selected=true;
    }catch(err){ alert("Glass error:\n"+err.toString()); }
    app.endUndoGroup();
}

// ---- TEXT BOX (from ShapeBox) ----
function isTextLayer(layer){ return layer && layer.property("ADBE Text Properties")!==null; }
function safeSet(prop,val){ try{ if(prop!==null&&prop!==undefined) prop.setValue(val); }catch(e){} }
function createTextBox(roundness){
    var comp=actComp(); if(!comp) return;
    var selected=comp.selectedLayers, textLayers=[];
    for(var i=0;i<selected.length;i++){ if(isTextLayer(selected[i])) textLayers.push(selected[i]); }
    if(textLayers.length===0){ alertU("Select one or more text layers."); return; }
    app.beginUndoGroup("AmanowTools Text Box");
    var made=0;
    for(var s=0;s<textLayers.length;s++){
        var textLayer=textLayers[s];
        try{
            var box=comp.layers.addShape(); box.name="AM Text Box";
            box.inPoint=textLayer.inPoint; box.outPoint=textLayer.outPoint;
            box.moveAfter(textLayer); box.parent=textLayer;
            var tr=box.property("ADBE Transform Group");
            safeSet(tr.property("ADBE Anchor Point"),[0,0]);
            safeSet(tr.property("ADBE Scale"),[100,100]);
            safeSet(tr.property("ADBE Rotate Z"),0);
            tr.property("ADBE Position").expression='t=thisLayer.parent;r=t.sourceRectAtTime(time,false);[r.left+r.width/2,r.top+r.height/2];';
            var contents=box.property("ADBE Root Vectors Group");
            var rect=contents.addProperty("ADBE Vector Shape - Rect");
            rect.name="Auto Box";
            rect.property("ADBE Vector Rect Roundness").setValue(roundness);
            rect.property("ADBE Vector Rect Size").expression='t=thisLayer.parent;r=t.sourceRectAtTime(time,false);px=34;py=16;[Math.max(r.width+px*2,24),Math.max(r.height+py*2,18)];';
            var fill=contents.addProperty("ADBE Vector Graphic - Fill"); fill.name="Fill";
            fill.property("ADBE Vector Fill Color").setValue([0.48,0.45,1.0]);
            fill.property("ADBE Vector Fill Opacity").setValue(100);
            var stroke=contents.addProperty("ADBE Vector Graphic - Stroke"); stroke.name="Stroke";
            stroke.property("ADBE Vector Stroke Color").setValue([1,1,1]);
            stroke.property("ADBE Vector Stroke Width").setValue(4);
            made++;
        }catch(err){}
    }
    deselectAll(comp);
    for(var r=0;r<textLayers.length;r++){ try{ textLayers[r].selected=true; }catch(e){} }
    app.endUndoGroup();
    if(made===0) alertU("Text Box error: no boxes were created.");
}

// ---- DOTTED LINE (from Dotted Line Shape) ----
var AM_DOT_TAG="AMANOW_DOTTED_LINE_SHAPE_BOX";
function addSliderTo(layer,name,value){ var fx=layer.property("ADBE Effect Parade").addProperty("ADBE Slider Control"); fx.name=name; fx.property(1).setValue(value); return fx; }
function createDottedBox(){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers;
    if(sel.length===0){ alertU("Select a text layer."); return; }
    app.beginUndoGroup("AmanowTools Dotted Line");
    var made=0;
    for(var s=0;s<sel.length;s++){
        var textLayer=sel[s];
        if(!isTextLayer(textLayer)) continue;
        try{
            var box=comp.layers.addShape(); box.name="AM Dotted Box";
            box.comment=AM_DOT_TAG+" | "+textLayer.name; box.label=10; box.parent=textLayer;
            box.inPoint=textLayer.inPoint; box.outPoint=textLayer.outPoint;
            box.moveAfter(textLayer);
            var tg=box.property("ADBE Transform Group");
            safeSet(tg.property("ADBE Anchor Point"),[0,0]);
            safeSet(tg.property("ADBE Scale"),[100,100]);
            safeSet(tg.property("ADBE Rotate Z"),0);
            tg.property("ADBE Position").expression='t=thisLayer.parent;r=t.sourceRectAtTime(time,false);[r.left+r.width/2,r.top+r.height/2];';
            addSliderTo(box,"Padding X",42); addSliderTo(box,"Padding Y",24);
            addSliderTo(box,"Stroke Width",3); addSliderTo(box,"Dash",18); addSliderTo(box,"Gap",12);
            var contents=box.property("ADBE Root Vectors Group");
            var border=contents.addProperty("ADBE Vector Group"); border.name="Dotted Border";
            var bv=border.property("ADBE Vectors Group");
            var rp=bv.addProperty("ADBE Vector Shape - Rect");
            rp.property("ADBE Vector Rect Position").setValue([0,0]);
            rp.property("ADBE Vector Rect Size").expression='t=thisLayer.parent;r=t.sourceRectAtTime(time,false);px=Math.max(0,effect("Padding X")("Slider"));py=Math.max(0,effect("Padding Y")("Slider"));[Math.max(r.width+px*2,24),Math.max(r.height+py*2,18)];';
            var stroke=bv.addProperty("ADBE Vector Graphic - Stroke");
            stroke.property("ADBE Vector Stroke Color").setValue([1,1,1]);
            stroke.property("ADBE Vector Stroke Width").expression='Math.max(1,effect("Stroke Width")("Slider"))';
            try{ stroke.property("ADBE Vector Stroke Line Cap").setValue(1); }catch(e){}
            var dashes=stroke.property("ADBE Vector Stroke Dashes");
            try{
                dashes.addProperty("ADBE Vector Stroke Dash 1"); dashes.addProperty("ADBE Vector Stroke Gap 1");
                dashes.property("ADBE Vector Stroke Dash 1").expression='Math.max(1,effect("Dash")("Slider"))';
                dashes.property("ADBE Vector Stroke Gap 1").expression='Math.max(1,effect("Gap")("Slider"))';
            }catch(e){}
            box.selected=true; textLayer.selected=false; made++;
        }catch(e){}
    }
    app.endUndoGroup();
    if(made===0) alertU("No text layer found. Select a Text Layer.");
}

// ---- HANDLES (from Text Handles) ----
var AM_HND_MARK="AMANOW_TEXT_HANDLES_PANEL";
function findHandles(comp,textLayer){
    var tag=AM_HND_MARK+"::"+textLayer.name;
    for(var i=1;i<=comp.numLayers;i++){ if(comp.layer(i).comment===tag) return comp.layer(i); }
    return null;
}
function createHandles(size, color){
    var comp=actComp(); if(!comp) return null;
    if(comp.selectedLayers.length!==1 || !isTextLayer(comp.selectedLayers[0])){ alertU("Select one text layer."); return null; }
    var textLayer=comp.selectedLayers[0];
    var old=findHandles(comp,textLayer); if(old){ deselectAll(comp); old.selected=true; return old; }
    var textName=textLayer.name.replace(/\\/g,"\\\\").replace(/"/g,'\\"');
    var hl=comp.layers.addShape(); hl.name="AM Text Handles";
    hl.comment=AM_HND_MARK+"::"+textLayer.name;
    hl.inPoint=textLayer.inPoint; hl.outPoint=textLayer.outPoint;
    hl.moveBefore(textLayer);
    var tr=hl.property("ADBE Transform Group");
    tr.property("ADBE Anchor Point").setValue([0,0]); tr.property("ADBE Position").setValue([0,0]);
    var contents=hl.property("ADBE Root Vectors Group");
    var pts=[[0,0],[0.5,0],[1,0],[0,0.5],[1,0.5],[0,1],[0.5,1],[1,1]];
    for(var i=0;i<pts.length;i++){
        var grp=contents.addProperty("ADBE Vector Group"); grp.name="H"+i;
        var gc=grp.property("ADBE Vectors Group");
        var rect=gc.addProperty("ADBE Vector Shape - Rect");
        rect.property("ADBE Vector Rect Size").setValue([size,size]);
        var fill=gc.addProperty("ADBE Vector Graphic - Fill");
        fill.property("ADBE Vector Fill Color").setValue(color);
        grp.property("ADBE Vector Transform Group").property("ADBE Vector Position").expression=
            't=thisComp.layer("'+textName+'");r=t.sourceRectAtTime(time,false);p=t.toComp([r.left+r.width*'+pts[i][0]+',r.top+r.height*'+pts[i][1]+']);[p[0],p[1]];';
    }
    deselectAll(comp); hl.selected=true; return hl;
}

// ---- QUICK CREATE ----
function quickCreate(kind){
    var comp=actComp(); if(!comp) return;
    app.beginUndoGroup("AmanowTools Create "+kind);
    try{
        var L=null;
        if(kind==="Null2D"){ L=comp.layers.addNull(); L.name="Null 2D"; }
        else if(kind==="Null3D"){ L=comp.layers.addNull(); L.name="Null 3D"; L.threeDLayer=true; }
        else if(kind==="Solid"){ L=comp.layers.addSolid([0.5,0.5,0.5],"Solid",comp.width,comp.height,1); }
        else if(kind==="Shape"){ L=comp.layers.addShape(); L.name="Shape"; }
        else if(kind==="Adjustment"){ L=comp.layers.addSolid([1,1,1],"Adjustment",comp.width,comp.height,1); L.adjustmentLayer=true; }
        else if(kind==="Camera"){ L=comp.layers.addCamera("Camera",[comp.width/2,comp.height/2]); }
        if(L){ deselectAll(comp); L.selected=true; }
    }catch(err){ alert("Create error:\n"+err.toString()); }
    app.endUndoGroup();
}


/* ---------- TEXT ANIMATOR (logic from LMTv2) ---------- */

function findHandles2(comp){
    for(var i=1;i<=comp.numLayers;i++){
        var L=comp.layer(i);
        if(L.comment && L.comment.indexOf(AM_HND_MARK)===0) return L;
    }
    return null;
}


/* ===================== TEXT MODULE (ported 1:1) ===================== */
/* ---------- TEXT ANIMATOR (logic from LMTv2) ---------- */
function ta_focusTimeline(){
    try{
        var comp=app.project.activeItem;
        if(!(comp instanceof CompItem)) return;
        if(comp.selectedLayers.length===0) return;
        var layer=comp.selectedLayers[0];
        comp.openInViewer(); app.executeCommand(2771);
        var idx=layer.index;
        for(var i=1;i<=comp.numLayers;i++) comp.layer(i).selected=false;
        app.scheduleTask("try{var c=app.project.activeItem;if(c instanceof CompItem){var l=c.layer("+idx+");if(l){l.selected=true;c.openInViewer();app.executeCommand(2771);}}}catch(e){}",50,false);
    }catch(err){}
}
function ta_after(layer){
    try{
        var comp=app.project.activeItem; if(!(comp instanceof CompItem)) return;
        for(var i=1;i<=comp.numLayers;i++) comp.layer(i).selected=false;
        layer.selected=true; ta_focusTimeline();
    }catch(e){}
}
function ta_needLayer(){
    var comp=app.project.activeItem;
    if(!(comp instanceof CompItem)){ alertU("Open a composition."); return null; }
    if(comp.selectedLayers.length===0){ alertU("Select a text layer."); return null; }
    return comp.selectedLayers[0];
}
function ta_addCustom(layer, posValue, blurValue, basedOn, shapeValue, easeHigh, easeLow, randomize, startT, endT){
    var animators=layer.property("ADBE Text Properties").property("ADBE Text Animators");
    var animator=animators.addProperty("ADBE Text Animator");
    var selector=animator.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
    var props=animator.property("ADBE Text Animator Properties");
    props.addProperty("ADBE Text Position 3D").setValue(posValue);
    props.addProperty("ADBE Text Opacity").setValue(0);
    props.addProperty("ADBE Text Blur").setValue(blurValue);
    var offset=selector.property("ADBE Text Percent Offset");
    offset.setValueAtTime(startT,-100); offset.setValueAtTime(endT,100);
    var adv=selector.property("ADBE Text Range Advanced");
    adv.property("ADBE Text Range Type2").setValue(basedOn);
    adv.property("ADBE Text Range Type").setValue(shapeValue);
    adv.property("ADBE Text Levels Max Ease").setValue(easeHigh);
    adv.property("ADBE Text Levels Min Ease").setValue(easeLow);
    if(randomize) adv.property("ADBE Text Randomize Order").setValue(true);
}
function ta_create(posValue, blurValue, basedOn, easeHigh, easeLow, randomize, scaleValue){
    var layer=ta_needLayer(); if(!layer) return;
    app.beginUndoGroup("Text Animator");
    var comp=app.project.activeItem; var t=comp.time;
    var animators=layer.property("ADBE Text Properties").property("ADBE Text Animators");
    var animator=animators.addProperty("ADBE Text Animator");
    var selector=animator.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
    var props=animator.property("ADBE Text Animator Properties");
    props.addProperty("ADBE Text Position 3D").setValue(posValue);
    if(scaleValue) props.addProperty("ADBE Text Scale 3D").setValue(scaleValue);
    props.addProperty("ADBE Text Opacity").setValue(0);
    props.addProperty("ADBE Text Blur").setValue(blurValue);
    var offset=selector.property("ADBE Text Percent Offset");
    offset.setValueAtTime(t,-100); offset.setValueAtTime(t+2,100);
    var adv=selector.property("ADBE Text Range Advanced");
    adv.property("ADBE Text Range Type2").setValue(basedOn);
    adv.property("ADBE Text Range Type").setValue(2);
    adv.property("ADBE Text Levels Max Ease").setValue(easeHigh);
    adv.property("ADBE Text Levels Min Ease").setValue(easeLow);
    if(randomize) adv.property("ADBE Text Randomize Order").setValue(true);
    app.endUndoGroup(); ta_after(layer);
}
function ta_doubleUpDown(basedOn, randomize){
    var layer=ta_needLayer(); if(!layer) return;
    app.beginUndoGroup("Text Animator UpDown");
    var comp=app.project.activeItem; var t=comp.time;
    if(randomize){
        ta_addCustom(layer,[0,100],[15,15],basedOn,2,-50,100,true,t,t+2);
        ta_addCustom(layer,[0,100],[15,15],basedOn,3,-50,100,true,t+1,t+3);
    } else {
        ta_addCustom(layer,[0,100],[15,15],basedOn,2,-50,100,false,t,t+2);
        ta_addCustom(layer,[0,100],[15,15],basedOn,3,-50,100,false,t,t+2);
    }
    app.endUndoGroup(); ta_after(layer);
}
function ta_leftRight(basedOn){
    var layer=ta_needLayer(); if(!layer) return;
    app.beginUndoGroup("Text Animator LeftRight");
    var comp=app.project.activeItem; var t=comp.time;
    ta_addCustom(layer,[100,0,0],[10,10],basedOn,2,-50,100,false,t,t+2);
    ta_addCustom(layer,[-100,0,0],[10,10],basedOn,3,-50,100,false,t,t+2);
    app.endUndoGroup(); ta_after(layer);
}
function ta_glitch(shapeValue){
    var layer=ta_needLayer(); if(!layer) return;
    app.beginUndoGroup("Glitch Animator");
    var animators=layer.property("ADBE Text Properties").property("ADBE Text Animators");
    var animator=animators.addProperty("ADBE Text Animator");
    var selector=animator.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
    var props=animator.property("ADBE Text Animator Properties");
    var blur=props.addProperty("ADBE Text Blur");
    try{ blur.setValue([0,0,0]); }catch(e){ try{ blur.setValue([0,0]); }catch(e2){} }
    blur.expression="wiggle(7,100)";
    var adv=selector.property("ADBE Text Range Advanced");
    adv.property("ADBE Text Range Type2").setValue(1); adv.property("ADBE Text Range Type").setValue(shapeValue);
    adv.property("ADBE Text Levels Max Ease").setValue(0); adv.property("ADBE Text Levels Min Ease").setValue(0);
    app.endUndoGroup(); ta_after(layer);
}
function ta_clear(){
    var layer=ta_needLayer(); if(!layer) return;
    app.beginUndoGroup("Clear Animators");
    var animators=layer.property("ADBE Text Properties").property("ADBE Text Animators");
    for(var i=animators.numProperties;i>=1;i--) animators.property(i).remove();
    app.endUndoGroup(); ta_after(layer);
}
function ta_srcText(layer){ try{ var tp=layer.property("ADBE Text Properties"); return tp?tp.property("ADBE Text Document"):null; }catch(e){ return null; } }
function ta_setText(layer,val,forceLeft){
    var p=ta_srcText(layer); var td=p.value; td.text=val;
    if(forceLeft){ try{ td.justification=ParagraphJustification.LEFT_JUSTIFY; }catch(e){} }
    p.setValue(td);
}
function ta_measure(measureLayer,val,time){
    ta_setText(measureLayer,val+"|",true); var r1=measureLayer.sourceRectAtTime(time,false);
    ta_setText(measureLayer,"|",true); var r2=measureLayer.sourceRectAtTime(time,false);
    return r1.width-r2.width;
}
function ta_splitWords(){
    var comp=app.project.activeItem;
    if(!(comp instanceof CompItem)){ alertU("Open a composition."); return; }
    if(comp.selectedLayers.length!==1){ alertU("Select one text layer."); return; }
    var layer=comp.selectedLayers[0];
    if(!ta_srcText(layer)){ alertU("Not a text layer."); return; }
    app.beginUndoGroup("Split Text To Words");
    var full=ta_srcText(layer).value.text;
    var matches=[], re=/\S+/g, m;
    while((m=re.exec(full))!==null){ matches.push({word:m[0],index:m.index}); }
    if(matches.length<2){ alertU("Need at least 2 words."); app.endUndoGroup(); return; }
    var time=comp.time;
    var oRect=layer.sourceRectAtTime(time,false);
    var oTr=layer.property("ADBE Transform Group");
    var oAnchorY=oTr.property("ADBE Anchor Point").value[1];
    var oPosY=oTr.property("ADBE Position").value[1];
    var ml=layer.duplicate(); ml.enabled=false; ml.shy=true;
    ta_setText(ml,full,true);
    var news=[];
    for(var i=0;i<matches.length;i++){
        var word=matches[i].word, startIndex=matches[i].index, prefix=full.substring(0,startIndex);
        var prefixW=ta_measure(ml,prefix,time);
        var wordLeft=oRect.left+prefixW;
        var nl=layer.duplicate(); nl.name=word; ta_setText(nl,word,true);
        var nRect=nl.sourceRectAtTime(time,false);
        var tr=nl.property("ADBE Transform Group");
        var anchorX=nRect.left+nRect.width/2;
        var centerX=wordLeft+nRect.width/2;
        var compX=layer.sourcePointToComp([centerX,oRect.top])[0];
        var oa=tr.property("ADBE Anchor Point").value, op=tr.property("ADBE Position").value;
        if(oa.length===2){ tr.property("ADBE Anchor Point").setValue([anchorX,oAnchorY]); } else { tr.property("ADBE Anchor Point").setValue([anchorX,oAnchorY,oa[2]]); }
        if(op.length===2){ tr.property("ADBE Position").setValue([compX,oPosY]); } else { tr.property("ADBE Position").setValue([compX,oPosY,op[2]]); }
        news.push(nl);
    }
    ml.remove(); layer.enabled=false;
    for(var k=0;k<news.length;k++) news[k].selected=true;
    app.endUndoGroup(); ta_focusTimeline();
}
function ta_typing(){
    var layer=ta_needLayer(); if(!layer) return;
    if(!ta_srcText(layer)){ alertU("Not a text layer."); return; }
    app.beginUndoGroup("Typing Cursor");
    var comp=app.project.activeItem;
    var effects=layer.property("ADBE Effect Parade");
    var animp=effects.addProperty("ADBE Slider Control"); animp.name="Animation";
    animp.property(1).setValueAtTime(comp.time,0); animp.property(1).setValueAtTime(comp.time+2,100);
    var cs=effects.addProperty("ADBE Slider Control"); cs.name="Cursor Shape"; cs.property(1).setValue(1);
    var co=effects.addProperty("ADBE Checkbox Control"); co.name="Cursor On/Off"; co.property(1).setValue(1);
    var bs=effects.addProperty("ADBE Slider Control"); bs.name="Cursor Blink Speed"; bs.property(1).setValue(4);
    ta_srcText(layer).expression=
'var t=text.sourceText;var l=t.length;var a=effect("Animation")(1);var c=["|","_","-","<",">","[","]","^"];var d=effect("Cursor Shape")(1).value;var reveal=t.slice(0,l*linear(a,0,100,0,1));reveal+c[d-1];';
    var animators=layer.property("ADBE Text Properties").property("ADBE Text Animators");
    var animator=animators.addProperty("ADBE Text Animator"); animator.name="Cursor Blink";
    var selector=animator.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
    selector.property("ADBE Text Range Type2").setValue(1);
    selector.property("ADBE Text Expressible Amount").expression="textIndex === textTotal ? 100 : 0;";
    var op=animator.property("ADBE Text Animator Properties").addProperty("ADBE Text Opacity");
    op.expression=
'var showCursor=effect("Cursor On/Off")(1);var blinkSpeed=effect("Cursor Blink Speed")(1);var animProp=effect("Animation")(1);var nk=animProp.nearestKey(time);var pk=Math.max(nk.index-(nk.time>time),1);var blink=Math.sin(Math.PI*(time-animProp.key(pk).time)*blinkSpeed);var tp=text.sourceText;var isTyping=(time>animProp.key(1).time && tp.valueAtTime(time-thisComp.frameDuration*5)!==tp.valueAtTime(time) && time<animProp.key(animProp.numKeys).time);if(showCursor==1){if(isTyping){100;}else{(blink>=0)*100;}}else{0;}';
    app.endUndoGroup(); ta_after(layer);
}

/* ---------- COUNTER (from Counter_PRO) ---------- */
function ct_isText(layer){ try{ return layer && layer.property("ADBE Text Properties") && layer.property("ADBE Text Properties").property("ADBE Text Document"); }catch(e){ return false; } }
function ct_selText(comp){ var s=comp.selectedLayers; for(var i=0;i<s.length;i++){ if(ct_isText(s[i])) return s[i]; } return null; }
function ct_format(v){ var sign=v<0?"-":""; var s=String(Math.abs(Math.round(v))); var out=""; while(s.length>3){ out=" "+s.substr(s.length-3,3)+out; s=s.substr(0,s.length-3); } return sign+s+out; }
function ct_ease(x,p){ if(x<=0)return 0; if(x>=1)return 1; if(x<0.5)return Math.pow(x*2,p)/2; return 1-Math.pow((1-x)*2,p)/2; }
function ct_copyStyle(baseDoc,newText,forceVisible){
    var d=new TextDocument(String(newText));
    var keys=["font","fontSize","justification","tracking","leading","autoLeading","baselineShift","horizontalScale","verticalScale","fauxBold","fauxItalic","allCaps","smallCaps","applyFill","fillColor","applyStroke","strokeColor","strokeWidth","strokeOverFill"];
    for(var i=0;i<keys.length;i++){ try{ d[keys[i]]=baseDoc[keys[i]]; }catch(e){} }
    if(forceVisible){ try{d.applyFill=true;}catch(e){} try{d.fillColor=[1,1,1];}catch(e){} try{d.fontSize=Math.max(48,d.fontSize);}catch(e){} try{d.justification=ParagraphJustification.CENTER_JUSTIFY;}catch(e){} }
    return d;
}
function ct_addBlur(layer,startT,endT,amount){
    if(amount<=0) return;
    var fx=layer.property("ADBE Effect Parade");
    for(var i=fx.numProperties;i>=1;i--){ if(fx.property(i).name==="AM Counter Blur"){ try{fx.property(i).remove();}catch(e){} } }
    var blurFx=null;
    try{ blurFx=fx.addProperty("ADBE Box Blur2"); }catch(e1){ try{ blurFx=fx.addProperty("ADBE Gaussian Blur 2"); }catch(e2){} }
    if(!blurFx) return; try{ blurFx.name="AM Counter Blur"; }catch(e){}
    var bp=blurFx.property(1); var dur=Math.max(0.001,endT-startT);
    try{
        bp.setValueAtTime(startT,0);
        bp.setValueAtTime(startT+dur*0.18,amount*0.55);
        bp.setValueAtTime(startT+dur*0.50,amount);
        bp.setValueAtTime(startT+dur*0.82,amount*0.45);
        bp.setValueAtTime(endT,0);
        for(var k=1;k<=bp.numKeys;k++){ bp.setTemporalEaseAtKey(k,[new KeyframeEase(0,80)],[new KeyframeEase(0,80)]); }
    }catch(e){}
    try{ if(blurFx.property(2)) blurFx.property(2).setValue(3); }catch(e){}
    try{ if(blurFx.property(4)) blurFx.property(4).setValue(1); }catch(e){}
}
function ctEsc(s){ s=String(s); s=s.replace(/\\/g,"\\\\").replace(/"/g,'\\"'); return '"'+s+'"'; }
function ctAddMarkers(layer, t0, t1){
    try{
        var mk=layer.property("ADBE Marker"); var hasIn=false, hasOut=false;
        for(var k=1;k<=mk.numKeys;k++){ var c=mk.keyValue(k).comment; if(c=="TR In")hasIn=true; if(c=="TR Out")hasOut=true; }
        if(!hasIn) mk.setValueAtTime(t0, new MarkerValue("TR In"));
        if(!hasOut) mk.setValueAtTime(t1, new MarkerValue("TR Out"));
    }catch(e){}
}
function ct_resetMarkers(){
    var comp=actComp(); if(!comp) return;
    var L=ct_selText(comp); if(!L){ alertU("Select the counter text layer first."); return; }
    app.beginUndoGroup("Counter In/Out");
    try{
        var mk=L.property("ADBE Marker");
        for(var k=mk.numKeys;k>=1;k--){ var c=mk.keyValue(k).comment; if(c=="TR In"||c=="TR Out") mk.removeKey(k); }
        mk.setValueAtTime(comp.time, new MarkerValue("TR In"));
        mk.setValueAtTime(comp.time+1.2, new MarkerValue("TR Out"));
    }catch(e){}
    app.endUndoGroup();
}
function ct_apply(vals){
    var comp=actComp(); if(!comp) return;
    app.beginUndoGroup("AmanowTools Counter");
    try{
        var initDur=Math.max(0.1, vals.duration||2);
        var firstText=vals.prefix+ct_format(vals.startVal)+vals.suffix;
        var layer=ct_selText(comp); var created=false;
        if(!layer){
            layer=comp.layers.addText(firstText); layer.name="AM Counter";
            layer.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width/2,comp.height/2]); created=true;
            try{ var td0=layer.property("ADBE Text Properties").property("ADBE Text Document"); var bd=td0.value; bd.fontSize=Math.max(52,Math.round(comp.height/8)); bd.justification=ParagraphJustification.CENTER_JUSTIFY; td0.setValue(bd); }catch(e){}
        }
        if(!ct_isText(layer)){ alertU("Select a text layer."); app.endUndoGroup(); return; }
        // In/Out markers define the duration (added only if missing, so moving them sticks)
        ctAddMarkers(layer, comp.time, comp.time+initDur);
        var textProp=layer.property("ADBE Text Properties").property("ADBE Text Document");
        for(var rk=textProp.numKeys; rk>=1; rk--){ try{ textProp.removeKey(rk); }catch(e0){} }
        var ex="";
        ex+="var sv="+vals.startVal+";var ev="+vals.endVal+";var ep="+Math.max(0.1,vals.easePow)+";";
        ex+="var pre="+ctEsc(vals.prefix)+";var suf="+ctEsc(vals.suffix)+";";
        ex+="function mt(nm,df){for(var k=1;k<=marker.numKeys;k++){if(marker.key(k).comment==nm)return marker.key(k).time;}return df;}";
        ex+="var tIn=mt('TR In',inPoint);var tOut=mt('TR Out',inPoint+"+initDur+");";
        ex+="var p=(tOut>tIn)?(time-tIn)/(tOut-tIn):1;if(p<0)p=0;if(p>1)p=1;";
        ex+="function ez(x,pw){if(x<=0)return 0;if(x>=1)return 1;if(x<0.5)return Math.pow(x*2,pw)/2;return 1-Math.pow((1-x)*2,pw)/2;}";
        ex+="var e=ez(p,ep);var num=sv+(ev-sv)*e;var sign=(num<0)?'-':'';var s=''+Math.abs(Math.round(num));var o='';";
        ex+="while(s.length>3){o=' '+s.substr(s.length-3,3)+o;s=s.substr(0,s.length-3);}pre+sign+s+o+suf";
        textProp.expression=ex;
        // optional blur active only while counting
        var fx=layer.property("ADBE Effect Parade");
        for(var bi=fx.numProperties;bi>=1;bi--){ if(fx.property(bi).name==="AM Counter Blur"){ try{fx.property(bi).remove();}catch(e){} } }
        if(vals.blur>0){
            var blurFx=null; try{ blurFx=fx.addProperty("ADBE Gaussian Blur 2"); }catch(e1){ try{ blurFx=fx.addProperty("ADBE Box Blur2"); }catch(e2){} }
            if(blurFx){ try{ blurFx.name="AM Counter Blur"; }catch(e){}
                try{ if(blurFx.numProperties>=3) blurFx.property(3).setValue(true); }catch(e){}
                blurFx.property(1).expression="function mt(nm,df){for(var k=1;k<=marker.numKeys;k++){if(marker.key(k).comment==nm)return marker.key(k).time;}return df;}var tIn=mt('TR In',inPoint);var tOut=mt('TR Out',inPoint+"+initDur+");var p=(tOut>tIn)?(time-tIn)/(tOut-tIn):1;(p>0.02&&p<0.98)?"+vals.blur+":0";
            }
        }
        deselectAll(comp); layer.selected=true;
        try{ comp.openInViewer(); }catch(e){}
    }catch(err){ alert("Counter error:\n"+err.toString()); }
    app.endUndoGroup();
}

/* ---------- LETTER MORPH (from LetterMorph, empty defaults) ---------- */
function lm_hasText(layer){ try{ return layer && layer.property("ADBE Text Properties")!==null && layer.property("ADBE Text Properties").property("ADBE Text Document")!==null; }catch(e){ return false; } }
function lm_getLayer(comp,startText){
    if(comp.selectedLayers && comp.selectedLayers.length>0){
        for(var i=0;i<comp.selectedLayers.length;i++){ if(lm_hasText(comp.selectedLayers[i])) return comp.selectedLayers[i]; }
    }
    var L=comp.layers.addText(startText); L.name="AM LetterMorph";
    try{ L.property("ADBE Transform Group").property("ADBE Position").setValue([comp.width/2,comp.height/2]); }catch(e){}
    return L;
}
function lm_buildWord(startWord,endWord,stepIndex,order){
    var maxLen=Math.max(startWord.length,endWord.length), replaced=[], i, result="";
    for(i=0;i<maxLen;i++) replaced[i]=false;
    for(i=0;i<stepIndex;i++){ if(i<order.length) replaced[order[i]]=true; }
    for(i=0;i<maxLen;i++){
        if(replaced[i]){ if(i<endWord.length) result+=endWord.charAt(i); }
        else { if(i<startWord.length) result+=startWord.charAt(i); }
    }
    return result;
}
function lm_order(maxLen,dir){
    var arr=[],i;
    if(dir===1){ for(i=maxLen-1;i>=0;i--) arr.push(i); }
    else if(dir===2){
        var center=(maxLen-1)/2, used=[], c, best, bd, d;
        for(i=0;i<maxLen;i++) used[i]=false;
        for(c=0;c<maxLen;c++){ best=-1; bd=999999; for(i=0;i<maxLen;i++){ if(!used[i]){ d=Math.abs(i-center); if(d<bd){ bd=d; best=i; } } } used[best]=true; arr.push(best); }
    } else { for(i=0;i<maxLen;i++) arr.push(i); }
    return arr;
}
function lm_blur(layer,startTime,duration,steps,amount){
    if(amount<=0) return;
    var fx=layer.property("ADBE Effect Parade");
    for(var i=fx.numProperties;i>=1;i--){ if(fx.property(i).name==="AM Morph Blur"){ try{fx.property(i).remove();}catch(e){} } }
    var blurFx=null;
    try{ blurFx=fx.addProperty("ADBE Gaussian Blur 2"); }catch(e1){ try{ blurFx=fx.addProperty("ADBE Box Blur2"); }catch(e2){} }
    if(!blurFx) return; blurFx.name="AM Morph Blur";
    var bp=blurFx.property(1); var seg=duration/steps; var pulse=Math.min(seg*0.28,0.08);
    try{
        bp.setValueAtTime(startTime,0);
        for(var i=1;i<=steps;i++){
            var t=startTime+seg*i;
            bp.setValueAtTime(Math.max(startTime,t-pulse),0);
            bp.setValueAtTime(t,amount);
            bp.setValueAtTime(Math.min(startTime+duration,t+pulse),0);
        }
        bp.setValueAtTime(startTime+duration,0);
    }catch(e){}
    try{ if(blurFx.numProperties>=3) blurFx.property(3).setValue(true); }catch(e){}
}
function lm_apply(startWord,endWord,duration,blurAmount,dir){
    var comp=actComp(); if(!comp) return;
    startWord=String(startWord); endWord=String(endWord);
    // If Start is empty but a text layer is selected, use its current text as Start.
    if(startWord.length===0 && comp.selectedLayers && comp.selectedLayers.length>0){
        for(var si=0;si<comp.selectedLayers.length;si++){
            if(lm_hasText(comp.selectedLayers[si])){
                try{ startWord=String(comp.selectedLayers[si].property("ADBE Text Properties").property("ADBE Text Document").value.text); }catch(e){}
                break;
            }
        }
    }
    if(endWord.length===0){ alertU("Fill the End word."); return; }
    if(startWord.length===0){ alertU("Type a Start word, or select a text layer to use its current text."); return; }
    if(duration<=0){ alertU("Duration must be greater than 0."); return; }
    app.beginUndoGroup("AmanowTools LetterMorph");
    var layer=lm_getLayer(comp,startWord);
    var textProp=layer.property("ADBE Text Properties").property("ADBE Text Document");
    var startTime=comp.time, maxLen=Math.max(startWord.length,endWord.length), steps=Math.max(1,maxLen);
    var order=lm_order(maxLen,dir), baseDoc=textProp.value, seg=duration/steps;
    for(var k=textProp.numKeys;k>=1;k--){ var kt=textProp.keyTime(k); if(kt>=startTime && kt<=startTime+duration) textProp.removeKey(k); }
    for(var i=0;i<=steps;i++){
        var cur=lm_buildWord(startWord,endWord,i,order); var doc;
        try{ doc=baseDoc; doc.text=cur; }catch(e){ doc=new TextDocument(cur); }
        var t=startTime+seg*i;
        try{ textProp.setValueAtTime(t,doc); var ki=textProp.nearestKeyIndex(t); textProp.setInterpolationTypeAtKey(ki,KeyframeInterpolationType.HOLD,KeyframeInterpolationType.HOLD); }catch(e){}
    }
    lm_blur(layer,startTime,duration,steps,blurAmount);
    app.endUndoGroup();
}


/* ===================== ANIM MODULE (ported; UI->params) ===================== */
function taAddProp(props, mn, val){ try{ var pp=props.addProperty(mn); pp.setValue(val); return pp; }catch(e){ return null; } }
function ensureFx(layer,name,val){
    var fx=layer.property("ADBE Effect Parade"); var e=null;
    try{ e=fx.property(name); }catch(x){}
    if(!e){ e=fx.addProperty("ADBE Slider Control"); e.name=name; }
    try{ e.property(1).setValue(val); }catch(y){}
    return e;
}
/* Runtime-only synchronization state. Keeping this outside MarkerValue avoids
   writing back to a marker after every manual drag, which polluted AE's Undo
   stack and could make Ctrl+Z remove TR In/Out completely. */
var amDurationSyncState={};
function amDurationSyncKey(layer,markerName){
    var comp=layer.containingComp, cid="comp", lid="layer";
    try{ cid=String(comp.id); }catch(e0){ try{ cid=String(comp.name); }catch(e1){} }
    try{ lid=String(layer.id); }catch(e2){ try{ lid=String(layer.index)+":"+String(layer.name); }catch(e3){} }
    return cid+":"+lid+":"+markerName;
}
function amClearDurationSyncState(layer,phase){
    var all=(phase===undefined||phase===null), inP=(phase===0||phase==="0"), outP=(phase===2||phase==="2");
    try{ if(all||inP) delete amDurationSyncState[amDurationSyncKey(layer,"TR In")]; }catch(e0){}
    try{ if(all||outP) delete amDurationSyncState[amDurationSyncKey(layer,"TR Out")]; }catch(e1){}
}
function hasAMBothPass(layer){
    /* Both/legacy passes own plain AM controls. A later one-sided pass must
       replace that whole pass; otherwise its opposite fade selector would be
       left behind while the shared AM Delay effect gets removed. */
    try{
        var fx=layer.property("ADBE Effect Parade");
        if(fx&&(fx.property("AM Delay")||fx.property("AM Bounce")||fx.property("AM Frequency"))) return true;
    }catch(e0){}
    try{
        var tp=layer.property("ADBE Text Properties"), anims=tp?tp.property("ADBE Text Animators"):null;
        if(anims){ for(var i=1;i<=anims.numProperties;i++){ try{
            var n=String(anims.property(i).name);
            if(n==="AM TextFlex"||n.indexOf("AmanowText")===0) return true;
        }catch(e1){} } }
    }catch(e2){}
    return false;
}
/* Remove only animation created by AmanowTools. This makes Animate a replacement,
   never a second animation stacked on top of the first one. */
function clearAMLayer(layer, phase){
    /* phase: undefined = remove everything; 0 = only the In pass; 2 = only the Out pass.
       In and Out passes live side by side (own animator, own sliders, own marker),
       so applying one never erases the other. A Both pass replaces everything. */
    var all=(phase===undefined||phase===null);
    if(!all&&hasAMBothPass(layer)){ clearAMLayer(layer); return; }
    var inP=(phase===0||phase==="0"), outP=(phase===2||phase==="2");
    amClearDurationSyncState(layer,all?undefined:phase);
    var BASE=["Amplitude","Frequency","Decay","Delay","Duration","Opacity Duration","Blur Duration","Distance","Overshoot","Bounce"];
    var names=[], b;
    for(b=0;b<BASE.length;b++) names.push("AM "+BASE[b]);                 /* plain = Both / legacy */
    if(all||inP){ for(b=0;b<BASE.length;b++) names.push("AM In "+BASE[b]); }
    if(all||outP){ for(b=0;b<BASE.length;b++) names.push("AM Out "+BASE[b]); }
    try{
        var mk=layer.property("ADBE Marker");
        if(mk){ for(var k=mk.numKeys;k>=1;k--){ try{ var c=mk.keyValue(k).comment;
            if(((all||inP)&&c==="TR In")||((all||outP)&&c==="TR Out")) mk.removeKey(k); }catch(e0){} } }
    }catch(e1){}
    try{
        var tp=layer.property("ADBE Text Properties"), anims=tp?tp.property("ADBE Text Animators"):null;
        if(anims){ for(var a=anims.numProperties;a>=1;a--){ try{
            var an=String(anims.property(a).name); var kill=false;
            if(all){ kill=(an.indexOf("AM ")===0||an.indexOf("AmanowText")===0); }
            else{
                if(an==="AM TextFlex"||an.indexOf("AmanowText")===0) kill=true;   /* Both/legacy is replaced by any new pass */
                if(inP&&an.indexOf("AM ")===0&&an.length>3&&an.substr(an.length-3)===" In") kill=true;
                if(outP&&an.indexOf("AM ")===0&&an.length>4&&an.substr(an.length-4)===" Out") kill=true;
            }
            if(kill) anims.property(a).remove(); }catch(e2){} } }
    }catch(e3){}
    if(all){
        try{
            var tg=layer.property("ADBE Transform Group");
            if(tg){
                var tn=["ADBE Position","ADBE Scale","ADBE Opacity","ADBE Rotate Z","ADBE Rotate X","ADBE Rotate Y"];
                for(var t=0;t<tn.length;t++){ try{ var pp=tg.property(tn[t]); var ex=pp&&pp.canSetExpression?String(pp.expression):""; if(ex.indexOf("AM ")>=0) pp.expression=""; }catch(e4){} }
            }
        }catch(e5){}
    }
    try{
        var fx=layer.property("ADBE Effect Parade");
        if(fx){ for(var f=fx.numProperties;f>=1;f--){ try{ var nm=String(fx.property(f).name); for(var z=0;z<names.length;z++){ if(nm===names[z]){ fx.property(f).remove(); break; } } }catch(e6){} } }
    }catch(e7){}
}
// Build the per-character Expression-Selector amount (0..100). Original elastic math.
function buildFlexExpr(dir, mode, shoot, pfx){
    pfx=pfx||"AM ";
    var both=(mode===1||mode==="1"), outOnly=(mode===2||mode==="2");
    var L=[];
    L.push("var B=effect('"+pfx+"Bounce')('Slider')/100; if(B<0)B=0; if(B>1)B=1;");
    L.push("var freq=effect('"+pfx+"Frequency')('Slider');");
    L.push("var dec=effect('"+pfx+"Decay')('Slider');");
    if(both){
        L.push("var ctlDurIn=Math.max(thisComp.frameDuration,effect('AM In Duration')('Slider'));");
        L.push("var ctlDurOut=Math.max(thisComp.frameDuration,effect('AM Out Duration')('Slider'));");
    }else{
        L.push("var ctlDur=Math.max(thisComp.frameDuration,effect('"+pfx+"Duration')('Slider'));");
        L.push("var ctlDurIn=ctlDur,ctlDurOut=ctlDur;");
    }
    if(both){
        L.push("var dlyIn=effect('AM In Delay')('Slider')*thisComp.frameDuration;");
        L.push("var dlyOut=effect('AM Out Delay')('Slider')*thisComp.frameDuration;");
    }else{
        L.push("var dly=effect('"+pfx+"Delay')('Slider')*thisComp.frameDuration;");
        L.push("var dlyIn=dly,dlyOut=dly;");
    }
    L.push("var n=textTotal; var i=textIndex;");
    if(dir===1) L.push("var o=n-i;");
    else if(dir===2){ L.push("var c=(n+1)/2; var o=Math.abs(i-c);"); }
    else if(dir===3){ L.push("var c=(n+1)/2; var o=((n-1)/2)-Math.abs(i-c); if(o<0)o=0;"); }
    else if(dir===4){ L.push("seedRandom(i,true); var o=Math.floor(random(0,n));"); }
    else L.push("var o=i-1;");
    L.push("var maxO=Math.max(0,n-1);");
    L.push("function mt(nm,df){ for(var k=1;k<=marker.numKeys;k++){ if(marker.key(k).comment==nm) return marker.key(k).time; } return df; }");
    L.push("var tIn=mt('TR In',Math.min(outPoint,inPoint+ctlDurIn));");
    L.push("var tOut=mt('TR Out',Math.max(inPoint,outPoint-ctlDurOut));");
    /* Keep the original, proven In/Out spring from AmanowTools_v1_0 (9).
       Opacity and Blur are deliberately handled by independent selectors below. */
    L.push("function ez(el,win,dur){ if(el<=0)return 0; if(el>=win)return 1; var q=el/dur; var tail=1-el/win; var f=Math.max(0.1,freq); var dc=Math.max(0,dec); var osc=(1-B)*Math.cos(2*Math.PI*f*q)+B*Math.abs(Math.cos(Math.PI*f*q)); return 1-Math.exp(-dc*q)*osc*tail*tail; }");
    L.push("var totalIn=Math.max(thisComp.frameDuration,tIn-inPoint); var stepIn=maxO?Math.min(Math.max(0,dlyIn),totalIn/maxO*0.8):0; var winIn=Math.max(thisComp.frameDuration,totalIn-o*stepIn); var stIn=inPoint+o*stepIn;");
    L.push("var totalOut=Math.max(thisComp.frameDuration,outPoint-tOut); var stepOut=maxO?Math.min(Math.max(0,dlyOut),totalOut/maxO*0.8):0; var winOut=Math.max(thisComp.frameDuration,totalOut-o*stepOut); var stOut=tOut+o*stepOut;");
    if(outOnly){
        L.push("ez(time-stOut,winOut,ctlDurOut)*100;");
    } else if(both){
        L.push("var ain=(1-ez(time-stIn,winIn,ctlDurIn))*100;");
        L.push("var aout=ez(time-stOut,winOut,ctlDurOut)*100;");
        L.push("Math.max(ain,aout);");
    } else {
        L.push("(1-ez(time-stIn,winIn,ctlDurIn))*100;");
    }
    return L.join("\n");
}

/* Opacity/Blur have their own linear-smooth timing. They use the same text
   order and Delay as the selected animation, but never Frequency, Decay or
   Bounce. This stays expression-driven even when the motion engine is KFRM. */
function buildIndependentFadeExpr(dir, phase, durFx, delayFx){
    var L=[];
    L.push("var dur=Math.max(thisComp.frameDuration,effect('"+durFx+"')('Slider'));");
    L.push("var dl=Math.max(0,effect('"+delayFx+"')('Slider'))*thisComp.frameDuration;");
    L.push("var n=Math.max(1,textTotal),i=textIndex,maxO=Math.max(0,n-1);");
    if(dir===1) L.push("var o=n-i;");
    else if(dir===2) L.push("var c=(n+1)/2,o=Math.abs(i-c);");
    else if(dir===3) L.push("var c=(n+1)/2,o=Math.max(0,((n-1)/2)-Math.abs(i-c));");
    else if(dir===4) L.push("seedRandom(i,true);var o=Math.floor(random(0,n));");
    else L.push("var o=i-1;");
    L.push("function sm(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}");
    L.push("function mt(nm,df){for(var k=1;k<=marker.numKeys;k++){if(marker.key(k).comment==nm)return marker.key(k).time;}return df;}");
    if(phase===2){
        L.push("var base=mt('TR Out',Math.max(inPoint,outPoint-dur));");
        L.push("var room=Math.max(0,outPoint-base-dur),step=maxO?Math.min(dl,room/maxO):0;");
        L.push("var a=base+o*step;");
        L.push("sm((time-a)/dur)*100;");
    }else{
        L.push("var deadline=mt('TR In',outPoint);");
        L.push("var room=Math.max(0,deadline-inPoint-dur),step=maxO?Math.min(dl,room/maxO):0;");
        L.push("var a=inPoint+o*step;");
        L.push("(1-sm((time-a)/dur))*100;");
    }
    return L.join("\n");
}

function addIndependentTextFade(layer, phase, based, dir, kind, value, duration, delayFx){
    var isBlur=(kind==="Blur"), phaseName=(phase===2?"Out":"In");
    var durFx="AM "+phaseName+" "+kind+" Duration";
    var fd=layer.containingComp.frameDuration;
    duration=parseFloat(duration); if(isNaN(duration)||duration<=0) duration=0.5;
    if(duration<fd) duration=fd;
    ensureFx(layer,durFx,duration);
    var anims=layer.property("ADBE Text Properties").property("ADBE Text Animators");
    var animator=anims.addProperty("ADBE Text Animator");
    animator.name="AM "+kind+" "+phaseName;
    var props=animator.property("ADBE Text Animator Properties");
    value=parseFloat(value); if(isNaN(value)) value=0;
    if(isBlur) taAddProp(props,"ADBE Text Blur",[value,value]);
    else taAddProp(props,"ADBE Text Opacity",value);
    var selector=animator.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
    try{ selector.property("ADBE Text Range Type2").setValue(based); }catch(e0){}
    var ex=buildIndependentFadeExpr(dir,phase,durFx,delayFx), assigned=false;
    try{ selector.property("ADBE Text Expressible Amount").expression=ex; assigned=true; }catch(e1){}
    if(!assigned){ try{ selector.property("Amount").expression=ex; }catch(e2){} }
    return animator;
}

function amClampLayerDuration(layer,duration){
    var fd=layer.containingComp.frameDuration, span=Math.max(fd,layer.outPoint-layer.inPoint);
    duration=parseFloat(duration); if(isNaN(duration)) duration=fd;
    return Math.max(fd,Math.min(span,duration));
}
function addTRMarkers(layer, mode, inDur, outDur){
    try{
        var mk=layer.property("ADBE Marker");
        var needIn=(mode===0||mode===1||mode==="0"||mode==="1");
        var needOut=(mode===1||mode===2||mode==="1"||mode==="2");
        /* refresh only the markers this pass owns - an Out pass must not delete TR In */
        for(var k=mk.numKeys;k>=1;k--){ try{ var c=mk.keyValue(k).comment; if((needIn&&c=="TR In")||(needOut&&c=="TR Out")) mk.removeKey(k); }catch(e){} }
        if(needIn){
            var di=amClampLayerDuration(layer,inDur), mvi=new MarkerValue("TR In");
            mk.setValueAtTime(Math.min(layer.outPoint,layer.inPoint+di),mvi);
        }
        if(needOut){
            var dout=amClampLayerDuration(layer,outDur), mvo=new MarkerValue("TR Out");
            mk.setValueAtTime(Math.max(layer.inPoint,layer.outPoint-dout),mvo);
        }
    }catch(e){}
}

function amFindMarker(mk,name){
    for(var k=1;k<=mk.numKeys;k++){ try{ if(mk.keyValue(k).comment===name) return k; }catch(e){} }
    return 0;
}
function amOpenDurationSyncUndo(ctx){
    if(!ctx.open){ app.beginUndoGroup("AmanowTools Duration Sync"); ctx.open=true; }
}
function amUpdateDurationSyncState(state,effectDur,markerDur){
    state.prevEffect=state.effect; state.prevMarker=state.marker;
    state.effect=effectDur; state.marker=markerDur; state.seen=true;
}
function amMoveDurationMarker(layer,mk,index,mv,isOut,duration,ctx){
    var t=isOut?(layer.outPoint-duration):(layer.inPoint+duration);
    t=Math.max(layer.inPoint,Math.min(layer.outPoint,t));
    var oldTime=t; try{ oldTime=mk.keyTime(index); }catch(e0){}
    amOpenDurationSyncUndo(ctx);
    try{
        mk.removeKey(index);
        mk.setValueAtTime(t,mv);
        return true;
    }catch(e1){
        /* Never leave a half-completed remove/add operation behind. */
        try{ if(!amFindMarker(mk,mv.comment)) mk.setValueAtTime(oldTime,mv); }catch(e2){}
        return false;
    }
}
function amSyncDurationPair(layer,fxName,markerName,isOut,ctx){
    var fx=null, slider=null, mk=null;
    try{ fx=layer.property("ADBE Effect Parade").property(fxName); slider=fx?fx.property(1):null; mk=layer.property("ADBE Marker"); }catch(e0){}
    if(!slider||!mk) return 0;
    try{ if(slider.numKeys>0||slider.expressionEnabled) return 0; }catch(e1){}
    var fd=layer.containingComp.frameDuration, eps=Math.max(0.0001,fd/100);
    var raw=parseFloat(slider.value), effectDur=amClampLayerDuration(layer,raw), writes=0;
    if(isNaN(raw)||Math.abs(raw-effectDur)>eps){
        try{ amOpenDurationSyncUndo(ctx); slider.setValue(effectDur); writes++; }catch(e2){}
    }
    var stateKey=amDurationSyncKey(layer,markerName), state=amDurationSyncState[stateKey];
    var index=amFindMarker(mk,markerName);
    /* Expression mode owns and creates TR markers. KFRM intentionally has no
       TR markers. Only a previously observed EXPR pair may be restored after
       an Undo operation temporarily removes its marker. */
    if(!index){
        if(!state||!state.seen) return writes;
        var restore=(state.prevMarker!==undefined&&state.prevMarker!==null)?state.prevMarker:state.marker;
        restore=amClampLayerDuration(layer,restore);
        try{
            amOpenDurationSyncUndo(ctx);
            var nt=isOut?(layer.outPoint-restore):(layer.inPoint+restore);
            mk.setValueAtTime(nt,new MarkerValue(markerName)); writes++;
            if(Math.abs(effectDur-restore)>eps){ slider.setValue(restore); writes++; }
            amUpdateDurationSyncState(state,restore,restore);
        }catch(e3){}
        return writes;
    }
    var mv=mk.keyValue(index);
    var rawMarkerDur=isOut?(layer.outPoint-mk.keyTime(index)):(mk.keyTime(index)-layer.inPoint);
    var markerDur=amClampLayerDuration(layer,rawMarkerDur);
    if(Math.abs(rawMarkerDur-markerDur)>eps){
        try{ amOpenDurationSyncUndo(ctx); slider.setValue(markerDur); writes++; }catch(eClamp){}
        if(amMoveDurationMarker(layer,mk,index,mv,isOut,markerDur,ctx)) writes++;
        if(!state){ state={effect:markerDur,marker:markerDur,prevEffect:effectDur,prevMarker:markerDur,seen:true}; amDurationSyncState[stateKey]=state; }
        else amUpdateDurationSyncState(state,markerDur,markerDur);
        return writes;
    }
    if(!state){
        state={effect:effectDur,marker:markerDur,prevEffect:effectDur,prevMarker:markerDur,seen:true};
        amDurationSyncState[stateKey]=state;
        /* On first observation, a visible legacy marker is authoritative. */
        if(Math.abs(effectDur-markerDur)>eps){ try{ amOpenDurationSyncUndo(ctx); slider.setValue(markerDur); writes++; state.effect=markerDur; }catch(e4){} }
        return writes;
    }
    var effectChanged=Math.abs(effectDur-state.effect)>eps;
    var markerChanged=Math.abs(markerDur-state.marker)>eps;
    if(effectChanged&&!markerChanged){
        if(amMoveDurationMarker(layer,mk,index,mv,isOut,effectDur,ctx)){
            writes++; amUpdateDurationSyncState(state,effectDur,effectDur);
        }
    }else if(markerChanged&&!effectChanged){
        /* Timeline edit: update only Effect Controls; never rewrite the marker. */
        try{ amOpenDurationSyncUndo(ctx); slider.setValue(markerDur); writes++; amUpdateDurationSyncState(state,markerDur,markerDur); }catch(e5){}
    }else if(effectChanged&&markerChanged){
        if(Math.abs(effectDur-markerDur)<=eps){
            amUpdateDurationSyncState(state,markerDur,markerDur);
        }else{
            /* Concurrent edits: the directly moved timeline marker wins. */
            try{ amOpenDurationSyncUndo(ctx); slider.setValue(markerDur); writes++; amUpdateDurationSyncState(state,markerDur,markerDur); }catch(e6){}
        }
    }
    return writes;
}
function am_syncDurationControls(){
    var comp=app.project?app.project.activeItem:null;
    if(!(comp instanceof CompItem)) return "0";
    var sel=comp.selectedLayers, writes=0, ctx={open:false};
    if(!sel||sel.length===0) return "0";
    try{
        for(var i=0;i<sel.length;i++){
            try{
                writes+=amSyncDurationPair(sel[i],"AM In Duration","TR In",false,ctx);
                writes+=amSyncDurationPair(sel[i],"AM Out Duration","TR Out",true,ctx);
            }catch(e){}
        }
    }finally{
        if(ctx.open){ try{ app.endUndoGroup(); }catch(eEnd){} }
    }
    return String(writes);
}
/* ===================== MOTION LAB ===================== */
/* Squash & Stretch: keyframed Scale pulse where the PEAK is set by the user
   on X and Y separately (e.g. x120 y80 = wide+short). Springs to the peak,
   over-shoots back, then settles. Works with or without any movement. */
function am_squashStretch(sxPct, syPct, dur){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s)."); return; }
    sxPct=pnum(sxPct,120); syPct=pnum(syPct,80);
    if(sxPct<1)sxPct=1; if(sxPct>400)sxPct=400; if(syPct<1)syPct=1; if(syPct>400)syPct=400;
    dur=pnum(dur,0.6); if(dur<0.15) dur=0.15;
    var fx=sxPct/100, fy=syPct/100;
    var ox=1+(1-fx)*0.28, oy=1+(1-fy)*0.28;   /* counter-overshoot back past rest */
    app.beginUndoGroup("AMANOW Squash & Stretch");
    for(var i=0;i<sel.length;i++){
        try{
            var sc=sel[i].property("ADBE Transform Group").property("ADBE Scale");
            if(!sc||!sc.canVaryOverTime) continue;
            var t0=comp.time, s0=sc.value, bx=s0[0], by=s0[1], is3=(s0.length>2);
            function SV(a,b){ return is3?[bx*a,by*b,s0[2]]:[bx*a,by*b]; }
            var T=[t0, t0+dur*0.30, t0+dur*0.62, t0+dur];
            var V=[SV(1,1), SV(fx,fy), SV(ox,oy), SV(1,1)];
            for(var q=0;q<T.length;q++) sc.setValueAtTime(T[q], V[q]);
            for(var e2=0;e2<T.length;e2++){
                try{
                    var ki=sc.nearestKeyIndex(T[e2]);
                    var dims=is3?3:2, ein=[], eout=[];
                    for(var d=0;d<dims;d++){ ein.push(new KeyframeEase(0,33)); eout.push(new KeyframeEase(0,33)); }
                    sc.setTemporalEaseAtKey(ki, ein, eout);
                }catch(eE){}
            }
        }catch(e){}
    }
    app.endUndoGroup();
}

/* Reset: remove the squash animation (Scale keyframes) from the selected
   layers and freeze the scale at its current value. */
function am_squashReset(){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s)."); return; }
    app.beginUndoGroup("AMANOW Squash Reset");
    for(var i=0;i<sel.length;i++){
        try{
            var sc=sel[i].property("ADBE Transform Group").property("ADBE Scale");
            if(!sc) continue;
            if(sc.numKeys>0){
                var v=sc.valueAtTime(comp.time,false);
                for(var k=sc.numKeys;k>=1;k--) sc.removeKey(k);
                try{ sc.setValue(v); }catch(eV){}
            }
        }catch(e){}
    }
    app.endUndoGroup();
}

/* Comp Resize: duplicates the comp at the preset size and keeps content centered. */
function am_resizeComp(w,h){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    w=Math.round(w); h=Math.round(h);
    app.beginUndoGroup("AMANOW Comp Resize");
    try{
        var dup=comp.duplicate();
        dup.name=comp.name+" "+w+"x"+h;
        var dx=(w-comp.width)/2, dy=(h-comp.height)/2;
        dup.width=w; dup.height=h;
        for(var i=1;i<=dup.numLayers;i++){
            try{
                var L=dup.layer(i);
                if(L.parent) continue;                     /* children follow their parent */
                var tg=L.property("ADBE Transform Group");
                var pp=tg.property("ADBE Position");
                var sep=false; try{ sep=!!pp.dimensionsSeparated; }catch(eS){}
                if(sep){
                    var px=tg.property("ADBE Position_0"), py=tg.property("ADBE Position_1");
                    if(px.numKeys>0){ for(var kx=1;kx<=px.numKeys;kx++) px.setValueAtKey(kx, px.keyValue(kx)+dx); } else px.setValue(px.value+dx);
                    if(py.numKeys>0){ for(var ky=1;ky<=py.numKeys;ky++) py.setValueAtKey(ky, py.keyValue(ky)+dy); } else py.setValue(py.value+dy);
                } else if(pp.numKeys>0){
                    for(var kk=1;kk<=pp.numKeys;kk++){ var v=pp.keyValue(kk); pp.setValueAtKey(kk, (v.length>2)?[v[0]+dx,v[1]+dy,v[2]]:[v[0]+dx,v[1]+dy]); }
                } else {
                    var v0=pp.value; pp.setValue((v0.length>2)?[v0[0]+dx,v0[1]+dy,v0[2]]:[v0[0]+dx,v0[1]+dy]);
                }
            }catch(eL){}
        }
        try{ dup.openInViewer(); }catch(eV){}
    }catch(e){ alert("Resize error:\n"+e.toString()); }
    app.endUndoGroup();
}

/* Brand Palette: paint the selected layers with a saved brand color. */
function am_paintVectors(group, col, mode){
    for(var i=1;i<=group.numProperties;i++){
        var p=group.property(i), mn=p.matchName;
        if(mn==="ADBE Vector Group"){ var inner=null; try{ inner=p.property("ADBE Vectors Group"); }catch(e0){} if(inner) am_paintVectors(inner,col,mode); }
        else if(mode==="fill" && mn==="ADBE Vector Graphic - Fill"){ try{ p.property("ADBE Vector Fill Color").setValue(col); }catch(e1){} }
        else if(mode==="stroke" && mn==="ADBE Vector Graphic - Stroke"){ try{ p.property("ADBE Vector Stroke Color").setValue(col); }catch(e2){} }
    }
}
function am_applyBrandColor(r,g,b,mode){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to paint."); return; }
    mode=(mode==="stroke")?"stroke":"fill";
    var col=[(parseFloat(r)||0)/255,(parseFloat(g)||0)/255,(parseFloat(b)||0)/255];
    app.beginUndoGroup("AMANOW Brand Color");
    for(var i=0;i<sel.length;i++){
        var L=sel[i];
        try{
            var tdoc=null; try{ var tp=L.property("ADBE Text Properties"); tdoc=tp?tp.property("ADBE Text Document"):null; }catch(eT){}
            if(tdoc){
                var v=tdoc.value;
                if(mode==="stroke"){ v.applyStroke=true; v.strokeColor=col; }
                else { v.applyFill=true; v.fillColor=col; }
                tdoc.setValue(v);
                continue;
            }
            var root=null; try{ root=L.property("ADBE Root Vectors Group"); }catch(eR){}
            if(root){ am_paintVectors(root, col, mode); continue; }
            if(mode==="fill"){
                var fxp=L.property("ADBE Effect Parade"), fill=null;
                for(var f=1;f<=fxp.numProperties;f++){ if(fxp.property(f).matchName==="ADBE Fill"){ fill=fxp.property(f); break; } }
                if(!fill){ try{ fill=fxp.addProperty("ADBE Fill"); }catch(eF){} }
                if(fill){ var okC=false; try{ fill.property(3).setValue(col); okC=true; }catch(c1){} if(!okC){ try{ fill.property("Color").setValue(col); }catch(c2){} } }
            }
        }catch(e){}
    }
    app.endUndoGroup();
}

/* Apply a two-color gradient. Shape layers get a real Gradient Fill/Stroke
   operator; other layers get a Ramp effect. If the gradient value can't be
   set, it falls back to a solid of the first color (never crashes). */
function am_gradColorsSet(gp, c1, c2){
    /* Read AE's own gradient value (exact format), replace the two color stops,
       write it back. Using AE's format guarantees the colors actually apply. */
    try{
        var v=gp.value;
        if(v && v.length && v.length>=8){
            v[1]=c1[0]; v[2]=c1[1]; v[3]=c1[2];   /* stop 1 color (after its 0.0 location) */
            v[5]=c2[0]; v[6]=c2[1]; v[7]=c2[2];   /* stop 2 color (after its 1.0 location) */
            gp.setValue(v);
            return true;
        }
        gp.setValue([0,c1[0],c1[1],c1[2], 1,c2[0],c2[1],c2[2], 0,1, 1,1]);
        return true;
    }catch(e){ return false; }
}
function am_applyGradient(r1,g1,b1,r2,g2,b2,mode){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to paint."); return; }
    mode=(mode==="stroke")?"stroke":"fill";
    var c1=[pnum(r1,0)/255,pnum(g1,0)/255,pnum(b1,0)/255];
    var c2=[pnum(r2,0)/255,pnum(g2,0)/255,pnum(b2,0)/255];
    app.beginUndoGroup("AMANOW Gradient");
    for(var i=0;i<sel.length;i++){
        var L=sel[i];
        try{
            var root=null; try{ root=L.property("ADBE Root Vectors Group"); }catch(eR){}
            if(root){
                /* gradient span across the shape's own bounds */
                var p1=[-150,-150], p2=[150,150];
                try{ var sr=L.sourceRectAtTime(comp.time,false); if(sr&&sr.width>2){ p1=[sr.left, sr.top]; p2=[sr.left+sr.width, sr.top+sr.height]; } }catch(eSR){}
                var host=root;
                for(var g=1; g<=root.numProperties; g++){ if(root.property(g).matchName==="ADBE Vector Group"){ try{ host=root.property(g).property("ADBE Vectors Group"); }catch(eH){} break; } }
                for(var k=host.numProperties; k>=1; k--){ var mk=host.property(k).matchName;
                    if(mode==="fill"   && (mk==="ADBE Vector Graphic - Fill"   || mk==="ADBE Vector Graphic - G-Fill"))   { try{ host.property(k).remove(); }catch(eRm1){} }
                    if(mode==="stroke" && (mk==="ADBE Vector Graphic - Stroke" || mk==="ADBE Vector Graphic - G-Stroke")) { try{ host.property(k).remove(); }catch(eRm2){} }
                }
                var op=host.addProperty(mode==="stroke"?"ADBE Vector Graphic - G-Stroke":"ADBE Vector Graphic - G-Fill");
                try{ op.moveTo(1); }catch(eMv){}
                try{ op.property("ADBE Vector Grad Type").setValue(1); }catch(eT){}
                var okC=am_gradColorsSet(op.property("ADBE Vector Grad Colors"), c1, c2);
                try{ op.property("ADBE Vector Grad Start Pt").setValue(p1); op.property("ADBE Vector Grad End Pt").setValue(p2); }catch(eP){}
                if(!okC){
                    try{ op.remove(); }catch(eRm){}
                    var sf=host.addProperty(mode==="stroke"?"ADBE Vector Graphic - Stroke":"ADBE Vector Graphic - Fill");
                    try{ sf.property(mode==="stroke"?"ADBE Vector Stroke Color":"ADBE Vector Fill Color").setValue(c1); }catch(eSf){}
                }
                continue;
            }
            var fx=L.property("ADBE Effect Parade");
            var ramp=fx.addProperty("ADBE Ramp");
            try{ ramp.name="AM Gradient"; }catch(eN){}
            var w=comp.width, h=comp.height; try{ if(L.width) w=L.width; if(L.height) h=L.height; }catch(eW){}
            try{ ramp.property("ADBE Ramp-0001").setValue([0,0]); }catch(e1){}
            try{ ramp.property("ADBE Ramp-0002").setValue(c1); }catch(e2){}
            try{ ramp.property("ADBE Ramp-0003").setValue([w,h]); }catch(e3){}
            try{ ramp.property("ADBE Ramp-0004").setValue(c2); }catch(e4){}
        }catch(e){}
    }
    app.endUndoGroup();
}

/* Shape Morph: turn the selected shape layer's form into a chosen target shape.
   All targets are built with 12 vertices, so the morphs stay clean. */
function am_shpMake(v,it,ot){ var s=new Shape(); s.vertices=v; s.inTangents=it; s.outTangents=ot; s.closed=true; return s; }
function am_shpCircle(cx,cy,rx,ry){
    var n=12, k=0.17553, v=[], it=[], ot=[];
    for(var i=0;i<n;i++){
        var a=-Math.PI/2 + i*(2*Math.PI/n);
        v.push([cx+rx*Math.cos(a), cy+ry*Math.sin(a)]);
        ot.push([-Math.sin(a)*rx*k,  Math.cos(a)*ry*k]);
        it.push([ Math.sin(a)*rx*k, -Math.cos(a)*ry*k]);
    }
    return am_shpMake(v,it,ot);
}
function am_shpSquare(cx,cy,rx,ry){
    var c=[[-rx,-ry],[rx,-ry],[rx,ry],[-rx,ry]], v=[], it=[], ot=[];
    for(var i=0;i<4;i++){
        var A=c[i], Bp=c[(i+1)%4];
        v.push([cx+A[0],cy+A[1]]);
        v.push([cx+A[0]+(Bp[0]-A[0])/3, cy+A[1]+(Bp[1]-A[1])/3]);
        v.push([cx+A[0]+(Bp[0]-A[0])*2/3, cy+A[1]+(Bp[1]-A[1])*2/3]);
    }
    for(var z=0;z<12;z++){ it.push([0,0]); ot.push([0,0]); }
    return am_shpMake(v,it,ot);
}
function am_shpRound(cx,cy,rx,ry){
    var q=0.4*Math.min(rx,ry), c=0.5523*q, v=[], it=[], ot=[];
    function P(x,y,ix,iy,ox,oy){ v.push([cx+x,cy+y]); it.push([ix,iy]); ot.push([ox,oy]); }
    P(0,-ry, 0,0, 0,0);
    P(rx-q,-ry, 0,0, c,0);  P(rx,-ry+q, 0,-c, 0,0);
    P(rx,0, 0,0, 0,0);
    P(rx,ry-q, 0,0, 0,c);   P(rx-q,ry, c,0, 0,0);
    P(0,ry, 0,0, 0,0);
    P(-rx+q,ry, 0,0, -c,0); P(-rx,ry-q, 0,c, 0,0);
    P(-rx,0, 0,0, 0,0);
    P(-rx,-ry+q, 0,0, 0,-c); P(-rx+q,-ry, -c,0, 0,0);
    return am_shpMake(v,it,ot);
}
function am_shpTri(cx,cy,rx,ry){
    var c=[[0,-ry],[rx,ry],[-rx,ry]], v=[], it=[], ot=[];
    for(var i=0;i<3;i++){
        var A=c[i], Bp=c[(i+1)%3];
        v.push([cx+A[0],cy+A[1]]);
        for(var t=1;t<=3;t++){ var f=t/4; v.push([cx+A[0]+(Bp[0]-A[0])*f, cy+A[1]+(Bp[1]-A[1])*f]); }
    }
    for(var z=0;z<12;z++){ it.push([0,0]); ot.push([0,0]); }
    return am_shpMake(v,it,ot);
}
function am_shpStar(cx,cy,rx,ry){
    var v=[], it=[], ot=[];
    for(var i=0;i<12;i++){
        var a=-Math.PI/2 + i*(Math.PI/6);
        var f=(i%2===0)?1:0.45;
        v.push([cx+rx*f*Math.cos(a), cy+ry*f*Math.sin(a)]);
        it.push([0,0]); ot.push([0,0]);
    }
    return am_shpMake(v,it,ot);
}
function am_shpScale(sh,cx,cy,f){
    var v=[], it=[], ot=[];
    for(var i=0;i<sh.vertices.length;i++){
        v.push([cx+(sh.vertices[i][0]-cx)*f, cy+(sh.vertices[i][1]-cy)*f]);
        it.push([sh.inTangents[i][0]*f, sh.inTangents[i][1]*f]);
        ot.push([sh.outTangents[i][0]*f, sh.outTangents[i][1]*f]);
    }
    return am_shpMake(v,it,ot);
}
function am_shpTarget(kind,cx,cy,rx,ry){
    if(kind==="square") return am_shpSquare(cx,cy,rx,ry);
    if(kind==="round")  return am_shpRound(cx,cy,rx,ry);
    if(kind==="tri")    return am_shpTri(cx,cy,rx,ry);
    if(kind==="star")   return am_shpStar(cx,cy,rx,ry);
    return am_shpCircle(cx,cy,rx,ry);
}
function am_findShape(grp){
    for(var j=1;j<=grp.numProperties;j++){
        var it=grp.property(j), mn=it.matchName;
        if(mn==="ADBE Vector Shape - Group") return {vec:grp,item:it,idx:j,kind:"path"};
        if(mn==="ADBE Vector Shape - Rect"||mn==="ADBE Vector Shape - Ellipse"||mn==="ADBE Vector Shape - Star") return {vec:grp,item:it,idx:j,kind:mn};
        if(mn==="ADBE Vector Group"){ var inner=null; try{ inner=it.property("ADBE Vectors Group"); }catch(e){} if(inner){ var r=am_findShape(inner); if(r) return r; } }
    }
    return null;
}
function am_morphOne(comp, L, kind, dur, amp, elastic){
    var root=null; try{ root=L.property("ADBE Root Vectors Group"); }catch(e0){}
    if(!root) return false;
    var sr=null; try{ sr=L.sourceRectAtTime(comp.time, false); }catch(eSR){}
    var found=null; try{ found=am_findShape(root); }catch(eF){}
    if(!found) return false;
    var path=null, start=null, cx=0, cy=0, rx=60, ry=60;
    try{
        if(found.kind==="path"){
            path=found.item.property("ADBE Vector Shape");
            start=path.value;
            var vs=start.vertices, mnx=1e12,mny=1e12,mxx=-1e12,mxy=-1e12;
            for(var q=0;q<vs.length;q++){ if(vs[q][0]<mnx)mnx=vs[q][0]; if(vs[q][0]>mxx)mxx=vs[q][0]; if(vs[q][1]<mny)mny=vs[q][1]; if(vs[q][1]>mxy)mxy=vs[q][1]; }
            cx=(mnx+mxx)/2; cy=(mny+mxy)/2; rx=Math.max(6,(mxx-mnx)/2); ry=Math.max(6,(mxy-mny)/2);
        } else {
            if(!(sr && sr.width>2 && sr.height>2)) return false;
            cx=sr.left+sr.width/2; cy=sr.top+sr.height/2; rx=sr.width/2; ry=sr.height/2;
            if(found.kind==="ADBE Vector Shape - Rect"){ var rr=0; try{ rr=found.item.property("ADBE Vector Rect Roundness").value; }catch(eR){} start=(rr>1)?am_shpRound(cx,cy,rx,ry):am_shpSquare(cx,cy,rx,ry); }
            else if(found.kind==="ADBE Vector Shape - Ellipse"){ start=am_shpCircle(cx,cy,rx,ry); }
            else { start=am_shpStar(cx,cy,rx,ry); }
            var np=found.vec.addProperty("ADBE Vector Shape - Group");
            try{ np.moveTo(found.idx); }catch(eM){}
            path=np.property("ADBE Vector Shape");
            path.setValue(start);
            try{ found.item.remove(); }catch(eD){}
        }
    }catch(eS){ return false; }
    if(!path||!start) return false;
    try{
        var target=am_shpTarget(kind,cx,cy,rx,ry);
        var t0=comp.time, a=Math.max(0,Math.min(100,amp))/100*0.28;
        path.setValueAtTime(t0, start);
        var kt=[t0];
        if(elastic){
            path.setValueAtTime(t0+dur,      am_shpScale(target,cx,cy,1+a));
            path.setValueAtTime(t0+dur*1.18, am_shpScale(target,cx,cy,1-a*0.45));
            path.setValueAtTime(t0+dur*1.34, am_shpScale(target,cx,cy,1+a*0.15));
            path.setValueAtTime(t0+dur*1.5,  target);
            kt.push(t0+dur, t0+dur*1.18, t0+dur*1.34, t0+dur*1.5);
        } else {
            path.setValueAtTime(t0+dur, target);
            kt.push(t0+dur);
        }
        for(var e3=0;e3<kt.length;e3++){ try{ var ki=path.nearestKeyIndex(kt[e3]); path.setTemporalEaseAtKey(ki,[new KeyframeEase(0,33)],[new KeyframeEase(0,33)]); }catch(eE){} }
    }catch(eK){ return false; }
    return true;
}
function am_shapeMorph(kind, dur, amp, elastic){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    dur=parseFloat(dur); if(isNaN(dur)||dur<=0) dur=1; if(dur<0.1) dur=0.1;
    amp=parseFloat(amp); if(isNaN(amp)) amp=50;
    var el=(elastic===1||elastic==="1"||elastic===true);
    var sel=comp.selectedLayers, shapes=[];
    for(var i=0;i<sel.length;i++){ try{ if(sel[i].property("ADBE Root Vectors Group")) shapes.push(sel[i]); }catch(e){} }
    if(shapes.length===0){ alertU("Select a shape layer."); return; }
    app.beginUndoGroup("AMANOW Shape Morph");
    var ok=0;
    for(var s=0;s<shapes.length;s++){ if(am_morphOne(comp, shapes[s], kind, dur, amp, el)) ok++; }
    app.endUndoGroup();
    if(ok===0) alertU("No editable shape path found on the selected layer(s).");
}

/* ===================== TEXT EXPLODER =====================
   Splits a text layer into separate layers (characters / words / lines /
   paragraphs). Each new layer is an exact duplicate where a text animator
   (Opacity 0) hides everything EXCEPT its own piece via a Subtract range
   selector. Nothing moves by even a pixel: kerning, alignment and wrapping
   stay identical, and every piece becomes an independent layer. */
function am_expCount(text, mode){
    var lines=String(text).split(/\r\n|\r|\n/);
    if(mode==="chars") return String(text).replace(/\s/g,"").length;
    if(mode==="words"){ var t=String(text).replace(/^\s+|\s+$/g,""); return t===""?0:t.split(/\s+/).length; }
    return lines.length;
}
function am_explodeOne(comp, src, mode){
    var text=""; try{ text=String(src.property("ADBE Text Properties").property("ADBE Text Document").value.text); }catch(e){ return 0; }
    if(!text || /^\s*$/.test(text)) return 0;
    var lines=text.split(/\r\n|\r|\n/);
    var pieces=[];   /* {label, based, i0, i1, total} : selector index range [i0,i1) */
    if(mode==="chars"){
        var flat=text.replace(/\s/g,"");
        for(var c=0;c<flat.length;c++) pieces.push({label:flat.charAt(c), based:2, i0:c, i1:c+1, total:flat.length});
    } else if(mode==="words"){
        var tt=text.replace(/^\s+|\s+$/g,"");
        var w=(tt==="")?[]:tt.split(/\s+/);
        for(var k=0;k<w.length;k++) pieces.push({label:w[k], based:3, i0:k, i1:k+1, total:w.length});
    } else if(mode==="lines"){
        for(var l=0;l<lines.length;l++){ if(!/^\s*$/.test(lines[l])) pieces.push({label:lines[l], based:4, i0:l, i1:l+1, total:lines.length}); }
    } else { /* paragraphs = groups of lines separated by blank lines */
        var cur=null;
        for(var g=0;g<lines.length;g++){
            if(/^\s*$/.test(lines[g])){ cur=null; continue; }
            if(!cur){ cur={first:g,last:g,txt:lines[g]}; pieces.push(cur); }
            else { cur.last=g; cur.txt+=" "+lines[g]; }
        }
        for(var q=0;q<pieces.length;q++){ var pg=pieces[q]; pieces[q]={label:pg.txt, based:4, i0:pg.first, i1:pg.last+1, total:lines.length}; }
    }
    if(pieces.length<2){ return -1; }          /* nothing to split in this mode */
    if(pieces.length>300){ return -2; }        /* sanity cap so AE never hangs */
    var made=[];
    for(var n=0;n<pieces.length;n++){
        var pc=pieces[n];
        var d=src.duplicate();
        try{ d.name=(pc.label.length>24?pc.label.substr(0,24)+"...":pc.label); }catch(eN){}
        try{
            var an=d.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator");
            an.name="AM Exploder";
            an.property("ADBE Text Animator Properties").addProperty("ADBE Text Opacity").setValue(0);
            var sels=an.property("ADBE Text Selectors");
            sels.addProperty("ADBE Text Selector");                       /* selector 1: default 0-100% = hide ALL */
            var sb=sels.addProperty("ADBE Text Selector");                /* selector 2: subtract = reveal the piece */
            var adv=sb.property("ADBE Text Range Advanced");
            try{ adv.property("ADBE Text Range Type2").setValue(pc.based); }catch(a1){}
            try{ adv.property("ADBE Text Selector Mode").setValue(2); }catch(a2){}
            var idxOk=false;
            try{
                adv.property("ADBE Text Range Units").setValue(2);        /* Index */
                sb.property("ADBE Text Index Start").setValue(pc.i0);
                sb.property("ADBE Text Index End").setValue(pc.i1);
                idxOk=true;
            }catch(a3){}
            if(!idxOk){                                                   /* percent fallback (maps linearly over units) */
                try{ adv.property("ADBE Text Range Units").setValue(1); }catch(a4){}
                try{ sb.property("ADBE Text Percent Start").setValue(pc.i0/pc.total*100); }catch(a5){}
                try{ sb.property("ADBE Text Percent End").setValue(pc.i1/pc.total*100); }catch(a6){}
            }
        }catch(eA){}
        made.push(d);
    }
    try{ src.enabled=false; }catch(eE){}
    try{ src.selected=false; }catch(eS){}
    for(var s=0;s<made.length;s++){ try{ made[s].selected=true; }catch(eS2){} }
    return made.length;
}
function am_explodeText(mode){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers, texts=[];
    for(var i=0;i<sel.length;i++){ try{ if(sel[i].property("ADBE Text Properties")) texts.push(sel[i]); }catch(e){} }
    if(texts.length===0){ alertU("Select a text layer."); return; }
    app.beginUndoGroup("AMANOW Text Exploder");
    var total=0, single=0, capped=0;
    for(var t=0;t<texts.length;t++){
        var r=am_explodeOne(comp, texts[t], mode);
        if(r===-1) single++;
        else if(r===-2) capped++;
        else total+=r;
    }
    app.endUndoGroup();
    if(total===0 && single>0){ alertU("Nothing to split: in this mode the text is a single piece."); }
    if(capped>0){ alertU("Some layers were skipped: more than 300 pieces."); }
}

/* ===================== COPY / PASTE CURVES (temporal ease only, not the keyframes) ===================== */
var amCurveClip = null;   /* persists across evalScript calls within the AE session */

function amTypeCode(t){
    if(t===KeyframeInterpolationType.HOLD) return 2;
    if(t===KeyframeInterpolationType.BEZIER) return 1;
    return 0; /* LINEAR */
}
function amCodeType(c){
    if(c===2) return KeyframeInterpolationType.HOLD;
    if(c===1) return KeyframeInterpolationType.BEZIER;
    return KeyframeInterpolationType.LINEAR;
}
function amCaptureKey(prop, ki){
    var rec={ it:1, ot:1, ie:[], oe:[] };
    try{ rec.it=amTypeCode(prop.keyInInterpolationType(ki)); }catch(e){}
    try{ rec.ot=amTypeCode(prop.keyOutInterpolationType(ki)); }catch(e){}
    try{ var ie=prop.keyInTemporalEase(ki);  for(var a=0;a<ie.length;a++) rec.ie.push({s:ie[a].speed, i:ie[a].influence}); }catch(e){}
    try{ var oe=prop.keyOutTemporalEase(ki); for(var b=0;b<oe.length;b++) rec.oe.push({s:oe[b].speed, i:oe[b].influence}); }catch(e){}
    if(rec.ie.length===0) rec.ie.push({s:0,i:16.6667});
    if(rec.oe.length===0) rec.oe.push({s:0,i:16.6667});
    return rec;
}
/* ordered list of {prop, keys[]} for selected properties that have selected keyframes */
function amSelKeyProps(comp){
    var out=[]; var props=comp.selectedProperties;
    for(var i=0;i<props.length;i++){
        var p=props[i];
        try{
            if(p.canVaryOverTime && p.numKeys>0){
                var sk=p.selectedKeys;
                if(sk && sk.length>0) out.push({prop:p, keys:sk});
            }
        }catch(e){}
    }
    return out;
}
function copyCurves(){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return "0"; }
    var groups=amSelKeyProps(comp);
    var clip=[];
    for(var g=0;g<groups.length;g++){
        var pr=groups[g].prop, keys=groups[g].keys;
        for(var k=0;k<keys.length;k++) clip.push(amCaptureKey(pr, keys[k]));
    }
    if(clip.length===0){ alertU("Select the keyframe(s) whose curves you want to copy."); return "0"; }
    amCurveClip=clip;
    return String(clip.length);
}
function pasteCurves(){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return "0"; }
    if(!amCurveClip || amCurveClip.length===0){ alertU("Copy curves first, then select the target keyframes and paste."); return "0"; }
    var groups=amSelKeyProps(comp);
    var targets=[];
    for(var g=0;g<groups.length;g++){ var pr=groups[g].prop, keys=groups[g].keys; for(var k=0;k<keys.length;k++) targets.push({prop:pr, ki:keys[k]}); }
    if(targets.length===0){ alertU("Select the target keyframe(s) to paste the curves onto."); return "0"; }
    app.beginUndoGroup("AMANOW Paste Curves");
    var n=0;
    for(var t=0;t<targets.length;t++){
        var prop=targets[t].prop, ki=targets[t].ki;
        var src=amCurveClip[ t % amCurveClip.length ];
        try{
            var L=1; try{ L=prop.keyInTemporalEase(ki).length; }catch(eL){ L=1; }
            var inArr=[], outArr=[];
            for(var d=0; d<L; d++){
                var se=src.ie[ Math.min(d, src.ie.length-1) ];
                var so=src.oe[ Math.min(d, src.oe.length-1) ];
                inArr.push(new KeyframeEase(se.s, Math.max(0.1, Math.min(100, se.i))));
                outArr.push(new KeyframeEase(so.s, Math.max(0.1, Math.min(100, so.i))));
            }
            /* apply the eased handles when a bezier side exists, then restore the exact interpolation types */
            if(src.it===1 || src.ot===1){ try{ prop.setTemporalEaseAtKey(ki, inArr, outArr); }catch(e1){} }
            try{ prop.setInterpolationTypeAtKey(ki, amCodeType(src.it), amCodeType(src.ot)); }catch(e2){}
            n++;
        }catch(e){}
    }
    app.endUndoGroup();
    return String(n);
}

/* ---------- KFRM engine (text): range selector with baked keyframes ---------- */
function amtPropSafe(parent, mn){ try{ var x=parent.property(mn); return x?x:null; }catch(e){ return null; } }
function amtCountUnits(text, basedOn){
    if(text===null||text===undefined) return 1;
    if(basedOn===4){ return text.split(/\r\n|\r|\n/).length; }
    else if(basedOn===3){ var t=text.replace(/^\s+|\s+$/g,""); if(t==="") return 0; return t.split(/\s+/).length; }
    else if(basedOn===2){ return text.replace(/\s/g,"").length; }
    return text.length;
}
function amtKey(prop, t, val, easeIn, easeOut){
    prop.setValueAtTime(t, val);
    try{
        var idx=prop.nearestKeyIndex(t);
        var ci=(easeIn===undefined)?33:easeIn; if(ci<0.1)ci=0.1;
        var co=(easeOut===undefined)?33:easeOut; if(co<0.1)co=0.1;
        prop.setTemporalEaseAtKey(idx, [new KeyframeEase(0,ci)], [new KeyframeEase(0,co)]);
    }catch(e){}
}
function applyTextKfrm(animator, p, layer, based){
    var sel=animator.property("ADBE Text Selectors").addProperty("ADBE Text Selector");
    var adv=amtPropSafe(sel,"ADBE Text Range Advanced");
    if(adv){
        var bo=amtPropSafe(adv,"ADBE Text Range Type2"); if(bo){ try{ bo.setValue(based); }catch(e1){} }
        var un=amtPropSafe(adv,"ADBE Text Range Units"); if(un){ try{ un.setValue(1); }catch(e2){} }       /* percentage */
        var sh=amtPropSafe(adv,"ADBE Text Range Type"); if(sh){ try{ sh.setValue(2); }catch(e3){} }         /* ramp up */
        if(p.dir===4){ var rnd=amtPropSafe(adv,"ADBE Text Randomize Order"); if(rnd){ try{ rnd.setValue(true); }catch(e4){} } }
    }
    var startP=amtPropSafe(sel,"ADBE Text Percent Start");
    var endP=amtPropSafe(sel,"ADBE Text Percent End");
    var offP=amtPropSafe(sel,"ADBE Text Percent Offset");
    if(offP){ try{ offP.setValue(0); }catch(e5){} }

    var rtl=(p.dir===1);
    var edge=rtl?endP:startP, fixed=rtl?startP:endP;
    if(!edge) return;
    if(fixed){ try{ fixed.setValue(rtl?0:100); }catch(e6){} }
    var full=rtl?100:0, rest=rtl?0:100;

    var text=""; try{ text=layer.property("ADBE Text Properties").property("ADBE Text Document").value.text; }catch(e7){}
    var nUnits=amtCountUnits(text, based); if(nUnits<1) nUnits=1;
    var fd=layer.containingComp.frameDuration;
    var baseDur=(p.dur>0)?p.dur:0.8;
    var durIn=(p.durIn>0)?p.durIn:baseDur, durOut=(p.durOut>0)?p.durOut:baseDur;
    var baseDelay=(p.delay!==undefined?p.delay:0);
    var delayIn=(p.delayIn!==undefined?p.delayIn:baseDelay), delayOut=(p.delayOut!==undefined?p.delayOut:baseDelay);
    var riseIn=durIn+(nUnits-1)*Math.max(0,delayIn)*fd;
    var riseOut=durOut+(nUnits-1)*Math.max(0,delayOut)*fd;
    if(riseIn<=0) riseIn=durIn; if(riseOut<=0) riseOut=durOut;
    var lin=layer.inPoint, lout=layer.outPoint;
    if(p.mode===0||p.mode==="0"){
        amtKey(edge, lin, full, 0.1,0.1);
        amtKey(edge, lin+riseIn, rest, 80,0.1);
    } else if(p.mode===2||p.mode==="2"){
        amtKey(edge, lout-riseOut, rest, 0.1,80);
        amtKey(edge, lout, full, 0.1,0.1);
    } else {
        var midA=lin+riseIn, midB=lout-riseOut;
        if(midB<=midA){ midB=Math.min(lout,midA+fd); }
        amtKey(edge, lin, full, 0.1,0.1);
        amtKey(edge, midA, rest, 80,0.1);
        amtKey(edge, midB, rest, 0.1,80);
        amtKey(edge, lout, full, 0.1,0.1);
    }
}

function applyAnimCEP(p){
    var comp=app.project.activeItem;
    if(!(comp instanceof CompItem)){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; var texts=[];
    for(var i=0;i<sel.length;i++){ try{ if(sel[i].property("ADBE Text Properties")) texts.push(sel[i]); }catch(e){} }
    if(texts.length===0){ alertU("Select a text layer."); return; }
    if(!(p.pos.on||p.anc.on||p.rot.on||p.scl.on||p.skew.on||p.trk.on||p.blur.on||p.opac.on)){
        alertU("Enable at least one property (Position, Scale, Opacity...)."); return; }
    var based=p.based, dir=p.dir, mode=p.mode, shoot=(p.shoot||(p.overshoot?"overshoot":"normal")), is3D=p.is3D;
    var bnc=(p.bounce&&typeof p.bounce==="object")?(p.bounce.on?p.bounce.v:0):(shoot==="bounce"?60:shoot==="overshoot"?30:shoot==="elastic"?45:0);
    var isIn=(mode===0||mode==="0"), isOut=(mode===2||mode==="2");
    var hasSpring=!!(p.pos.on||p.anc.on||p.rot.on||p.scl.on||p.skew.on||p.trk.on);
    var appliedFreq=isOut?2:p.freq;
    var pfx=isOut?"AM Out ":(isIn?"AM In ":"AM ");
    var baseDur=(p.dur!==undefined?p.dur:0.8);
    var durIn=(p.durIn!==undefined?p.durIn:baseDur), durOut=(p.durOut!==undefined?p.durOut:baseDur);
    var baseDelay=(p.delay!==undefined?p.delay:0);
    var delayIn=(p.delayIn!==undefined?p.delayIn:baseDelay), delayOut=(p.delayOut!==undefined?p.delayOut:baseDelay);
    var expr=buildFlexExpr(dir, mode, shoot, pfx);
    app.beginUndoGroup("AmanowTools TextFlex");
    for(var li=0;li<texts.length;li++){
        var layer=texts[li];
        try{
            clearAMLayer(layer, isIn?0:(isOut?2:undefined));
            ensureFx(layer,pfx+"Bounce",bnc);
            ensureFx(layer,pfx+"Frequency",appliedFreq);
            ensureFx(layer,pfx+"Decay",p.decay);
            if(isIn) ensureFx(layer,"AM In Duration",durIn);
            else if(isOut) ensureFx(layer,"AM Out Duration",durOut);
            else{
                ensureFx(layer,"AM In Duration",durIn);
                ensureFx(layer,"AM Out Duration",durOut);
            }
            if(isIn) ensureFx(layer,"AM In Delay",delayIn);
            else if(isOut) ensureFx(layer,"AM Out Delay",delayOut);
            else{
                ensureFx(layer,"AM In Delay",delayIn);
                ensureFx(layer,"AM Out Delay",delayOut);
            }
            if(p.engine!=="kfrm"){
                addTRMarkers(layer, mode, durIn, durOut);
            }
            if(hasSpring){
                var animator=layer.property("ADBE Text Properties").property("ADBE Text Animators").addProperty("ADBE Text Animator"); animator.name=isOut?"AM TextFlex Out":(isIn?"AM TextFlex In":"AM TextFlex");
                var props=animator.property("ADBE Text Animator Properties");
                if(p.pos.on)  taAddProp(props,"ADBE Text Position 3D",[p.pos.v[0],p.pos.v[1],p.pos.v[2]]);
                if(p.anc.on)  taAddProp(props,"ADBE Text Anchor Point 3D",[p.anc.v[0],p.anc.v[1],p.anc.v[2]]);
                if(p.rot.on){ if(is3D){ taAddProp(props,"ADBE Text Rotation X",p.rot.v[0]); taAddProp(props,"ADBE Text Rotation Y",p.rot.v[1]); } taAddProp(props,"ADBE Text Rotation",p.rot.v[2]); }
                if(p.scl.on)  taAddProp(props,"ADBE Text Scale 3D",[100+p.scl.v[0],100+p.scl.v[1],100]);
                if(p.skew.on){ taAddProp(props,"ADBE Text Skew",p.skew.v[0]); taAddProp(props,"ADBE Text Skew Axis",p.skew.v[1]); }
                if(p.trk.on)  taAddProp(props,"ADBE Text Tracking Amount",p.trk.v[0]);
                if(p.engine==="kfrm"){
                    applyTextKfrm(animator, p, layer, based);
                } else {
                    var selector=animator.property("ADBE Text Selectors").addProperty("ADBE Text Expressible Selector");
                    try{ selector.property("ADBE Text Range Type2").setValue(based); }catch(e){}
                    var amtSet=false;
                    try{ selector.property("ADBE Text Expressible Amount").expression=expr; amtSet=true; }catch(e){}
                    if(!amtSet){ try{ selector.property("Amount").expression=expr; }catch(e2){} }
                }
            }
            /* Opacity and Blur are always expression animations with their own
               Duration effects. They intentionally ignore the spring Decay. */
            var delayFxIn="AM In Delay", delayFxOut="AM Out Delay";
            var blurDurIn=(p.blur.inDur!==undefined?p.blur.inDur:p.blur.dur), blurDurOut=(p.blur.outDur!==undefined?p.blur.outDur:p.blur.dur);
            var opacDurIn=(p.opac.inDur!==undefined?p.opac.inDur:p.opac.dur), opacDurOut=(p.opac.outDur!==undefined?p.opac.outDur:p.opac.dur);
            if(p.blur.on){
                if(!isOut) addIndependentTextFade(layer,0,based,dir,"Blur",p.blur.v[0],blurDurIn,delayFxIn);
                if(!isIn)  addIndependentTextFade(layer,2,based,dir,"Blur",p.blur.v[0],blurDurOut,delayFxOut);
            }
            if(p.opac.on){
                if(!isOut) addIndependentTextFade(layer,0,based,dir,"Opacity",p.opac.v[0],opacDurIn,delayFxIn);
                if(!isIn)  addIndependentTextFade(layer,2,based,dir,"Opacity",p.opac.v[0],opacDurOut,delayFxOut);
            }
        }catch(e){ alert("Anim error:\n"+e.toString()); }
    }
    app.endUndoGroup();
    try{ ta_after(texts[0]); }catch(e){}
}
function animPresetFolder(){ var f=new Folder(Folder.userData.fsName+"/AmanowTools/anim_presets"); try{ if(!f.exists) f.create(); }catch(e){} return f; }
function animPresetSave(name, content){
    try{ name=String(name).replace(/[^0-9A-Za-z\u0400-\u04FF _-]/g,""); name=name.replace(/^\s+|\s+$/g,""); if(!name) return "ERR";
        var f=new File(animPresetFolder().fsName+"/"+name+".txt"); f.encoding="UTF-8"; f.open("w"); f.write(content); f.close(); return name;
    }catch(e){ return "ERR"; }
}
function animPresetList(){ var out=[]; try{ var files=animPresetFolder().getFiles("*.txt"); for(var i=0;i<files.length;i++){ out.push(decodeURI(files[i].name).replace(/\.txt$/,"")); } }catch(e){} return out.join("\n"); }
function animPresetLoad(name){ try{ var f=new File(animPresetFolder().fsName+"/"+name+".txt"); if(!f.exists) return ""; f.open("r"); var s=f.read(); f.close(); return s; }catch(e){ return ""; } }
function animPresetDelete(name){ try{ var f=new File(animPresetFolder().fsName+"/"+name+".txt"); if(f.exists) f.remove(); }catch(e){} return "ok"; }


/* ===================== SHAPE ANIM (keyframes, In/Out/Both) ===================== */
function easeAllBez(prop, infl){
    infl = clampN(infl, 0.1, 100);
    for(var k=1;k<=prop.numKeys;k++){
        try{ prop.setInterpolationTypeAtKey(k, KeyframeInterpolationType.BEZIER, KeyframeInterpolationType.BEZIER); }catch(e){}
        var dims=1; try{ var v=prop.keyValue(k); if(v instanceof Array) dims=v.length; }catch(e){}
        var a=[],b=[]; for(var d=0;d<dims;d++){ a.push(new KeyframeEase(0,infl)); b.push(new KeyframeEase(0,infl)); }
        try{ prop.setTemporalEaseAtKey(k,a,b); }catch(e1){ try{ prop.setTemporalEaseAtKey(k,[new KeyframeEase(0,infl)],[new KeyframeEase(0,infl)]); }catch(e2){} }
    }
}
function amtExpr(mode, variant){
    var head='';
    head+='var freq=Math.max(0.1,effect("AM Frequency")("Slider"));';
    head+='var dec=Math.max(0,effect("AM Decay")("Slider"));';
    if(mode==="both"){
        head+='var ctlDurIn=Math.max(thisComp.frameDuration,effect("AM In Duration")("Slider"));';
        head+='var ctlDurOut=Math.max(thisComp.frameDuration,effect("AM Out Duration")("Slider"));';
    }else if(mode==="out"){
        head+='var ctlDurOut=Math.max(thisComp.frameDuration,effect("AM Out Duration")("Slider"));var ctlDurIn=ctlDurOut;';
    }else{
        head+='var ctlDurIn=Math.max(thisComp.frameDuration,effect("AM In Duration")("Slider"));var ctlDurOut=ctlDurIn;';
    }
    head+='var dl=Math.max(0,effect("AM Delay")("Slider"))*thisComp.frameDuration;';
    head+='var B=effect("AM Bounce")("Slider")/100;if(B<0)B=0;if(B>1)B=1;';
    head+='function mt(nm,df){for(var k=1;k<=marker.numKeys;k++){if(marker.key(k).comment==nm)return marker.key(k).time;}return df;}';
    head+='var tIn=mt("TR In",Math.min(outPoint,inPoint+ctlDurIn));var tOut=mt("TR Out",Math.max(inPoint,outPoint-ctlDurOut));';
    head+='function ez(el,win,dur){if(el<=0)return 0;if(el>=win)return 1;var q=el/dur;var tail=1-el/win;var osc=(1-B)*Math.cos(2*Math.PI*freq*q)+B*Math.abs(Math.cos(Math.PI*freq*q));return 1-Math.exp(-dec*q)*osc*tail*tail;}';
    head+='var stIn=inPoint+dl;var winIn=Math.max(thisComp.frameDuration,tIn-stIn);';
    head+='var stOut=tOut+dl;var winOut=Math.max(thisComp.frameDuration,outPoint-stOut);';
    if(mode==="out"){
        return head+'var amount=(time<stOut)?1:1-ez(time-stOut,winOut,ctlDurOut);';
    } else if(mode==="both"){
        return head+'var ai=ez(time-stIn,winIn,ctlDurIn);var ao=(time<stOut)?1:1-ez(time-stOut,winOut,ctlDurOut);var amount=Math.min(ai,ao);';
    }
    return head+'var amount=ez(time-stIn,winIn,ctlDurIn);';
}
function shapeOpacityExpr(mode){
    var h='function sm(x){x=Math.max(0,Math.min(1,x));return x*x*(3-2*x);}';
    h+='function mt(nm,df){for(var k=1;k<=marker.numKeys;k++){if(marker.key(k).comment==nm)return marker.key(k).time;}return df;}';
    if(mode==="out"){
        h+='var d=Math.max(thisComp.frameDuration,effect("AM Out Opacity Duration")("Slider"));';
        h+='var s=mt("TR Out",Math.max(inPoint,outPoint-d));(1-sm((time-s)/d))*value;';
    }else if(mode==="both"){
        h+='var di=Math.max(thisComp.frameDuration,effect("AM In Opacity Duration")("Slider"));';
        h+='var dout=Math.max(thisComp.frameDuration,effect("AM Out Opacity Duration")("Slider"));';
        h+='var so=mt("TR Out",Math.max(inPoint,outPoint-dout));Math.min(sm((time-inPoint)/di),1-sm((time-so)/dout))*value;';
    }else{
        h+='var d=Math.max(thisComp.frameDuration,effect("AM In Opacity Duration")("Slider"));sm((time-inPoint)/d)*value;';
    }
    return h;
}
/* Remove all AmanowTools animation from the selected layers:
   TR markers + AM text animators + AM transform expressions + AM effect sliders. */
function am_resetAnim(){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to reset."); return; }
    app.beginUndoGroup("AMANOW Reset Anim");
    for(var i=0;i<sel.length;i++) clearAMLayer(sel[i]);
    app.endUndoGroup();
}
function shapeAnimCEP(cfg, mode, dur, ease){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers; if(sel.length===0){ alertU("Select layer(s)."); return; }
    /* One consistent high-quality default for every Shape preset and phase. */
    dur=1;
    var variant=cfg.variant||"normal";
    var DX=cfg.dx||0, DY=cfg.dy||0, ROT=cfg.rot||0, ROTX=cfg.rotX||0, ROTY=cfg.rotY||0;
    var hasPos=(DX!==0||DY!==0), hasRot=(ROT!==0), hasRotX=(ROTX!==0), hasRotY=(ROTY!==0), hasScale=(cfg.sx!==undefined&&cfg.sx!==null), fade=(cfg.fade!==false);
    var bncDef=60, freqDef=3, opacityDur=0.1;
    var modeNum=(mode==="out")?2:(mode==="both")?1:0;
    var amt=amtExpr(mode, variant);
    app.beginUndoGroup("AMANOW Shape Anim");
    for(var i=0;i<sel.length;i++){
        var Lr=sel[i]; var tg=Lr.property("ADBE Transform Group");
        try{
            clearAMLayer(Lr);
            ensureFx(Lr,"AM Delay",0);
            ensureFx(Lr,"AM Distance",100);
            ensureFx(Lr,"AM Frequency",freqDef);
            ensureFx(Lr,"AM Decay",3);
            if(modeNum!==2) ensureFx(Lr,"AM In Duration",dur);
            if(modeNum!==0) ensureFx(Lr,"AM Out Duration",dur);
            ensureFx(Lr,"AM Bounce",bncDef);
            if(fade){
                if(modeNum!==2) ensureFx(Lr,"AM In Opacity Duration",opacityDur);
                if(modeNum!==0) ensureFx(Lr,"AM Out Opacity Duration",opacityDur);
            }
            addTRMarkers(Lr, modeNum, dur, dur);
            if(hasPos)   tg.property("ADBE Position").expression   = amt+'var ds=effect("AM Distance")("Slider")/100;var ox=('+DX+')*ds*(1-amount),oy=('+DY+')*ds*(1-amount);(value.length>2)?value+[ox,oy,0]:value+[ox,oy];';
            if(hasScale) tg.property("ADBE Scale").expression      = amt+'var sx='+cfg.sx+',sy='+cfg.sy+';var rx=sx+(value[0]-sx)*amount,ry=sy+(value[1]-sy)*amount;(value.length>2)?[rx,ry,value[2]]:[rx,ry];';
            if(fade)     tg.property("ADBE Opacity").expression    = shapeOpacityExpr(mode);
            if(hasRotX||hasRotY){ try{ Lr.threeDLayer=true; }catch(e3d){} }
            if(hasRot)   tg.property("ADBE Rotate Z").expression   = amt+'value+('+ROT+')*(1-amount);';
            if(hasRotX)  tg.property("ADBE Rotate X").expression   = amt+'value+('+ROTX+')*(1-amount);';
            if(hasRotY)  tg.property("ADBE Rotate Y").expression   = amt+'value+('+ROTY+')*(1-amount);';
        }catch(e){ alert("Shape anim error:\n"+e.toString()); }
    }
    app.endUndoGroup();
}


/* ===================== LAYER COLOR (swatches) ===================== */
function setShapeFills(group, col){
    for(var i=1;i<=group.numProperties;i++){
        var p=group.property(i);
        try{
            if(p.matchName==="ADBE Vector Graphic - Fill"){ p.property("ADBE Vector Fill Color").setValue(col); }
            else if(p.numProperties && p.numProperties>0){ setShapeFills(p,col); }
        }catch(e){}
    }
}
function setLayerColor(labelIndex){
    var comp=actComp(); if(!comp){ alertU("Open a composition."); return; }
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to change color."); return; }
    var idx=Math.round(labelIndex); if(idx<0)idx=0; if(idx>16)idx=16;
    app.beginUndoGroup("AMANOW Layer Label Color");
    for(var i=0;i<sel.length;i++){ try{ sel[i].label=idx; }catch(e){} }
    app.endUndoGroup();
}


/* ===================== CREATE / DOCK helpers ===================== */
function createAdjLayer(){
    var comp=actComp(); if(!comp) return;
    app.beginUndoGroup("Adjustment Layer");
    try{ var s=comp.layers.addSolid([1,1,1],"Adjustment Layer",comp.width,comp.height,1); s.adjustmentLayer=true; deselectAll(comp); s.selected=true; }catch(e){}
    app.endUndoGroup();
}
function createSolidColor(r,g,b){
    var comp=actComp(); if(!comp) return;
    app.beginUndoGroup("Solid");
    try{ var s=comp.layers.addSolid([r,g,b],"Solid",comp.width,comp.height,1); deselectAll(comp); s.selected=true; }catch(e){}
    app.endUndoGroup();
}
function preCompose(){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to pre-compose."); return; }
    try{ var mid=app.findMenuCommandId("Pre-compose..."); if(mid){ app.executeCommand(mid); return; } }catch(e){}
    // fallback (no dialog)
    app.beginUndoGroup("Pre-compose");
    try{ var idx=[]; for(var i=0;i<sel.length;i++) idx.push(sel[i].index); idx.sort(function(a,b){return a-b;}); comp.layers.precompose(idx,"Pre-comp 1",true); }
    catch(e2){ alert("Pre-compose error:\n"+e2.toString()); }
    app.endUndoGroup();
}

// ---- Un Pre-compose: pull the layers of a selected pre-comp back into the current comp ----
function am_unPreOne(comp, pre){
    var src=pre.source;
    try{
        var ptg=pre.property("ADBE Transform Group");
        var pPos=ptg.property("ADBE Position").value;
        var pAnc=ptg.property("ADBE Anchor Point").value;
        var pScale=ptg.property("ADBE Scale").value;
        var pRot=0; try{ pRot=ptg.property("ADBE Rotate Z").value; }catch(e){}

        var cmdSelAll=app.findMenuCommandId("Select All"); if(!cmdSelAll) cmdSelAll=2004;
        var cmdCopy=app.findMenuCommandId("Copy"); if(!cmdCopy) cmdCopy=18;
        var cmdPaste=app.findMenuCommandId("Paste"); if(!cmdPaste) cmdPaste=19;

        src.openInViewer();
        app.executeCommand(cmdSelAll);
        app.executeCommand(cmdCopy);
        comp.openInViewer();
        app.executeCommand(cmdPaste);

        var pasted=comp.selectedLayers;
        if(pasted && pasted.length>0){
            var nul=comp.layers.addNull();
            nul.name="UnPre Anchor";
            var ntg=nul.property("ADBE Transform Group");
            try{ ntg.property("ADBE Anchor Point").setValue(pAnc); }catch(e){}
            try{ ntg.property("ADBE Position").setValue(pPos); }catch(e){}
            try{ ntg.property("ADBE Scale").setValue(pScale); }catch(e){}
            try{ ntg.property("ADBE Rotate Z").setValue(pRot); }catch(e){}
            try{ nul.moveBefore(pasted[pasted.length-1]); }catch(e){}
            for(var j=0;j<pasted.length;j++){ try{ pasted[j].parent=nul; }catch(e){} }
            try{ pre.remove(); }catch(e){}
        }
    }catch(err){ /* skip this one, keep going with the rest */ }
}
function unPreCompose(){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers;
    /* collect EVERY selected pre-comp layer (references stay valid as we remove) */
    var pres=[];
    for(var i=0;i<sel.length;i++){ if(sel[i].source && (sel[i].source instanceof CompItem)) pres.push(sel[i]); }
    if(pres.length===0){ alertU("Select one or more pre-comp layers to un-precompose."); return; }
    app.beginUndoGroup("Un Pre-compose");
    for(var p=0;p<pres.length;p++){ am_unPreOne(comp, pres[p]); }
    app.endUndoGroup();
}

// ---- Center: align 2+ selected layers so their centers sit on a common point ----
function am_layerCenter(layer, t){
    var tg=layer.property("ADBE Transform Group");
    var pos=tg.property("ADBE Position").value;
    var cx=pos[0], cy=pos[1];
    try{
        var anc=tg.property("ADBE Anchor Point").value;
        var scl=tg.property("ADBE Scale").value;
        var r=layer.sourceRectAtTime(t, false);
        var lcx=r.left + r.width/2, lcy=r.top + r.height/2;
        cx = pos[0] + (lcx - anc[0]) * (scl[0]/100);
        cy = pos[1] + (lcy - anc[1]) * (scl[1]/100);
    }catch(e){}
    return [cx, cy];
}
function centerLayers(mode){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers;
    var avs=[];
    for(var i=0;i<sel.length;i++){
        var L=sel[i];
        if((typeof CameraLayer!=="undefined" && L instanceof CameraLayer) ||
           (typeof LightLayer!=="undefined" && L instanceof LightLayer)) continue;
        avs.push(L);
    }
    if(avs.length<2){ alertU("Select at least 2 layers to center them on each other."); return; }
    avs.sort(function(a,b){ return a.index-b.index; }); // index 1 = top of stack
    var ctrl=(mode==1 || mode==="1");
    var anchor = ctrl ? avs[0] : avs[avs.length-1];
    var t=comp.time;
    app.beginUndoGroup("Center Layers");
    try{
        var ac=am_layerCenter(anchor, t);
        for(var j=0;j<avs.length;j++){
            if(avs[j]===anchor) continue;
            var cur=am_layerCenter(avs[j], t);
            am_offsetPos(avs[j], ac[0]-cur[0], ac[1]-cur[1]);
        }
    }catch(err){ alert("Center error:\n"+err.toString()); }
    app.endUndoGroup();
}
function am_offsetPos(layer, dx, dy){
    if(dx===0 && dy===0) return;
    var posProp=layer.property("ADBE Transform Group").property("ADBE Position");
    try{
        if(posProp.numKeys>0){
            for(var k=1;k<=posProp.numKeys;k++){
                var v=posProp.keyValue(k);
                posProp.setValueAtKey(k, (v.length>=3)?[v[0]+dx,v[1]+dy,v[2]]:[v[0]+dx,v[1]+dy]);
            }
        } else {
            var p=posProp.value;
            posProp.setValue((p.length>=3)?[p[0]+dx,p[1]+dy,p[2]]:[p[0]+dx,p[1]+dy]);
        }
    }catch(ePos){
        try{
            var tg2=layer.property("ADBE Transform Group");
            var px=tg2.property("ADBE Position_0"), py=tg2.property("ADBE Position_1");
            if(px&&py){ px.setValue(px.value+dx); py.setValue(py.value+dy); }
        }catch(eSep){}
    }
}

function duplicateLayers(){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to duplicate."); return; }
    app.beginUndoGroup("Duplicate");
    try{ for(var i=sel.length-1;i>=0;i--){ sel[i].duplicate(); } }catch(e){}
    app.endUndoGroup();
}
function importFiles(){
    try{ app.project.importFileWithDialog(); }
    catch(e){ try{ var f=File.openDialog("Import file"); if(f){ app.project.importFile(new ImportOptions(f)); } }catch(e2){} }
}
function alignLayers(mode){
    var comp=actComp(); if(!comp) return;
    var sel=comp.selectedLayers; if(!sel||sel.length===0){ alertU("Select layer(s) to align."); return; }
    var t=comp.time, W=comp.width, H=comp.height;

    /* ---- Distribute: equal spacing between layer centers ---- */
    if(mode==="dh" || mode==="dv"){
        if(sel.length<3){ alertU("Select at least 3 layers to distribute evenly."); return; }
        app.beginUndoGroup("Distribute");
        var arr=[];
        for(var i=0;i<sel.length;i++){
            try{
                var L0=sel[i], tg0=L0.property("ADBE Transform Group");
                var pos0=tg0.property("ADBE Position");
                var anc0=tg0.property("ADBE Anchor Point").value;
                var scl0=tg0.property("ADBE Scale").value;
                var r0=L0.sourceRectAtTime(t,false);
                var sx0=scl0[0]/100, sy0=scl0[1]/100;
                var lx0=(r0.left-anc0[0])*sx0, ty0=(r0.top-anc0[1])*sy0, w0=r0.width*sx0, h0=r0.height*sy0;
                var pv0=pos0.value.slice();
                arr.push({pos:pos0, pv:pv0, lx:lx0, ty:ty0, w:w0, h:h0, cx:pv0[0]+lx0+w0/2, cy:pv0[1]+ty0+h0/2});
            }catch(e){}
        }
        if(arr.length>=3){
            if(mode==="dh"){
                arr.sort(function(a,b){ return a.cx-b.cx; });
                var span=arr[arr.length-1].cx-arr[0].cx, step=span/(arr.length-1);
                for(var k=1;k<arr.length-1;k++){ var tc=arr[0].cx+k*step; var p=arr[k].pv.slice(); p[0]=tc-arr[k].lx-arr[k].w/2; try{ arr[k].pos.setValue(p); }catch(eK){} }
            } else {
                arr.sort(function(a,b){ return a.cy-b.cy; });
                var spanY=arr[arr.length-1].cy-arr[0].cy, stepY=spanY/(arr.length-1);
                for(var k2=1;k2<arr.length-1;k2++){ var tcy=arr[0].cy+k2*stepY; var p2=arr[k2].pv.slice(); p2[1]=tcy-arr[k2].ty-arr[k2].h/2; try{ arr[k2].pos.setValue(p2); }catch(eK2){} }
            }
        }
        app.endUndoGroup();
        return;
    }

    app.beginUndoGroup("Align");
    for(var i=0;i<sel.length;i++){
        var L=sel[i];
        try{
            var tg=L.property("ADBE Transform Group");
            var pos=tg.property("ADBE Position");
            var anc=tg.property("ADBE Anchor Point").value;
            var scl=tg.property("ADBE Scale").value;
            var r=L.sourceRectAtTime(t,false);
            var sx=scl[0]/100, sy=scl[1]/100;
            var lx=(r.left-anc[0])*sx, ty=(r.top-anc[1])*sy, w=r.width*sx, h=r.height*sy;
            var p=pos.value.slice();
            if(mode==="left") p[0]=-lx;
            else if(mode==="right") p[0]=W-lx-w;
            else if(mode==="cx") p[0]=W/2-lx-w/2;
            else if(mode==="top") p[1]=-ty;
            else if(mode==="bottom") p[1]=H-ty-h;
            else if(mode==="cy") p[1]=H/2-ty-h/2;
            pos.setValue(p);
        }catch(e){}
    }
    app.endUndoGroup();
}

/* ===================== EXPORT ===================== */
function exportComp(){
    var comp=actComp();
    if(!comp){ alertU("Open a composition to export."); return; }
    app.beginUndoGroup("AmanowTools Export");
    try{
        app.project.renderQueue.items.add(comp);
        try{ app.executeCommand(app.findMenuCommandId("Render Queue")); }catch(e){}
    }catch(err){ alert("Export error:\n"+err.toString()); }
    app.endUndoGroup();
}

/* ===================== LICENSE: device fingerprint ===================== */
/* ===================== TRIAL (persistent install timestamp, multi-store) ===================== */
function amTrialDir(){ return Folder.userData.fsName + "/AmanowTools"; }
function amTrialFile(){ return new File(amTrialDir() + "/trial.dat"); }
function amTrialReadFile(){
    try{ var f=amTrialFile(); if(!f.exists) return ""; f.open("r"); var s=f.read(); f.close(); return s||""; }catch(e){ return ""; }
}
function amTrialWriteFile(v){
    try{ var dir=new Folder(amTrialDir()); if(!dir.exists) dir.create(); var f=amTrialFile(); f.open("w"); f.write(String(v)); f.close(); return true; }catch(e){ return false; }
}
/* second durable store: After Effects preferences (survives plugin re-install) */
function amCfgGet(){ try{ if(app.settings.haveSetting("AmanowTools","trial")) return String(app.settings.getSetting("AmanowTools","trial")); }catch(e){} return ""; }
function amCfgSet(v){ try{ app.settings.saveSetting("AmanowTools","trial", String(v)); }catch(e){} }

function amParsePair(s, now){
    var i=now, l=now;
    if(s && s.indexOf("|")>=0){ var p=s.split("|"); var a=parseFloat(p[0]), b=parseFloat(p[1]); if(!isNaN(a)&&a>0) i=a; if(!isNaN(b)&&b>0) l=b; }
    return { i:i, l:l };
}
/* write the reconciled pair to BOTH durable host stores */
function amTrialSet(install, lastSeen){
    var now=(new Date()).getTime();
    install=parseFloat(install); lastSeen=parseFloat(lastSeen);
    if(isNaN(install)||install<=0) install=now;
    if(isNaN(lastSeen)||lastSeen<install) lastSeen=install;
    var v=install+"|"+lastSeen;
    amTrialWriteFile(v);
    amCfgSet(v);
    return v;
}
/* create on first run; reconcile file + AE-prefs (earliest install, latest last-seen); advance highwater */
function amTrialStamp(){
    var now=(new Date()).getTime();
    var a=amParsePair(amTrialReadFile(), now);
    var b=amParsePair(amCfgGet(), now);
    var install=Math.min(a.i, b.i);
    var last=Math.max(a.l, b.l, now);
    return amTrialSet(install, last);
}

/* ---- stable, cross-platform device id: Windows MachineGuid / macOS IOPlatformUUID (cached) ---- */
function amHexUuid(s){
    if(!s) return "";
    var m=String(s).toUpperCase().match(/[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}/);
    if(m) return m[0];
    var h=String(s).toUpperCase().replace(/[^0-9A-F]/g,"");
    return (h.length>=24)? h.substr(0,32) : "";
}
function amHardwareId(){
    try{
        if(typeof system==="undefined" || !system.callSystem) return "";
        var os=""; try{ os=String($.os); }catch(e){}
        var isWin=(os.indexOf("Windows")>=0 || os.indexOf("Win")>=0);
        var out="";
        if(isWin){
            try{ out=system.callSystem('cmd.exe /c reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid'); }catch(e1){ out=""; }
            var idw=amHexUuid(out);
            if(idw) return idw;
            try{ out=system.callSystem('cmd.exe /c wmic csproduct get UUID'); }catch(e2){ out=""; }
            return amHexUuid(out);
        } else {
            try{ out=system.callSystem('/bin/sh -c "ioreg -rd1 -c IOPlatformExpertDevice | grep -i IOPlatformUUID"'); }catch(e3){ out=""; }
            var idm=amHexUuid(out);
            if(idm) return idm;
            try{ out=system.callSystem('/bin/sh -c "system_profiler SPHardwareDataType | grep -i UUID"'); }catch(e4){ out=""; }
            return amHexUuid(out);
        }
    }catch(e){ return ""; }
}
function amDevCacheFile(){ return new File(amTrialDir() + "/dev.dat"); }
function amDevCacheRead(){
    try{ var f=amDevCacheFile(); if(!f.exists) return ""; f.open("r"); var s=f.read(); f.close(); return s?String(s).replace(/^\s+|\s+$/g,""):""; }catch(e){ return ""; }
}
function amDevCacheWrite(v){
    try{ var dir=new Folder(amTrialDir()); if(!dir.exists) dir.create(); var f=amDevCacheFile(); f.open("w"); f.write(String(v)); f.close(); }catch(e){}
}
function amDeviceRaw(){
    /* cached id -> stable, and avoids running a shell command on every launch */
    var c=amDevCacheRead();
    if(c && c.length>=6) return c;
    var hw=amHardwareId();
    var raw;
    if(hw && hw.length>=6){ raw="HW:"+hw; }
    else {
        /* fallback that does NOT include the OS version, so system updates don't change the id */
        var user="", home="";
        try{ user=String($.getenv("USER")||$.getenv("USERNAME")||$.getenv("LOGNAME")||""); }catch(e){}
        try{ home=String($.getenv("HOME")||$.getenv("USERPROFILE")||""); }catch(e){}
        raw="SW:"+user+"|"+home;
    }
    amDevCacheWrite(raw);
    return raw;
}



/* ===================== AUTO-UPDATE (host side) =====================
   CEP here has no Node.js, so the panel asks the host to do the work.
   We write a small system script (PowerShell on Windows, sh on macOS) that
   downloads the archive, unpacks it, backs up the current plugin, copies the
   new files over it, verifies the result and rolls back if anything fails. */
function am_extRoot(){
    try{ return File($.fileName).parent.parent.fsName; }catch(e){ return ""; }
}
function am_pluginVersion(root){
    try{
        root = String(root || "");

        if(!root){
            root = am_extRoot();
        }

        var f = new File(root + "/CSXS/manifest.xml");

        if(!f.exists){
            return "";
        }

        f.open("r");
        var s = f.read();
        f.close();

        var m = String(s).match(
            /ExtensionBundleVersion\s*=\s*"([^"]+)"/
        );

        return m ? m[1] : "";
    }catch(e){
        return "";
    }
}
function am_updWrite(path, text, unixLF){
    var f=new File(path);
    f.encoding="UTF-8";
    f.lineFeed = unixLF ? "Unix" : "Windows";
    f.open("w"); f.write(text); f.close();
    return f;
}
function am_selfUpdate(url){
    try{
        if(!url) return "ERR: no download url";
        var root=am_extRoot();
        if(!root) return "ERR: cannot locate the plugin folder";
        var isWin=(Folder.fs==="Windows");
        var sep=isWin?"\\":"/";
        var tdir=Folder.temp.fsName+sep+"amanow_update";
        var tf=new Folder(tdir); if(!tf.exists) tf.create();
        var resF=new File(tdir+sep+"result.txt");
        if(resF.exists) resF.remove();
        var L=[], cmd, sf;
        if(isWin){
            L.push("$ErrorActionPreference='Stop'");
            L.push("$url='"+url+"'");
            L.push("$ext='"+root+"'");
            L.push("$tmp='"+tdir+"'");
            L.push("$res=Join-Path $tmp 'result.txt'");
            L.push("try{");
            L.push("  [Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12");
            L.push("  $zip=Join-Path $tmp 'u.zip'");
            L.push("  $x=Join-Path $tmp 'x'");
            L.push("  if(Test-Path $x){ Remove-Item $x -Recurse -Force }");
            L.push("  if(Test-Path $zip){ Remove-Item $zip -Force }");
            L.push("  Invoke-WebRequest -Uri $url -OutFile $zip -UseBasicParsing");
            L.push("  Add-Type -AssemblyName System.IO.Compression.FileSystem");
            L.push("  [System.IO.Compression.ZipFile]::ExtractToDirectory($zip,$x)");
            L.push("  $mf=Get-ChildItem -Path $x -Recurse -Filter manifest.xml | Where-Object { $_.Directory.Name -eq 'CSXS' } | Select-Object -First 1");
            L.push("  if(-not $mf){ throw 'manifest.xml not found inside the archive' }");
            L.push("  $src=$mf.Directory.Parent.FullName");
            L.push("  foreach($f in @('index.html','js\\main.js','jsx\\host.jsx','css\\style.css')){ if(-not (Test-Path (Join-Path $src $f))){ throw ('missing in archive: '+$f) } }");
            L.push("  $bak=$ext+'.bak'");
            L.push("  if(Test-Path $bak){ Remove-Item $bak -Recurse -Force }");
            L.push("  Copy-Item -Path $ext -Destination $bak -Recurse -Force");
            L.push("  Copy-Item -Path (Join-Path $src '*') -Destination $ext -Recurse -Force");
            L.push("  foreach($f in @('index.html','js\\main.js','jsx\\host.jsx','CSXS\\manifest.xml')){ if(-not (Test-Path (Join-Path $ext $f))){ throw ('copy failed: '+$f) } }");
            L.push("  Remove-Item $x -Recurse -Force");
            L.push("  Remove-Item $zip -Force");
            L.push("  Set-Content -Path $res -Value 'OK' -Encoding ASCII");
            L.push("}catch{");
            L.push("  $msg=$_.Exception.Message");
            L.push("  try{ $bak=$ext+'.bak'; if(Test-Path $bak){ Copy-Item -Path (Join-Path $bak '*') -Destination $ext -Recurse -Force } }catch{}");
            L.push("  Set-Content -Path $res -Value ('ERR: '+$msg) -Encoding ASCII");
            L.push("}");
            sf=am_updWrite(tdir+"\\am_update.ps1", L.join("\r\n"), false);
            var psx=($.getenv("SystemRoot")||"C:\\Windows")+"\\System32\\WindowsPowerShell\\v1.0\\powershell.exe";
            cmd='cmd.exe /c ""'+psx+'" -NoProfile -ExecutionPolicy Bypass -File "'+sf.fsName+'""';
        } else {
            L.push("#!/bin/sh");
            L.push("URL='"+url+"'");
            L.push("EXT='"+root+"'");
            L.push("TMP='"+tdir+"'");
            L.push('RES="$TMP/result.txt"');
            L.push('fail(){ echo "ERR: $1" > "$RES"; exit 0; }');
            L.push('ZIP="$TMP/u.zip"; X="$TMP/x"');
            L.push('rm -rf "$X" "$ZIP"; mkdir -p "$X" || fail "cannot create temp folder"');
            L.push('curl -fsSL "$URL" -o "$ZIP" || fail "download failed"');
            L.push('unzip -oq "$ZIP" -d "$X" || fail "unpack failed"');
            L.push("MF=`find \"$X\" -type f -path '*/CSXS/manifest.xml' | head -n 1`");
            L.push('[ -n "$MF" ] || fail "manifest.xml not found inside the archive"');
            L.push('SRCD=`dirname "$MF"`; SRC=`dirname "$SRCD"`');
            L.push('for f in index.html js/main.js jsx/host.jsx css/style.css; do [ -f "$SRC/$f" ] || fail "missing in archive: $f"; done');
            L.push('BAK="$EXT.bak"; rm -rf "$BAK"; cp -R "$EXT" "$BAK" || fail "backup failed"');
            L.push('cp -R "$SRC/." "$EXT/" || { rm -rf "$EXT"; cp -R "$BAK" "$EXT"; fail "copy failed"; }');
            L.push('for f in index.html js/main.js jsx/host.jsx CSXS/manifest.xml; do [ -f "$EXT/$f" ] || { rm -rf "$EXT"; cp -R "$BAK" "$EXT"; fail "copy incomplete: $f"; }; done');
            L.push('xattr -cr "$EXT" >/dev/null 2>&1');
            L.push('rm -rf "$X" "$ZIP"');
            L.push('echo OK > "$RES"');
            sf=am_updWrite(tdir+"/am_update.sh", L.join("\n"), true);
            cmd='/bin/sh "'+sf.fsName+'"';
        }
        system.callSystem(cmd);
        if(!resF.exists) return "ERR: the updater could not start";
        resF.open("r"); var out=String(resF.read()); resF.close();
        out=out.replace(/^\s+|\s+$/g,"");
        return out||"ERR: empty result";
    }catch(e){ return "ERR: "+e.toString(); }
}

"AmanowTools host loaded";
