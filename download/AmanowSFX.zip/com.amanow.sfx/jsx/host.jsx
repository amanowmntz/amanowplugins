// AmanowSFX  ExtendScript host for Adobe Premiere Pro (ES3)
// All functions are GLOBAL so they can be called via CSInterface.evalScript.
#target premierepro

var AM_SFX_BIN = "AmanowSFX SFX";

// --- sanity ping ---
function am_ping() { return "ok"; }

// --- does an active sequence exist? ---
function am_hasSeq() {
    try { return (app.project && app.project.activeSequence) ? "1" : "0"; }
    catch (e) { return "0"; }
}

// --- current playhead position in seconds (or -1) ---
function am_playhead() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return "-1";
        return String(seq.getPlayerPosition().seconds);
    } catch (e) { return "-1"; }
}

// --- find (or create) the destination bin in the project ---
function amFindBin(name) {
    var root = app.project.rootItem;
    var n = root.children.numItems;
    for (var i = 0; i < n; i++) {
        var it = root.children[i];
        try { if (it && it.name === name && it.type === 2) return it; } catch (e) {}
    }
    try { return root.createBin(name); } catch (e2) { return root; }
}

// --- compare two media paths tolerant of slash/case differences ---
function amSamePath(a, b) {
    if (!a || !b) return false;
    a = String(a); b = String(b);
    if (a === b) return true;
    var x = a.replace(/\\/g, "/").toLowerCase();
    var y = b.replace(/\\/g, "/").toLowerCase();
    return x === y;
}

// --- find an already-imported item in the bin by media path ---
function amFindItemByPath(bin, p) {
    var n = bin.children.numItems;
    for (var i = 0; i < n; i++) {
        var c = bin.children[i];
        try {
            if (c && c.getMediaPath) {
                if (amSamePath(c.getMediaPath(), p)) return c;
            }
        } catch (e) {}
    }
    return null;
}

// --- pick the targeted audio track, fall back to the first one ---
function amTargetAudioIndex(seq) {
    var idx = 0;
    try {
        var na = seq.audioTracks.numTracks;
        for (var a = 0; a < na; a++) {
            var tr = seq.audioTracks[a];
            if (tr && tr.isTargeted && tr.isTargeted()) { idx = a; break; }
        }
    } catch (e) {}
    return idx;
}

// --- place a project item on the timeline at a given time (seconds) ---
function amPlace(item, atSeconds) {
    var seq = app.project.activeSequence;
    if (!seq) return false;
    var idx = amTargetAudioIndex(seq);
    var track = null;
    try { track = seq.audioTracks[idx]; } catch (e) {}
    if (!track) return false;

    var t;
    if (atSeconds !== undefined && atSeconds !== null && Number(atSeconds) >= 0) t = Number(atSeconds);
    else { try { t = seq.getPlayerPosition().seconds; } catch (e2) { t = 0; } }

    // try seconds (number) -> Time object -> insertClip, in order
    try { track.overwriteClip(item, t); return true; } catch (e3) {}
    try { var T = new Time(); T.seconds = t; track.overwriteClip(item, T); return true; } catch (e4) {}
    try { track.insertClip(item, t); return true; } catch (e5) {}
    return false;
}

// --- import one file, optionally place it; returns a status string ---
// p          : absolute media path
// atSeconds  : where to place it (seconds), or -1 for "current playhead / none"
// doPlace    : "true" / "1" to drop it on the timeline
function am_add(p, atSeconds, doPlace) {
    try {
        if (!p) return "ERR: empty path";
        var bin = amFindBin(AM_SFX_BIN);

        var item = amFindItemByPath(bin, p);
        if (!item) {
            var before = bin.children.numItems;
            app.project.importFiles([p], true, bin, false);
            item = amFindItemByPath(bin, p);
            if (!item && bin.children.numItems > before) {
                item = bin.children[bin.children.numItems - 1];
            }
        }

        var wantPlace = (doPlace === true || doPlace === "true" || doPlace === 1 || doPlace === "1");
        var placed = false;
        if (wantPlace && item) placed = amPlace(item, atSeconds);

        if (placed) return "OK|placed";
        if (item) return "OK|imported";
        return "ERR: import failed";
    } catch (err) {
        return "ERR: " + err.toString();
    }
}

// --- select the destination bin in the Project panel (best effort) ---
function am_revealBin() {
    try {
        var bin = amFindBin(AM_SFX_BIN);
        if (bin && bin.select) { try { bin.select(); } catch (e) {} }
        return bin ? "OK" : "ERR";
    } catch (e2) { return "ERR"; }
}

// ===================== EFFECT: read selected clip + replace =====================

// escape a string for embedding inside our hand-built JSON
function amJsonEsc(s) {
    return String(s).replace(/\\/g, "\\\\").replace(/"/g, '\\"');
}

// return the first selected AUDIO clip on the active sequence as JSON
function am_getSelectedAudio() {
    try {
        var seq = app.project.activeSequence;
        if (!seq) return "ERR: no active sequence";
        var sel = null;
        try { sel = seq.getSelection(); } catch (e) { sel = null; }
        if (!sel || !sel.length) return "ERR: select a clip on the timeline";
        var item = null;
        for (var i = 0; i < sel.length; i++) {
            try { if (sel[i] && String(sel[i].mediaType) === "Audio") { item = sel[i]; break; } } catch (e2) {}
        }
        if (!item) return "ERR: select an AUDIO clip";
        var path = "";
        try { path = item.projectItem.getMediaPath(); } catch (e3) { path = ""; }
        if (!path) return "ERR: clip has no source file";
        var inP = 0, outP = 0, startP = 0, dur = 0, nm = "";
        try { inP = Number(item.inPoint.seconds); } catch (e4) {}
        try { outP = Number(item.outPoint.seconds); } catch (e5) {}
        try { startP = Number(item.start.seconds); } catch (e6) {}
        try { dur = Number(item.duration.seconds); } catch (e7) {}
        try { nm = item.name; } catch (e8) {}
        if (!(outP > inP)) { outP = inP + (dur > 0 ? dur : 0); }
        return '{"ok":true,"name":"' + amJsonEsc(nm) + '","path":"' + amJsonEsc(path) +
               '","in":' + inP + ',"out":' + outP + ',"start":' + startP + ',"dur":' + dur + '}';
    } catch (err) { return "ERR: " + err.toString(); }
}

// locate which audio track holds a given selected trackItem (by start/end match)
function amFindTrackOfItem(seq, item) {
    try {
        var na = seq.audioTracks.numTracks;
        for (var t = 0; t < na; t++) {
            var tr = seq.audioTracks[t];
            var nc = tr.clips.numItems;
            for (var c = 0; c < nc; c++) {
                var cl = tr.clips[c];
                try {
                    if (Math.abs(Number(cl.start.seconds) - Number(item.start.seconds)) < 0.0006 &&
                        Math.abs(Number(cl.end.seconds) - Number(item.end.seconds)) < 0.0006) {
                        return { track: tr, index: t };
                    }
                } catch (e) {}
            }
        }
    } catch (e2) {}
    return null;
}

// import the processed file and overwrite it onto the selected clip's spot
function am_replaceSelected(path) {
    try {
        if (!path) return "ERR: empty path";
        var seq = app.project.activeSequence;
        if (!seq) return "ERR: no active sequence";
        var sel = null;
        try { sel = seq.getSelection(); } catch (e) { sel = null; }
        if (!sel || !sel.length) return "ERR: the clip is no longer selected";
        var item = null;
        for (var i = 0; i < sel.length; i++) {
            try { if (sel[i] && String(sel[i].mediaType) === "Audio") { item = sel[i]; break; } } catch (e2) {}
        }
        if (!item) return "ERR: select an AUDIO clip";

        var startSec = 0;
        try { startSec = Number(item.start.seconds); } catch (e3) {}
        var loc = amFindTrackOfItem(seq, item);
        var track = loc ? loc.track : null;

        var bin = amFindBin(AM_SFX_BIN);
        var before = bin.children.numItems;
        app.project.importFiles([path], true, bin, false);
        var newItem = amFindItemByPath(bin, path);
        if (!newItem && bin.children.numItems > before) newItem = bin.children[bin.children.numItems - 1];
        if (!newItem) return "ERR: import failed";

        var placed = false;
        if (track) {
            try { track.overwriteClip(newItem, startSec); placed = true; } catch (e4) {}
            if (!placed) { try { var T = new Time(); T.seconds = startSec; track.overwriteClip(newItem, T); placed = true; } catch (e5) {} }
        }
        if (!placed) placed = amPlace(newItem, startSec);
        return placed ? "OK|replaced" : "ERR: could not place processed clip";
    } catch (err) { return "ERR: " + err.toString(); }
}

/* ===================== LICENSE: device fingerprint + persistent trial (Premiere) ===================== */
function amTrialDir(){ return Folder.userData.fsName + "/AmanowSFX"; }
function amTrialFile(){ return new File(amTrialDir() + "/trial.dat"); }
function amTrialReadFile(){
    try{ var f=amTrialFile(); if(!f.exists) return ""; f.open("r"); var s=f.read(); f.close(); return s||""; }catch(e){ return ""; }
}
function amTrialWriteFile(v){
    try{ var dir=new Folder(amTrialDir()); if(!dir.exists) dir.create(); var f=amTrialFile(); f.open("w"); f.write(String(v)); f.close(); return true; }catch(e){ return false; }
}
/* second durable store: a sibling file OUTSIDE the AmanowSFX folder, so clearing one store alone can't reset the trial */
function amCfgFile(){ return new File(Folder.userData.fsName + "/.amanow_sfx.dat"); }
function amCfgGet(){ try{ var f=amCfgFile(); if(!f.exists) return ""; f.open("r"); var s=f.read(); f.close(); return s||""; }catch(e){ return ""; } }
function amCfgSet(v){ try{ var f=amCfgFile(); f.open("w"); f.write(String(v)); f.close(); }catch(e){} }
function amParsePair(s, now){
    var i=now, l=now;
    if(s && s.indexOf("|")>=0){ var p=s.split("|"); var a=parseFloat(p[0]), b=parseFloat(p[1]); if(!isNaN(a)&&a>0) i=a; if(!isNaN(b)&&b>0) l=b; }
    return { i:i, l:l };
}
function amTrialSet(install, lastSeen){
    var now=(new Date()).getTime();
    install=parseFloat(install); lastSeen=parseFloat(lastSeen);
    if(isNaN(install)||install<=0) install=now;
    if(isNaN(lastSeen)||lastSeen<install) lastSeen=install;
    var v=install+"|"+lastSeen;
    amTrialWriteFile(v);
    amCfgSet(v);
    return v;
}
function amTrialStamp(){
    var now=(new Date()).getTime();
    var a=amParsePair(amTrialReadFile(), now);
    var b=amParsePair(amCfgGet(), now);
    var install=Math.min(a.i, b.i);
    var last=Math.max(a.l, b.l, now);
    return amTrialSet(install, last);
}
function amHexUuid(s){
    if(!s) return "";
    var m=String(s).toUpperCase().match(/[0-9A-F]{8}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{4}-[0-9A-F]{12}/);
    if(m) return m[0];
    var h=String(s).toUpperCase().replace(/[^0-9A-F]/g,"");
    return (h.length>=24)? h.substr(0,32) : "";
}
function amHardwareId(){
    try{
        if(typeof system==="undefined" || !system.callSystem) return "";
        var os=""; try{ os=String($.os); }catch(e){}
        var isWin=(os.indexOf("Windows")>=0 || os.indexOf("Win")>=0);
        var out="";
        if(isWin){
            try{ out=system.callSystem('cmd.exe /c reg query "HKLM\\SOFTWARE\\Microsoft\\Cryptography" /v MachineGuid'); }catch(e1){ out=""; }
            var idw=amHexUuid(out);
            if(idw) return idw;
            try{ out=system.callSystem('cmd.exe /c wmic csproduct get UUID'); }catch(e2){ out=""; }
            return amHexUuid(out);
        } else {
            try{ out=system.callSystem('/bin/sh -c "ioreg -rd1 -c IOPlatformExpertDevice | grep -i IOPlatformUUID"'); }catch(e3){ out=""; }
            var idm=amHexUuid(out);
            if(idm) return idm;
            try{ out=system.callSystem('/bin/sh -c "system_profiler SPHardwareDataType | grep -i UUID"'); }catch(e4){ out=""; }
            return amHexUuid(out);
        }
    }catch(e){ return ""; }
}
function amDevCacheFile(){ return new File(amTrialDir() + "/dev.dat"); }
function amDevCacheRead(){
    try{ var f=amDevCacheFile(); if(!f.exists) return ""; f.open("r"); var s=f.read(); f.close(); return s?String(s).replace(/^\s+|\s+$/g,""):""; }catch(e){ return ""; }
}
function amDevCacheWrite(v){
    try{ var dir=new Folder(amTrialDir()); if(!dir.exists) dir.create(); var f=amDevCacheFile(); f.open("w"); f.write(String(v)); f.close(); }catch(e){}
}
function amDeviceRaw(){
    var c=amDevCacheRead();
    if(c && c.length>=6) return c;
    var hw=amHardwareId();
    var raw;
    if(hw && hw.length>=6){ raw="HW:"+hw; }
    else {
        var user="", home="";
        try{ user=String($.getenv("USER")||$.getenv("USERNAME")||$.getenv("LOGNAME")||""); }catch(e){}
        try{ home=String($.getenv("HOME")||$.getenv("USERPROFILE")||""); }catch(e){}
        raw="SW:"+user+"|"+home;
    }
    amDevCacheWrite(raw);
    return raw;
}
"AmanowSFX host loaded";
