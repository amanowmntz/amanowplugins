/* Minimal CSInterface bridge for AmanowSFX (CEP / Premiere Pro) */
var SystemPath = {
    USER_DATA: "userData",
    COMMON_FILES: "commonFiles",
    MY_DOCUMENTS: "myDocuments",
    APPLICATION: "application",
    EXTENSION: "extension",
    HOST_APPLICATION: "hostApplication"
};

function CSInterface() {}
CSInterface.prototype._cep = function () {
    return (typeof window !== "undefined") ? window.__adobe_cep__ : null;
};
CSInterface.prototype.evalScript = function (script, callback) {
    if (callback === null || callback === undefined) callback = function (r) {};
    var cep = this._cep();
    if (cep) { cep.evalScript(script, callback); }
    else { callback("EvalScript error: CEP not available."); }
};
CSInterface.prototype.getHostEnvironment = function () {
    var cep = this._cep();
    try { return JSON.parse(cep.getHostEnvironment()); } catch (e) { return {}; }
};
CSInterface.prototype.getApplicationID = function () {
    var env = this.getHostEnvironment(); return env ? env.appName : "";
};
CSInterface.prototype.getExtensionID = function () {
    var cep = this._cep();
    try { return cep.getExtensionId(); } catch (e) { return ""; }
};
CSInterface.prototype.getSystemPath = function (pathType) {
    var cep = this._cep();
    try { return decodeURI(cep.getSystemPath(pathType)); } catch (e) { return ""; }
};
CSInterface.prototype.openURLInDefaultBrowser = function (url) {
    try { return window.cep.util.openURLInDefaultBrowser(url); } catch (e) {}
};
CSInterface.prototype.addEventListener = function (type, listener, obj) {
    var cep = this._cep();
    try { cep.addEventListener(type, listener, obj); } catch (e) {}
};
CSInterface.prototype.removeEventListener = function (type, listener, obj) {
    var cep = this._cep();
    try { cep.removeEventListener(type, listener, obj); } catch (e) {}
};
