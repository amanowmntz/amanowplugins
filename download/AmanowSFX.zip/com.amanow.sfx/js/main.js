/* ===================== AmanowSFX  main panel logic ===================== */
(function () {
"use strict";

/* ---------- node modules (require is available with --enable-nodejs) ---------- */
var fs = null, pathMod = null, os = null;
try {
  if (typeof require === "function") {
    fs = require("fs");
    pathMod = require("path");
    os = require("os");
  }
} catch (e) {}

var cs = new CSInterface();

/* ---------- constants ---------- */
var AUDIO_RE = /\.(wav|mp3|aif|aiff|m4a|aac|flac|ogg|oga|opus|wma|caf)$/i;
var BUCKETS = 480;          // waveform resolution stored per channel
var MAX_RESULTS = 400;      // cap search rendering
var FOLDER_MAX = 600;       // cap sounds rendered at once when opening a folder
var MAX_CONCURRENT = 3;     // simultaneous audio decodes

/* ---------- icons ---------- */
var SVG_CHEV   = '<svg viewBox="0 0 24 24"><path d="M9 6l6 6-6 6"/></svg>';
var SVG_FOLDER = '<svg class="folder-ic" viewBox="0 0 24 24"><path d="M3 6h6l2 2h10v10H3z"/></svg>';
var SVG_PLAY   = '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
var SVG_PAUSE  = '<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>';
var SVG_STAR   = '<svg viewBox="0 0 24 24"><path d="M12 3l2.7 5.7 6.3.9-4.5 4.4 1.1 6.3L12 17.8 6.4 20.2l1.1-6.3L3 9.6l6.3-.9z"/></svg>';

/* ---------- DOM ---------- */
function $(id) { return document.getElementById(id); }
var elBody = $("body"), elTree = $("tree"), elResults = $("results"),
    elResultsGrid = $("resultsGrid"), elResultsHead = $("resultsHead"),
    elSplit = $("split"), elPaneLeft = $("paneLeft"), elPaneRight = $("paneRight"),
    elDivider = $("divider"), elFolderView = $("folderView"),
    elRightHead = $("rightHead"), elSoundGrid = $("soundGrid"), elRightEmpty = $("rightEmpty"),
    elRightActions = $("rightActions"),
    elPackTabs = $("packTabs"), elSortOrder = $("sortOrder"), elSortFav = $("sortFav"),
    elEmpty = $("emptyState"), elEmptySub = elEmpty.querySelector(".empty-sub"),
    elLoading = $("loading"), elLoadingTxt = $("loadingTxt"),
    elFooter = $("footer"), elSelCount = $("selCount"), elSelInfo = $("selInfo"),
    elFooterBtns = $("footerBtns"), elMediaCtrls = $("mediaCtrls"),
    elReplayBtn = $("replayBtn"), elPlayPauseBtn = $("playPauseBtn"),
    elFadeBtn = $("fadeBtn"), elFadePop = $("fadePop"),
    elFadeInSlider = $("fadeInSlider"), elFadeOutSlider = $("fadeOutSlider"),
    elFadeInVal = $("fadeInVal"), elFadeOutVal = $("fadeOutVal"),
    elAddBtn = $("addBtn"), elCancelBtn = $("cancelBtn"),
    elSearch = $("search"), elSearchClear = $("searchClear"), elSizeSlider = $("sizeSlider"),
    elZoomSlider = $("zoomSlider"),
    elLibName = $("libName"), elAddLib = $("addLibBtn"), elLibBtn = $("libBtn"),
    elEmptyAdd = $("emptyAdd"), elPlayer = $("player"), elToast = $("toast");
/* tabs + effect view */
var elTabLibrary = $("tabLibrary"), elTabEffect = $("tabEffect"),
    elLibView = $("libView"), elFxView = $("fxView"),
    elFxScroll = $("fxScroll"), elFxClip = $("fxClip"), elFxEmpty = $("fxEmpty"),
    elFxEffects = $("fxEffects"), elFxClipName = $("fxClipName"), elFxLoadBtn = $("fxLoadBtn"),
    elFxCanvas = $("fxCanvas"), elFxProg = $("fxProg"), elFxPreviewBtn = $("fxPreviewBtn"),
    elFxWaveWrap = $("fxWaveWrap"),
    elFxReplayBtn = $("fxReplayBtn"), elFxDur = $("fxDur"),
    elFxApplyBtn = $("fxApplyBtn"), elFxStatus = $("fxStatus"),
    elFxSpeedOn = $("fxSpeedOn"), elFxSpeed = $("fxSpeed"), elFxSpeedVal = $("fxSpeedVal"), elFxKeepPitch = $("fxKeepPitch"),
    elFxCardSpeed = $("fxCardSpeed"),
    elFxRepeat = $("fxRepeat"), elFxRepeatOn = $("fxRepeatOn"), elFxRepeatVal = $("fxRepeatVal"),
    elFxMuting = $("fxMuting"), elFxMutingOn = $("fxMutingOn"), elFxMutingVal = $("fxMutingVal"),
    elFxAddBtn = $("fxAddBtn"), elFxAddMenu = $("fxAddMenu"), elFxChain = $("fxChain"),
    elFxToolbar = $("fxToolbar"), elFxScale = $("fxScale"),
    elFxHelpBtn = $("fxHelpBtn"), elFxHelp = $("fxHelp"), elFxHelpList = $("fxHelpList"), elFxHelpClose = $("fxHelpClose");
var elSearchBox = elSearch.parentNode;

/* ---------- state ---------- */
var state = {
  packs: [],         // [{path, tree}] - multiple sound-pack folders
  activePack: 0,     // which pack tab (L1, L2, ...) is showing
  searchAll: false,  // "All" tab: search across every pack instead of just the active one
  sortMode: "order", // "order" = folder order, "favfirst" = favorites first
  allFiles: [],      // flat index for search {name,path,folder}
  sel: {},           // path -> file (selection)
  selOrder: [],      // paths in selection order
  favorites: {},     // path -> category name ("" = uncategorized)
  favCats: [],       // ordered favorite folder (category) names
  dragFile: null,    // sound currently being dragged (for drop-into-favorites)
  query: "",
  fadeIn: 0,         // seconds
  fadeOut: 0         // seconds
};

/* ---------- small helpers ---------- */
function lsGet(k, d) { try { var v = localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
function lsSet(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
function cssVar(n) { return getComputedStyle(document.documentElement).getPropertyValue(n).trim() || "#dfe3ea"; }
function baseName(p) { return pathMod ? pathMod.basename(p) : p; }
function natCmp(a, b) { return String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: "base" }); }
function fmtDur(s) {
  if (s === undefined || s === null) return "";
  s = Math.round(s); var m = Math.floor(s / 60), ss = s % 60;
  return m + ":" + (ss < 10 ? "0" : "") + ss;
}

/* ---------- favorites ---------- */
function favLoad() {
  var raw = {}; try { raw = JSON.parse(lsGet("amsfx_favs", "{}")) || {}; } catch (e) { raw = {}; }
  var out = {};
  for (var k in raw) { if (raw.hasOwnProperty(k)) out[k] = (typeof raw[k] === "string") ? raw[k] : ""; } /* old format: true -> "" */
  return out;
}
function favSave() { lsSet("amsfx_favs", JSON.stringify(state.favorites)); }
function favCatsLoad() { try { var a = JSON.parse(lsGet("amsfx_favcats", "[]")); return (Object.prototype.toString.call(a) === "[object Array]") ? a : []; } catch (e) { return []; } }
function favCatsSave() { lsSet("amsfx_favcats", JSON.stringify(state.favCats)); }
function favCatCount(cat) { var n = 0; for (var p in state.favorites) if (state.favorites.hasOwnProperty(p) && state.favorites[p] === cat) n++; return n; }

/* ===================== peak cache (memory + disk) ===================== */
var peakMem = {};   // path -> {L:[],R:[],dur}
var cacheFile = null, cacheDirty = false, cacheTimer = null;

function initCache() {
  if (!fs || !os || !pathMod) return;
  try {
    var dir = pathMod.join(os.homedir(), ".amanow_sfx");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir);
    cacheFile = pathMod.join(dir, "peaks.json");
    if (fs.existsSync(cacheFile)) {
      var obj = JSON.parse(fs.readFileSync(cacheFile, "utf8"));
      if (obj && typeof obj === "object") peakMem = obj;
    }
  } catch (e) { peakMem = {}; }
}
function cacheSaveSoon() {
  if (!cacheFile) return;
  cacheDirty = true;
  if (cacheTimer) return;
  cacheTimer = setTimeout(function () {
    cacheTimer = null;
    if (!cacheDirty) return;
    cacheDirty = false;
    try {
      var keys = Object.keys(peakMem);
      if (keys.length > 4000) { for (var i = 0; i < keys.length - 4000; i++) delete peakMem[keys[i]]; }
      fs.writeFile(cacheFile, JSON.stringify(peakMem), function () {});
    } catch (e) {}
  }, 1500);
}

/* ===================== audio decode + peaks ===================== */
var actx = null;
function audioCtx() {
  if (!actx) { try { actx = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { actx = null; } }
  return actx;
}
function chPeaks(data, buckets) {
  var len = data.length, out = new Array(buckets), step = len / buckets;
  for (var b = 0; b < buckets; b++) {
    var s = Math.floor(b * step), e = Math.floor((b + 1) * step);
    if (e <= s) e = s + 1; if (e > len) e = len;
    var peak = 0;
    for (var i = s; i < e; i++) { var v = data[i]; if (v < 0) v = -v; if (v > peak) peak = v; }
    var q = Math.round(peak * 255); if (q > 255) q = 255; if (q < 0) q = 0;
    out[b] = q;
  }
  return out;
}
function computePeaks(buf) {
  var L = buf.getChannelData(0);
  var R = buf.numberOfChannels > 1 ? buf.getChannelData(1) : L;
  return { L: chPeaks(L, BUCKETS), R: chPeaks(R, BUCKETS), dur: buf.duration };
}

/* throttled decode queue */
var q = [], qActive = 0;
function qPush(task) { q.push(task); qPump(); }
function qPump() { while (qActive < MAX_CONCURRENT && q.length) { var t = q.shift(); qActive++; t(qDone); } }
function qDone() { qActive--; qPump(); }

function ensurePeaks(f) {
  return new Promise(function (resolve, reject) {
    if (peakMem[f.path]) { resolve(peakMem[f.path]); return; }
    qPush(function (done) {
      if (peakMem[f.path]) { done(); resolve(peakMem[f.path]); return; }
      if (!fs) { done(); reject("nofs"); return; }
      fs.readFile(f.path, function (err, buf) {
        if (err) { done(); reject(err); return; }
        var ctx = audioCtx();
        if (!ctx) { done(); reject("noctx"); return; }
        var ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
        try {
          ctx.decodeAudioData(ab, function (audioBuf) {
            try { peakMem[f.path] = computePeaks(audioBuf); cacheSaveSoon(); } catch (e) {}
            done(); resolve(peakMem[f.path] || null);
          }, function (e) { done(); reject(e || "decode"); });
        } catch (e2) { done(); reject(e2); }
      });
    });
  });
}

/* ---------- waveform drawing ---------- */
var curZoom = 1;   /* kept in sync by applyZoom so canvases render sharp when zoomed */
function effDpr() {
  var dpr = Math.min(2, window.devicePixelRatio || 1);
  return Math.min(3, dpr * (curZoom > 1 ? curZoom : 1));
}
function drawWave(canvas, pk, color) {
  var cw = canvas.clientWidth, ch = canvas.clientHeight;
  if (!cw || !ch) return;
  var dpr = effDpr();
  canvas.width = Math.round(cw * dpr);
  canvas.height = Math.round(ch * dpr);
  var g = canvas.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, cw, ch);
  g.fillStyle = color || "#dfe3ea";
  var gap = Math.max(2, Math.round(ch * 0.10));
  var rowH = (ch - gap) / 2;
  var rows = [pk.L, pk.R];
  /* never draw more bars than the canvas has pixels for: sharper and cheaper */
  var src = (pk.L && pk.L.length) || 1;
  var target = Math.max(40, Math.min(src, Math.round(cw / 1.6)));
  var bw = cw / target, barW = Math.max(0.6, bw * 0.66), stride = src / target;
  for (var r = 0; r < 2; r++) {
    var arr = rows[r]; if (!arr) continue;
    var midY = r * (rowH + gap) + rowH / 2;
    for (var i = 0; i < target; i++) {
      var s0 = (i * stride) | 0, s1 = ((i + 1) * stride) | 0;
      if (s1 <= s0) s1 = s0 + 1; if (s1 > src) s1 = src;
      var peak = 0;
      for (var j = s0; j < s1; j++) { if (arr[j] > peak) peak = arr[j]; }
      var a = peak / 255, h = a * (rowH * 0.94); if (h < 0.7) h = 0.7;
      g.fillRect(i * bw + (bw - barW) / 2, midY - h / 2, barW, h);
    }
  }
}
function drawFlat(canvas, color) {
  var cw = canvas.clientWidth, ch = canvas.clientHeight;
  if (!cw || !ch) return;
  var dpr = effDpr();
  canvas.width = Math.round(cw * dpr);
  canvas.height = Math.round(ch * dpr);
  var g = canvas.getContext("2d");
  g.setTransform(dpr, 0, 0, dpr, 0, 0);
  g.clearRect(0, 0, cw, ch);
  g.fillStyle = color || "#555a63";
  var gap = Math.max(2, Math.round(ch * 0.10)), rowH = (ch - gap) / 2;
  g.fillRect(0, rowH / 2, cw, 1);
  g.fillRect(0, rowH + gap + rowH / 2, cw, 1);
}
function redrawCard(card) {
  if (card._pk) drawWave(card._canvas, card._pk, card.classList.contains("sel") ? cssVar("--wave-sel") : cssVar("--wave"));
  else if (card._failed) drawFlat(card._canvas, "#555a63");
}

/* ---------- lazy draw via IntersectionObserver ---------- */
/* visibleCards holds only the cards currently on (or near) screen, so every
   resize/zoom/size redraw touches a few dozen cards instead of hundreds. */
var visibleCards = (typeof Set === "function") ? new Set() : null;
var observer = new IntersectionObserver(function (entries) {
  for (var i = 0; i < entries.length; i++) {
    var c = entries[i].target;
    if (entries[i].isIntersecting) {
      if (visibleCards) visibleCards.add(c);
      loadCard(c);
    } else if (visibleCards) {
      visibleCards.delete(c);
    }
  }
}, { root: elPaneRight, rootMargin: "300px 0px" });

/* draw as soon as the card actually has a measurable size (handles the brief
   moment a virtualized card is still being rendered by the browser) */
function drawCardSafe(card, tries) {
  if (!card._canvas) return;
  if (card._canvas.clientWidth > 0) { redrawCard(card); card._drawn = true; return; }
  if (tries <= 0) return;
  requestAnimationFrame(function () { drawCardSafe(card, tries - 1); });
}

function loadCard(card) {
  if (card._pending || card._pk || card._failed) { if (card._pk && !card._drawn) drawCardSafe(card, 16); return; }
  var f = card._file;
  card._pending = true;
  ensurePeaks(f).then(function (pk) {
    card._pending = false;
    card._pk = pk;
    card.classList.add("ready");
    if (card._dur) card._dur.textContent = fmtDur(pk ? pk.dur : null);
    drawCardSafe(card, 16);
  }, function () {
    card._pending = false;
    card._failed = true;
    card.classList.add("ready");
    if (card._dur) card._dur.textContent = "";
    drawCardSafe(card, 16);
  });
}

/* ===================== sound cards ===================== */
function isSel(f) { return !!state.sel[f.path]; }

/* dragging a card out onto the Premiere timeline (CEP file drag-and-drop).
   Setting "com.adobe.cep.dnd.file.N" makes the host import/place the file at the drop point. */
function cardDragStart(ev, f) {
  try {
    var dt = ev.dataTransfer; if (!dt) return;
    var paths = (state.sel[f.path] && state.selOrder.length > 1) ? state.selOrder.slice() : [f.path];
    for (var i = 0; i < paths.length; i++) dt.setData("com.adobe.cep.dnd.file." + i, paths[i]);
    try { dt.setData("text/plain", paths.join("\n")); } catch (e) {}
    dt.effectAllowed = "copy";
  } catch (e2) {}
}

function makeCard(f) {
  var card = document.createElement("div");
  card.className = "card" + (isSel(f) ? " sel" : "");
  card.setAttribute("data-path", f.path);
  card._file = f;

  card.innerHTML =
    '<div class="wave-wrap">' +
      '<div class="wave-skel"></div>' +
      '<canvas class="wave"></canvas>' +
      '<div class="wave-prog"></div>' +
    '</div>' +
    '<div class="card-foot">' +
      '<div class="play-ic">' + SVG_PLAY + '</div>' +
      '<div class="card-name"></div>' +
      '<div class="card-dur"></div>' +
      '<div class="star' + ((f.path in state.favorites) ? " on" : "") + '">' + SVG_STAR + '</div>' +
    '</div>';

  var nameEl = card.querySelector(".card-name");
  nameEl.textContent = f.name; nameEl.title = f.name;
  card._canvas = card.querySelector(".wave");
  card._dur = card.querySelector(".card-dur");
  card._prog = card.querySelector(".wave-prog");
  card._wave = card.querySelector(".wave-wrap");
  var playEl = card.querySelector(".play-ic");
  var starEl = card.querySelector(".star");

  card.addEventListener("click", function (ev) {
    if (starEl.contains(ev.target)) return;
    if (playEl.contains(ev.target)) { previewToggle(card, f); return; }
    /* on the sound you're already previewing, the waveform is a scrubber,
       so a click there must NOT change the selection */
    if (card._wave.contains(ev.target) && preview.card === card && preview.loaded) return;
    if (ev.ctrlKey || ev.metaKey) toggleAdd(card, f);  /* Ctrl-click = add to selection */
    else selectSingle(card, f);                        /* plain click = select just this */
  });
  /* double-click adds this sound to the timeline (replaces the old Add button) */
  card.addEventListener("dblclick", function (ev) {
    if (starEl.contains(ev.target)) return;
    if (playEl.contains(ev.target)) return;
    state.sel = {}; state.selOrder = [];
    state.sel[f.path] = f; state.selOrder.push(f.path);
    doAdd();
  });
  /* drag the playhead on the previewed sound to hear any moment */
  card._wave.addEventListener("pointerdown", function (ev) {
    if (preview.card !== card || !preview.loaded) return;  /* only scrub the cued sound */
    if (playEl.contains(ev.target)) return;
    ev.preventDefault();
    card.draggable = false;  /* don't let a native drag hijack the scrub */
    var restore = function () {
      card.draggable = true;
      window.removeEventListener("pointerup", restore);
      window.removeEventListener("pointercancel", restore);
    };
    window.addEventListener("pointerup", restore);
    window.addEventListener("pointercancel", restore);
    scrubStart(card, ev);
  });
  starEl.addEventListener("click", function (ev) { ev.stopPropagation(); toggleFav(f); });

  /* drag this card onto the Premiere timeline (in addition to the Add button) */
  card.setAttribute("draggable", "true");
  card.addEventListener("dragstart", function (ev) { state.dragFile = f; cardDragStart(ev, f); card.classList.add("dragging"); });
  card.addEventListener("dragend", function () { state.dragFile = null; card.classList.remove("dragging"); card.draggable = true; });

  /* when the browser actually renders this (un-virtualizes it), make sure it's drawn */
  card.addEventListener("contentvisibilityautostatechange", function (e) {
    if (e && e.skipped) return;
    if (card._pk || card._failed) drawCardSafe(card, 4);
    else loadCard(card);
  });

  observer.observe(card);
  return card;
}

/* plain click: make THIS the only selected sound and play it */
function selectSingle(card, f) {
  if (visibleCards) {
    visibleCards.forEach(function (c) {
      if (c !== card && c.classList.contains("sel")) { c.classList.remove("sel"); redrawCard(c); }
    });
  }
  var prev = elBody.querySelectorAll(".card.sel");
  for (var i = 0; i < prev.length; i++) {
    if (prev[i] !== card) { prev[i].classList.remove("sel"); redrawCard(prev[i]); }
  }
  state.sel = {}; state.selOrder = [];
  state.sel[f.path] = f; state.selOrder.push(f.path);
  card.classList.add("sel"); redrawCard(card);
  startPreview(card, f);
  updateFooter();
}

/* Ctrl-click: add/remove THIS sound without touching the others */
function toggleAdd(card, f) {
  if (state.sel[f.path]) {
    delete state.sel[f.path];
    var i = state.selOrder.indexOf(f.path); if (i >= 0) state.selOrder.splice(i, 1);
    card.classList.remove("sel");
    if (preview.card === card) teardownPreview();
  } else {
    state.sel[f.path] = f; state.selOrder.push(f.path);
    card.classList.add("sel");
    startPreview(card, f);
  }
  redrawCard(card);
  updateFooter();
}

function clearSelection() {
  teardownPreview();
  state.sel = {}; state.selOrder = [];
  var sels = elBody.querySelectorAll(".card.sel");
  for (var i = 0; i < sels.length; i++) { sels[i].classList.remove("sel"); redrawCard(sels[i]); }
  updateFooter();
}

function updateFooter() {
  var n = state.selOrder.length;
  elSelCount.textContent = String(n);
  elSelInfo.style.display = n > 0 ? "" : "none";
  elFooterBtns.style.display = n > 0 ? "" : "none";
  elMediaCtrls.style.display = preview.loaded ? "" : "none";
}

function toggleFav(f) {
  if (f.path in state.favorites) delete state.favorites[f.path];
  else state.favorites[f.path] = "";
  favSave();
  var on = (f.path in state.favorites);
  var stars = elBody.querySelectorAll('.card[data-path]');
  for (var i = 0; i < stars.length; i++) {
    if (stars[i].getAttribute("data-path") === f.path) {
      var st = stars[i].querySelector(".star");
      if (st) st.classList.toggle("on", on);
    }
  }
  refreshFavNode();
  refreshFolderStars();
}

/* ---- favorite an ENTIRE folder at once (grouped under a category) ---- */
function isFolderFaved(node) {
  var f = collectFiles(node, []); if (!f.length) return false;
  for (var i = 0; i < f.length; i++) if (!(f[i].path in state.favorites)) return false;
  return true;
}
function favoriteFolder(node) {
  var files = collectFiles(node, []);
  if (!files.length) { toast("This folder has no sounds"); return; }
  var cat = String(node.name).replace(/^\u2605\s*/, "").slice(0, 40);
  if (isFolderFaved(node)) {
    for (var i = 0; i < files.length; i++) delete state.favorites[files[i].path];
    toast("Removed from Favorites");
  } else {
    if (state.favCats.indexOf(cat) < 0) { state.favCats.push(cat); favCatsSave(); }
    for (var j = 0; j < files.length; j++) state.favorites[files[j].path] = cat;
    toast("Added " + files.length + " sound" + (files.length === 1 ? "" : "s") + " to Favorites \u2192 " + cat);
  }
  favSave();
  refreshFavNode();
  refreshFolderStars();
  redrawFavStarsOnCards();
}
/* keep the little folder-stars in the tree in sync */
function refreshFolderStars() {
  var nodes = elTree.querySelectorAll(".node");
  for (var i = 0; i < nodes.length; i++) {
    if (!nodes[i]._node) continue;
    var st = nodes[i].querySelector(".folder-star");
    if (st && nodes[i]._children && !nodes[i]._children.contains(st)) st.classList.toggle("on", isFolderFaved(nodes[i]._node));
  }
}
/* reflect favorite changes on any sound cards currently on screen */
function redrawFavStarsOnCards() {
  var cards = elBody.querySelectorAll('.card[data-path]');
  for (var i = 0; i < cards.length; i++) {
    var st = cards[i].querySelector(".star");
    if (st) st.classList.toggle("on", cards[i].getAttribute("data-path") in state.favorites);
  }
}

/* ---- favorite categories (folders inside Favorites) ---- */
function addFavCat(name) {
  var v = String(name || "").trim().slice(0, 40);
  if (!v) return;
  if (state.favCats.indexOf(v) < 0) { state.favCats.push(v); favCatsSave(); refreshFavNode(); }
}
function removeFavCat(cat) {
  for (var p in state.favorites) { if (state.favorites.hasOwnProperty(p) && state.favorites[p] === cat) state.favorites[p] = ""; }
  var i = state.favCats.indexOf(cat); if (i >= 0) state.favCats.splice(i, 1);
  favSave(); favCatsSave();
  refreshFavNode();
  refreshFolderStars();
  toast("Folder \"" + cat + "\" removed");
}
/* drop a dragged sound onto a Favorites row to file it there */
function fileFavInto(f, cat) {
  if (!f) return;
  state.favorites[f.path] = cat || "";
  favSave();
  refreshFavNode();
  refreshFolderStars();
  redrawFavStarsOnCards();
  toast(cat ? ("Filed under \"" + cat + "\"") : "Added to Favorites");
}

/* ===================== preview playback ===================== */
/* One shared <audio> element previews the clicked sound. The footer's
   Play/Pause and Replay buttons control whatever is currently loaded. */
var preview = { card: null, file: null, url: null, raf: null, loaded: false, playing: false };

function cardPlayIcon(card, playing) { var p = card && card.querySelector(".play-ic"); if (p) p.innerHTML = playing ? SVG_PAUSE : SVG_PLAY; }

function setFooterPlayIcon(playing) {
  if (!elPlayPauseBtn) return;
  elPlayPauseBtn.innerHTML = playing ? SVG_PAUSE : SVG_PLAY;
  elPlayPauseBtn.classList.add("play-state");
  elPlayPauseBtn.classList.toggle("live", playing);
}

/* ---- Web Audio gain for live fade in / fade out on the preview ---- */
var faderNode = null, faderReady = false, faderTried = false;
function ensureFader() {
  if (faderTried) return faderReady;
  faderTried = true;
  try {
    var ctx = audioCtx();
    if (!ctx || !ctx.createMediaElementSource) return false;
    var src = ctx.createMediaElementSource(elPlayer);
    faderNode = ctx.createGain();
    faderNode.gain.value = 1;
    src.connect(faderNode);
    faderNode.connect(ctx.destination);
    faderReady = true;
  } catch (e) { faderReady = false; }
  return faderReady;
}
function resumeCtx() { try { var c = audioCtx(); if (c && c.state === "suspended" && c.resume) c.resume(); } catch (e) {} }
function fadeGainAt(t, dur) {
  var fi = state.fadeIn, fo = state.fadeOut, g = 1;
  if (fi > 0 && t < fi) g = Math.min(g, t / fi);
  if (fo > 0 && dur > 0 && t > dur - fo) g = Math.min(g, Math.max(0, (dur - t) / fo));
  if (g < 0) g = 0; if (g > 1) g = 1;
  return g;
}
function applyLiveFade(t, dur) {
  if (!faderReady || !faderNode) return;
  try { faderNode.gain.value = fadeGainAt(t, dur); } catch (e) {}
}

/* position the playhead line at a 0..1 fraction (in the card's own coordinates) */
function setProg(card, frac) {
  var prog = card && card._prog; if (!prog) return;
  if (frac < 0) frac = 0; if (frac > 1) frac = 1;
  var w = (card._canvas && card._canvas.clientWidth) || 1;
  prog.style.left = (9 + frac * w) + "px";
}

function progTick() {
  if (!preview.card) return;
  var card = preview.card;
  var d = elPlayer.duration || (card._pk && card._pk.dur) || 0;
  var t = elPlayer.currentTime || 0;
  if (d > 0) { setProg(card, t / d); applyLiveFade(t, d); }
  preview.raf = requestAnimationFrame(progTick);
}
function startTick() { if (preview.raf) cancelAnimationFrame(preview.raf); preview.raf = requestAnimationFrame(progTick); }
function stopTick() { if (preview.raf) { cancelAnimationFrame(preview.raf); preview.raf = null; } }

/* ---- scrub: drag the playhead on the previewed sound ---- */
function clientXToFrac(card, clientX) {
  var canvas = card._canvas; if (!canvas) return 0;
  var rect = canvas.getBoundingClientRect();
  var w = rect.width || 1;
  var frac = (clientX - rect.left) / w;
  if (frac < 0) frac = 0; if (frac > 1) frac = 1;
  return frac;
}
function scrubTo(card, clientX) {
  var frac = clientXToFrac(card, clientX);
  var d = elPlayer.duration || (card._pk && card._pk.dur) || 0;
  if (d > 0) { try { elPlayer.currentTime = frac * d; } catch (e) {} }
  setProg(card, frac);
  applyLiveFade(frac * d, d);
}
function scrubStart(card, ev) {
  var ww = card._wave; if (!ww) return;
  scrubTo(card, ev.clientX);
  function move(e) { scrubTo(card, e.clientX); }
  function up() {
    try { ww.releasePointerCapture(ev.pointerId); } catch (e) {}
    ww.removeEventListener("pointermove", move);
    ww.removeEventListener("pointerup", up);
    ww.removeEventListener("pointercancel", up);
  }
  try { ww.setPointerCapture(ev.pointerId); } catch (e) {}
  ww.addEventListener("pointermove", move);
  ww.addEventListener("pointerup", up);
  ww.addEventListener("pointercancel", up);
}

function markPlaying(on) {
  preview.playing = on;
  if (preview.card) { preview.card.classList.toggle("playing", on); cardPlayIcon(preview.card, on); }
  setFooterPlayIcon(on);
}

/* fully unload the current preview (used on navigation / deselect / cancel) */
function teardownPreview() {
  stopTick();
  try { elPlayer.pause(); } catch (e) {}
  try { elPlayer.onended = null; } catch (e) {}
  try { elPlayer.removeAttribute("src"); elPlayer.load(); } catch (e) {}
  if (preview.url) { try { URL.revokeObjectURL(preview.url); } catch (e) {} }
  if (preview.card) { preview.card.classList.remove("playing"); preview.card.classList.remove("cued"); cardPlayIcon(preview.card, false); }
  preview = { card: null, file: null, url: null, raf: null, loaded: false, playing: false };
  if (elMediaCtrls) elMediaCtrls.style.display = "none";
  setFooterPlayIcon(false);
}
function stopPlay() { teardownPreview(); }   /* alias kept for search / tree rebuild */

/* load a file and play it from the beginning */
function startPreview(card, f) {
  teardownPreview();
  if (!fs) return;
  fs.readFile(f.path, function (err, buf) {
    if (err) { toast("Can't read file", true); return; }
    var ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
    var url = URL.createObjectURL(new Blob([ab]));
    preview.card = card; preview.file = f; preview.url = url; preview.loaded = true;
    card.classList.add("cued");
    elPlayer.src = url;
    if (elMediaCtrls) elMediaCtrls.style.display = "";
    ensureFader(); resumeCtx();
    if (faderReady && faderNode) { try { faderNode.gain.value = state.fadeIn > 0 ? 0 : 1; } catch (e) {} }
    setProg(card, 0);
    elPlayer.onended = function () { stopTick(); markPlaying(false); };
    var pr = elPlayer.play();
    markPlaying(true);
    if (pr && pr.then) pr.then(function () { startTick(); }, function () { startTick(); });
    else startTick();
    updateFooter();
  });
}

/* play-icon on a card: toggle that card's own preview */
function previewToggle(card, f) {
  if (preview.card === card && preview.loaded) {
    if (preview.playing) pausePreview(); else resumePreview();
    return;
  }
  startPreview(card, f);
}

function pausePreview() {
  if (!preview.loaded) return;
  try { elPlayer.pause(); } catch (e) {}
  stopTick();
  markPlaying(false);
}
function resumePreview() {
  if (!preview.loaded) return;
  resumeCtx();
  if (elPlayer.ended || (elPlayer.duration && elPlayer.currentTime >= elPlayer.duration - 0.02)) {
    try { elPlayer.currentTime = 0; } catch (e) {}
  }
  var pr = elPlayer.play();
  markPlaying(true);
  if (pr && pr.then) pr.then(function () { startTick(); }, function () { startTick(); });
  else startTick();
}
function replayPreview() {
  if (!preview.loaded) return;
  try { elPlayer.currentTime = 0; } catch (e) {}
  resumePreview();
}

/* footer Play / Pause button */
function footerPlayPause() {
  if (!preview.loaded) return;
  if (preview.playing) pausePreview(); else resumePreview();
}

/* ===================== filesystem scan ===================== */
function readEntries(dir) {
  /* returns [{name, isDir}] tolerant of old node (no withFileTypes) */
  try {
    var d = fs.readdirSync(dir, { withFileTypes: true });
    if (d && d.length === 0) return [];
    if (d && d.length && d[0] && typeof d[0].isDirectory === "function") {
      var out = [];
      for (var i = 0; i < d.length; i++) out.push({ name: d[i].name, isDir: d[i].isDirectory() });
      return out;
    }
  } catch (e) {}
  var names = [];
  try { names = fs.readdirSync(dir); } catch (e2) { return []; }
  var out2 = [];
  for (var j = 0; j < names.length; j++) {
    var isDir = false;
    try { isDir = fs.statSync(pathMod.join(dir, names[j])).isDirectory(); } catch (e3) {}
    out2.push({ name: names[j], isDir: isDir });
  }
  return out2;
}

function scanDir(dir) {
  var node = { name: baseName(dir) || dir, path: dir, dirs: [], files: [], audioCount: 0 };
  var entries = readEntries(dir);
  for (var i = 0; i < entries.length; i++) {
    var en = entries[i];
    if (en.isDir) {
      node.dirs.push(scanDir(pathMod.join(dir, en.name)));
    } else if (AUDIO_RE.test(en.name)) {
      var f = { name: en.name, path: pathMod.join(dir, en.name), folder: dir };
      node.files.push(f);
      state.allFiles.push(f);
    }
  }
  node.dirs.sort(function (a, b) { return natCmp(a.name, b.name); });
  node.files.sort(function (a, b) { return natCmp(a.name, b.name); });
  node.audioCount = node.files.length;
  var total = node.files.length;
  for (var d = 0; d < node.dirs.length; d++) total += node.dirs[d].totalCount;
  node.totalCount = total;       // direct files + everything in sub-folders
  return node;
}

/* gather every audio file inside a folder AND all of its sub-folders */
function collectFiles(node, out) {
  out = out || [];
  if (node.files) for (var i = 0; i < node.files.length; i++) out.push(node.files[i]);
  if (node.dirs) for (var j = 0; j < node.dirs.length; j++) collectFiles(node.dirs[j], out);
  return out;
}

/* ===================== tree rendering (accordion) ===================== */
var mountToken = 0;   /* bumping this cancels any background card mounting */
function clearContainer(el) {
  mountToken++;
  var cards = el.querySelectorAll(".card");
  for (var i = 0; i < cards.length; i++) {
    try { observer.unobserve(cards[i]); } catch (e) {}
    if (visibleCards) visibleCards.delete(cards[i]);
  }
  el.innerHTML = "";
  el.style.height = "";
  el.classList.remove("vgrid");
  if (activeVG && activeVG.outer === el) activeVG = null;
}

/* ===================== virtualized sound grid (windowing) =====================
   Only the cards visible in the viewport (plus a buffer above and below) exist
   in the DOM. A folder with 4000+ sounds then scrolls exactly as smoothly as a
   folder with 40, because the browser is only ever laying out ~100 cards. */
var VG_BUFFER = 800;          /* px of extra cards kept above & below the viewport */
var activeVG = null;

function zoomScale() { return (elBody && elBody.classList.contains("zoomed")) ? curZoom : 1; }

function vgUnmountCard(c) {
  try { observer.unobserve(c); } catch (e) {}
  if (visibleCards) visibleCards.delete(c);
  if (preview.card === c) teardownPreview();
}

/* replaces the old streaming mountCards: builds a virtual grid for `list` */
function mountCards(grid, files, extraEl) { return vgInit(grid, files); }

function vgInit(outer, list) {
  var old = outer.querySelectorAll(".card");
  for (var i = 0; i < old.length; i++) vgUnmountCard(old[i]);
  outer.innerHTML = "";
  var win = document.createElement("div");
  win.className = "vwin";
  outer.appendChild(win);
  outer.classList.add("vgrid");
  var vg = { outer: outer, win: win, list: list, cols: 0, rowH: 0, cardH: 0, padTop: 6, first: 0, last: 0, ready: false };
  activeVG = vg;
  /* first paint: render a small measurement batch, measure the grid, then window it */
  var probeN = Math.min(list.length, 120);
  var frag = document.createDocumentFragment();
  for (var j = 0; j < probeN; j++) frag.appendChild(makeCard(list[j]));
  win.appendChild(frag);
  vg.first = 0; vg.last = probeN;
  vgMeasure(vg);
  vgRender(true);
  return vg;
}

/* read the real column count + row height from the cards the browser laid out */
function vgMeasure(vg) {
  var kids = vg.win.querySelectorAll(".card");
  if (!kids.length) { vg.ready = false; return; }
  var top0 = kids[0].offsetTop;
  var cardH = kids[0].offsetHeight || 90;
  var cols = 1;
  for (var i = 1; i < kids.length; i++) { if (kids[i].offsetTop === top0) cols++; else break; }
  if (cols < 1) cols = 1;
  var rowH = (kids.length > cols) ? (kids[cols].offsetTop - top0) : (cardH + 9);
  if (!(rowH > 0)) rowH = cardH + 9;
  vg.padTop = top0 || 0; vg.cardH = cardH; vg.cols = cols; vg.rowH = rowH;
  var rows = Math.ceil(vg.list.length / cols);
  var totalH = vg.padTop + (rows > 0 ? (rows - 1) * rowH + cardH : 0) + 10;
  vg.outer.style.height = totalH + "px";
  vg.ready = true;
}

/* which rows are inside the viewport (+ buffer), accounting for zoom scale */
function vgVisibleRows(vg) {
  var scale = zoomScale();
  var scRect = elPaneRight.getBoundingClientRect();
  var gTop = vg.outer.getBoundingClientRect().top;
  var m = VG_BUFFER;
  var fRow = Math.floor(((scRect.top - m - gTop) / scale - vg.padTop) / vg.rowH);
  var lRow = Math.floor(((scRect.bottom + m - gTop) / scale - vg.padTop) / vg.rowH);
  var maxRow = Math.ceil(vg.list.length / vg.cols) - 1;
  if (fRow < 0) fRow = 0;
  if (lRow > maxRow) lRow = maxRow;
  if (lRow < fRow) lRow = fRow;
  return { f: fRow, l: lRow };
}

/* render exactly the visible window; recycle cards (keep DOM order == item order) */
function vgRender(force) {
  var vg = activeVG;
  if (!vg || !vg.ready || !vg.cols) return;
  var rows = vgVisibleRows(vg);
  var nf = rows.f * vg.cols;
  var nl = Math.min(vg.list.length, (rows.l + 1) * vg.cols);
  if (!force && nf === vg.first && nl === vg.last) return;
  var win = vg.win, list = vg.list;
  if (force || nl <= vg.first || nf >= vg.last) {
    var old = win.querySelectorAll(".card");
    for (var i = 0; i < old.length; i++) vgUnmountCard(old[i]);
    win.innerHTML = "";
    var frag = document.createDocumentFragment();
    for (var a = nf; a < nl; a++) frag.appendChild(makeCard(list[a]));
    win.appendChild(frag);
  } else {
    while (vg.first < nf) { var c1 = win.firstChild; if (!c1) break; vgUnmountCard(c1); win.removeChild(c1); vg.first++; }
    while (vg.last > nl) { var c2 = win.lastChild; if (!c2) break; vgUnmountCard(c2); win.removeChild(c2); vg.last--; }
    while (vg.last < nl) { win.appendChild(makeCard(list[vg.last])); vg.last++; }
    while (vg.first > nf) { vg.first--; win.insertBefore(makeCard(list[vg.first]), win.firstChild); }
  }
  vg.first = nf; vg.last = nl;
  win.style.transform = "translateY(" + (rows.f * vg.rowH) + "px)";
}

/* re-measure and re-window (after resize / zoom / card-size change) */
function vgRelayout() {
  var vg = activeVG;
  if (!vg || !vg.list) return;
  if (!vg.win.querySelector(".card")) return;
  vgMeasure(vg);
  vgRender(true);
}
var vgRlTimer = null;
function vgRelayoutSoon() { if (vgRlTimer) clearTimeout(vgRlTimer); vgRlTimer = setTimeout(function () { vgRlTimer = null; vgRelayout(); }, 60); }
var vgScroll = rafThrottle(function () { vgRender(false); });

function makeFolderNode(node) {
  var el = document.createElement("div");
  el.className = "node"; el._node = node; el._loaded = false;
  var total = (typeof node.totalCount === "number") ? node.totalCount : node.audioCount;
  var hasChildren = node.dirs && node.dirs.length > 0;
  var hasAudio = total > 0;
  var isFav = node._favRoot || node._favCat;   /* Favorites root or a favorites folder */
  var chevCls = hasChildren ? "chev" : "chev empty";
  var cntHtml = hasAudio ? ('<div class="node-count">' + total + '</div>') : '';
  var starHtml = (!isFav && hasAudio) ? ('<div class="folder-star" title="Add this whole folder to Favorites">' + SVG_STAR + '</div>') : '';
  el.innerHTML =
    '<div class="node-row">' +
      '<div class="' + chevCls + '">' + SVG_CHEV + '</div>' +
      SVG_FOLDER +
      '<div class="node-name"></div>' +
      cntHtml + starHtml +
    '</div>' +
    '<div class="node-children"></div>';
  var row = el.firstChild;
  var nameEl = row.querySelector(".node-name");
  nameEl.textContent = node.name; nameEl.title = node.path;
  el._children = el.querySelector(".node-children");
  var chev = row.querySelector(".chev");

  /* the little triangle only opens / closes the sub-folder list */
  chev.addEventListener("click", function (ev) { ev.stopPropagation(); toggleNode(el); });
  /* clicking the folder itself shows ITS sounds on the right, and reveals sub-folders */
  row.addEventListener("click", function () {
    selectFolder(el, node);
    if (hasChildren && !el.classList.contains("open")) toggleNode(el);
  });

  /* star on the folder = favorite ALL its sounds together */
  var fstar = row.querySelector(".folder-star");
  if (fstar) {
    fstar.classList.toggle("on", isFolderFaved(node));
    fstar.addEventListener("click", function (ev) { ev.stopPropagation(); favoriteFolder(node); });
  }

  /* right-click a Favorites folder to delete it */
  if (node._favCat) {
    row.addEventListener("contextmenu", function (ev) { if (ev.preventDefault) ev.preventDefault(); removeFavCat(node._favCat); });
  }
  /* drop a dragged sound onto Favorites (or one of its folders) to file it */
  if (isFav) {
    row.addEventListener("dragover", function (ev) { if (state.dragFile) { if (ev.preventDefault) ev.preventDefault(); row.classList.add("drop-hot"); } });
    row.addEventListener("dragleave", function () { row.classList.remove("drop-hot"); });
    row.addEventListener("drop", function (ev) {
      row.classList.remove("drop-hot");
      if (ev.preventDefault) ev.preventDefault();
      fileFavInto(state.dragFile, node._favCat || "");
    });
  }
  return el;
}

function toggleNode(el) {
  if (el.classList.contains("open")) el.classList.remove("open");
  else {
    if (!el._loaded) { buildNodeChildren(el); el._loaded = true; }
    el.classList.add("open");
  }
}

function buildNodeChildren(el) {
  var node = el._node, cont = el._children;
  /* the LEFT tree now shows folders only; sounds live on the right */
  if (node.dirs) {
    for (var i = 0; i < node.dirs.length; i++) cont.appendChild(makeFolderNode(node.dirs[i]));
  }
}

/* highlight a folder in the tree and show its sounds in the right pane */
function selectFolder(el, node) {
  var row = el.firstChild;
  if (state.curFolderRow && state.curFolderRow !== row) state.curFolderRow.classList.remove("sel");
  row.classList.add("sel");
  state.curFolderRow = row;
  state.curFolderEl = el;
  state.curFolder = node;
  showFolderSounds(node);
}

/* render the sounds of one folder (and all its sub-folders) into the right pane */
function showFolderSounds(node) {
  stopPlay();
  /* drop the old cards cleanly (stop watching them) */
  if (preview.card && elSoundGrid.contains(preview.card)) teardownPreview();
  var old = elSoundGrid.querySelectorAll(".card");
  for (var i = 0; i < old.length; i++) { try { observer.unobserve(old[i]); } catch (e) {} if (visibleCards) visibleCards.delete(old[i]); }
  clearContainer(elSoundGrid);

  /* search view off, folder view on */
  if (elResults) elResults.style.display = "none";
  elFolderView.style.display = "";
  updateRightActions(node);

  var all = collectFiles(node, []);
  applySortMode(all);
  var total = all.length;
  var cleanName = String(node.name).replace(/^\u2605\s*/, "");

  if (total === 0) {
    elRightHead.textContent = cleanName;
    elSoundGrid.style.display = "none";
    elRightEmpty.style.display = "";
    elRightEmpty.textContent = node._favCat
      ? "Drag favorite sounds here to file them into this folder."
      : (node._favRoot
        ? "Tap the star on a sound (or on a whole folder) to add it here."
        : "This folder has no sounds.");
    return;
  }

  elRightEmpty.style.display = "none";
  elSoundGrid.style.display = "";
  elRightHead.textContent = cleanName + "  \u00b7  " + total + " sound" + (total === 1 ? "" : "s");

  elPaneRight.scrollTop = 0;
  mountCards(elSoundGrid, all, null);   /* virtualized: only visible cards exist in the DOM */
}

/* order the list either in folder order (default) or with favorites first */
function applySortMode(list) {
  if (state.sortMode === "favfirst") {
    var fav = [], rest = [];
    for (var i = 0; i < list.length; i++) { if (list[i].path in state.favorites) fav.push(list[i]); else rest.push(list[i]); }
    list.length = 0;
    for (var a = 0; a < fav.length; a++) list.push(fav[a]);
    for (var b = 0; b < rest.length; b++) list.push(rest[b]);
  }
  /* "order" keeps the natural folder-by-folder order from collectFiles */
}
function setSortMode(m) {
  state.sortMode = (m === "favfirst") ? "favfirst" : "order";
  lsSet("amsfx_sort", state.sortMode);
  updateSortButtons();
  if (state.curFolder) showFolderSounds(state.curFolder);
}
function updateSortButtons() {
  if (!elSortOrder || !elSortFav) return;
  elSortOrder.classList.toggle("on", state.sortMode !== "favfirst");
  elSortFav.classList.toggle("on", state.sortMode === "favfirst");
}

var favEl = null;
function buildTree() {
  stopPlay();
  clearContainer(elTree);
  state.curFolderRow = null;
  favEl = makeFavNode();
  elTree.appendChild(favEl);                 /* Favorites is shared across ALL packs */
  if (state.packs.length < 2) state.searchAll = false;   /* "All" only makes sense with 2+ packs */
  renderPackTabs();
  if (!state.packs.length) return;
  if (state.activePack >= state.packs.length) state.activePack = state.packs.length - 1;
  if (state.activePack < 0) state.activePack = 0;

  if (state.searchAll) {
    /* ALL mode: every pack shows in the tree; the first is opened + selected */
    var firstEl = null;
    for (var i = 0; i < state.packs.length; i++) {
      var pe = makeFolderNode(state.packs[i].tree);
      pe._isPack = true;
      elTree.appendChild(pe);
      if (i === 0) firstEl = pe;
    }
    if (firstEl) { toggleNode(firstEl); selectFolder(firstEl, firstEl._node); }
    return;
  }

  var pk = state.packs[state.activePack];
  var el = makeFolderNode(pk.tree);
  el._isPack = true;
  elTree.appendChild(el);                     /* only the ACTIVE pack shows in the tree */
  toggleNode(el);
  selectFolder(el, el._node);
}

/* the All / L1 / L2 / ... buttons in the header */
function renderPackTabs() {
  if (!elPackTabs) return;
  clearContainer(elPackTabs);
  /* "All" tab (only with 2+ packs) searches across every pack at once */
  if (state.packs.length >= 2) {
    var all = document.createElement("button");
    all.className = "pack-tab" + (state.searchAll ? " on" : "");
    all.type = "button";
    all.textContent = "All";
    all.title = "Show and search every pack at once";
    all.addEventListener("click", function () { setSearchAll(); });
    elPackTabs.appendChild(all);
  }
  for (var i = 0; i < state.packs.length; i++) {
    (function (idx) {
      var b = document.createElement("button");
      b.className = "pack-tab" + ((!state.searchAll && idx === state.activePack) ? " on" : "");
      b.type = "button";
      b.textContent = "L" + (idx + 1);
      b.title = baseName(state.packs[idx].path) + "  (right-click to remove)";
      b.addEventListener("click", function () { setActivePack(idx); });
      b.addEventListener("contextmenu", function (ev) { if (ev.preventDefault) ev.preventDefault(); removePack(state.packs[idx].path); });
      elPackTabs.appendChild(b);
    })(i);
  }
}
function setActivePack(i) {
  if (i < 0 || i >= state.packs.length) return;
  if (i === state.activePack && !state.searchAll) return;
  state.activePack = i;
  state.searchAll = false;                    /* picking L1/L2 leaves "All" mode */
  elSearch.value = ""; elSearchBox.classList.remove("has-text"); state.query = "";
  elResults.style.display = "none"; elFolderView.style.display = "";
  buildTree();
}
/* switch to "All": show + search every pack */
function setSearchAll() {
  if (state.searchAll) return;
  state.searchAll = true;
  elSearch.value = ""; elSearchBox.classList.remove("has-text"); state.query = "";
  elResults.style.display = "none"; elFolderView.style.display = "";
  buildTree();
}

function favFileList() {
  var out = [];
  for (var i = 0; i < state.allFiles.length; i++) {
    if (state.allFiles[i].path in state.favorites) out.push(state.allFiles[i]);
  }
  out.sort(function (a, b) { return natCmp(a.name, b.name); });
  return out;
}
function makeFavNode() {
  /* uncategorized favorites (category == "") sit directly under Favorites */
  var uncategorized = [];
  for (var i = 0; i < state.allFiles.length; i++) {
    var p = state.allFiles[i].path;
    if ((p in state.favorites) && state.favorites[p] === "") uncategorized.push(state.allFiles[i]);
  }
  uncategorized.sort(function (a, b) { return natCmp(a.name, b.name); });
  /* each favorite category becomes a sub-folder */
  var dirs = [];
  for (var c = 0; c < state.favCats.length; c++) {
    var cat = state.favCats[c], cf = [];
    for (var j = 0; j < state.allFiles.length; j++) {
      var pp = state.allFiles[j].path;
      if ((pp in state.favorites) && state.favorites[pp] === cat) cf.push(state.allFiles[j]);
    }
    cf.sort(function (a, b) { return natCmp(a.name, b.name); });
    dirs.push({ name: cat, path: "::fav::" + cat, dirs: [], files: cf, audioCount: cf.length, totalCount: cf.length, _favCat: cat });
  }
  var total = uncategorized.length;
  for (var d = 0; d < dirs.length; d++) total += dirs[d].totalCount;
  var node = { name: "\u2605 Favorites", path: "::favorites::", dirs: dirs,
               files: uncategorized, audioCount: total, totalCount: total, _favRoot: true };
  return makeFolderNode(node);
}

/* keep the Favorites section in sync right after a star is toggled */
/* the "+ Folder" control shown in the right pane while viewing Favorites */
function updateRightActions(node) {
  if (!elRightActions) return;
  if (node && node._favRoot) { elRightActions.style.display = ""; resetFavActions(); }
  else elRightActions.style.display = "none";
}
function resetFavActions() {
  if (!elRightActions) return;
  clearContainer(elRightActions);
  var b = document.createElement("button");
  b.className = "mini-btn"; b.type = "button"; b.textContent = "+ Folder";
  b.title = "Create a folder inside Favorites";
  b.addEventListener("click", startAddCat);
  elRightActions.appendChild(b);
}
function startAddCat() {
  if (!elRightActions) return;
  clearContainer(elRightActions);
  var inp = document.createElement("input");
  inp.type = "text"; inp.className = "fav-cat-input"; inp.setAttribute("placeholder", "Folder name\u2026"); inp.setAttribute("maxlength", "40");
  var okB = document.createElement("button"); okB.className = "mini-btn"; okB.type = "button"; okB.textContent = "Add";
  function commit() { var v = (inp.value || "").trim(); if (v) addFavCat(v); resetFavActions(); }
  okB.addEventListener("click", commit);
  inp.addEventListener("keydown", function (e) {
    var k = e.keyCode || e.which;
    if (k === 13) { if (e.preventDefault) e.preventDefault(); commit(); }
    else if (k === 27) { if (e.preventDefault) e.preventDefault(); resetFavActions(); }
  });
  elRightActions.appendChild(inp); elRightActions.appendChild(okB);
  try { inp.focus(); } catch (e) {}
}

function refreshFavNode() {
  if (!favEl || !favEl.parentNode) return;
  var curInFav = state.curFolderEl && (favEl === state.curFolderEl || favEl.contains(state.curFolderEl));
  var selCat = curInFav && state.curFolder ? (state.curFolder._favCat || null) : null;
  var wasOpen = favEl.classList.contains("open");
  var fresh = makeFavNode();
  if (wasOpen || selCat) { buildNodeChildren(fresh); fresh._loaded = true; fresh.classList.add("open"); }
  favEl.parentNode.replaceChild(fresh, favEl);
  favEl = fresh;
  if (curInFav) {
    var target = fresh;
    if (selCat && fresh._children) {
      var kids = fresh._children.children;
      for (var i = 0; i < kids.length; i++) { if (kids[i]._node && kids[i]._node._favCat === selCat) { target = kids[i]; break; } }
    }
    selectFolder(target, target._node);
  }
}

/* ===================== search ===================== */
var searchTimer = null;
function onSearchInput() {
  var v = elSearch.value;
  elSearchBox.classList.toggle("has-text", v.length > 0);
  if (searchTimer) clearTimeout(searchTimer);
  searchTimer = setTimeout(function () { runSearch(v.trim()); }, 130);
}
/* the files to search: just the active pack, or every pack when "All" is on */
function packFlat(pk) { if (!pk._flat) pk._flat = collectFiles(pk.tree, []); return pk._flat; }
function searchScopeFiles() {
  if (state.searchAll || state.packs.length < 2) return state.allFiles;
  var pk = state.packs[state.activePack];
  return pk ? packFlat(pk) : state.allFiles;
}
function runSearch(qStr) {
  state.query = qStr;
  stopPlay();
  clearSearchHits();
  if (!qStr) {
    elResults.style.display = "none";
    elFolderView.style.display = "";
    return;
  }
  var ql = qStr.toLowerCase(), matches = [];
  /* SOUNDS: search the active pack only - unless the "All" tab is on */
  var scope = searchScopeFiles();
  for (var i = 0; i < scope.length; i++) {
    if (scope[i].name.toLowerCase().indexOf(ql) >= 0) matches.push(scope[i]);
  }
  if (preview.card && elResultsGrid.contains(preview.card)) teardownPreview();
  var oldR = elResultsGrid.querySelectorAll(".card");
  for (var r = 0; r < oldR.length; r++) { try { observer.unobserve(oldR[r]); } catch (e) {} if (visibleCards) visibleCards.delete(oldR[r]); }

  elFolderView.style.display = "none";
  elResults.style.display = "block";
  elResultsHead.textContent = matches.length + " result" + (matches.length === 1 ? "" : "s") + ' for "' + qStr + '"';
  clearContainer(elResultsGrid);
  elPaneRight.scrollTop = 0;
  if (matches.length === 0) {
    var em = document.createElement("div"); em.className = "sounds-empty"; em.textContent = "No sounds match.";
    elResultsGrid.appendChild(em);
  } else {
    mountCards(elResultsGrid, matches, null);
  }

  /* FOLDERS: also reveal matching folders on the left by expanding the path to them */
  expandMatchingFolders(ql);
}

/* remove the "matched folder" highlight from the tree */
function clearSearchHits() {
  if (!elTree) return;
  var hits = elTree.querySelectorAll(".search-hit");
  for (var i = 0; i < hits.length; i++) hits[i].classList.remove("search-hit");
  var mp = elTree.querySelectorAll(".match-path");
  for (var j = 0; j < mp.length; j++) mp[j].classList.remove("match-path");
  var sg = elTree.querySelectorAll(".searching");
  for (var s = 0; s < sg.length; s++) sg[s].classList.remove("searching");
}
function openNode(el) { if (el && !el.classList.contains("open")) toggleNode(el); }
function findChildElByNode(parentEl, node) {
  if (!parentEl || !parentEl._children) return null;
  var kids = parentEl._children.children;
  for (var i = 0; i < kids.length; i++) if (kids[i]._node === node) return kids[i];
  return null;
}
function getPackRootEl() {
  var kids = elTree.children;
  for (var i = 0; i < kids.length; i++) { if (kids[i] !== favEl && kids[i]._node && !kids[i]._node._favRoot) return kids[i]; }
  return null;
}
/* every pack root element currently in the tree (1 in normal mode, all of them in "All") */
function getPackRootEls() {
  var out = [], kids = elTree.children;
  for (var i = 0; i < kids.length; i++) { if (kids[i] !== favEl && kids[i]._node && !kids[i]._node._favRoot) out.push(kids[i]); }
  return out;
}
/* find, for the active pack, every folder whose name matches; return the node path to each */
function findFolderPaths(root, ql) {
  var results = [];
  function walk(node, trail) {
    var here = trail.concat([node]);
    if (node !== root && String(node.name).toLowerCase().indexOf(ql) >= 0) results.push(here);
    if (node.dirs) for (var i = 0; i < node.dirs.length; i++) walk(node.dirs[i], here);
  }
  walk(root, []);
  return results;
}
function expandMatchingFolders(ql) {
  var packEls = getPackRootEls();
  for (var e = 0; e < packEls.length; e++) {
    var packEl = packEls[e];
    if (!packEl || !packEl._node) continue;
    var paths = findFolderPaths(packEl._node, ql);
    if (!paths.length) continue;                     /* this pack has no folder match -> leave as-is */
    packEl.classList.add("searching");               /* turn on the "show only matches" filter */
    var limit = paths.length > 200 ? 200 : paths.length;
    for (var p = 0; p < limit; p++) {
      var pathNodes = paths[p], el = packEl;
      openNode(el);
      for (var k = 1; k < pathNodes.length; k++) {
        var childEl = findChildElByNode(el, pathNodes[k]);
        if (!childEl) break;
        childEl.classList.add("match-path");         /* keep this folder visible through the filter */
        if (k < pathNodes.length - 1) openNode(childEl);
        else { childEl.firstChild.classList.add("search-hit"); openNode(childEl); }
        el = childEl;
      }
    }
  }
}

/* ===================== live scaling (size + zoom) ===================== */
/* While a slider is dragged we ONLY nudge cheap CSS variables.
   No waveform is redrawn until the slider is released, and even then we
   redraw just the cards that are actually on screen. */

function applySize(v) {
  var scale = 0.72 + (v / 100) * 0.95;          /* 0.72 .. 1.67 */
  var waveH = Math.round(40 * scale);
  var cardMin = Math.round(150 * scale + 28);
  var s = document.documentElement.style;
  s.setProperty("--wave-h", waveH + "px");
  s.setProperty("--card-min", cardMin + "px");
}

/* zoom uses a GPU transform (no layout) for buttery-smooth dragging */
function applyZoom(v) {
  var z = 0.72 + (v / 100) * 0.9;               /* 0.72 .. 1.62 */
  curZoom = z;
  document.documentElement.style.setProperty("--ui-zoom", z.toFixed(3));
  /* only carry the (costly) transform layer when the user is actually zoomed */
  if (elBody) elBody.classList.toggle("zoomed", Math.abs(z - 1) > 0.02);
}
/* width compensation re-flows columns to fit; only run on release (it lays out) */
function settleZoom(v) {
  var z = 0.72 + (v / 100) * 0.9;
  document.documentElement.style.setProperty("--ui-zoom-w", z.toFixed(3));
}

/* ---- draggable divider between folders (left) and sounds (right) ---- */
var splitDrag = { active: false, startX: 0, startW: 0, totalW: 320 };
function dividerDown(e) {
  splitDrag.active = true;
  splitDrag.startX = (e.clientX != null ? e.clientX : 0);
  splitDrag.startW = elPaneLeft.getBoundingClientRect().width;
  splitDrag.totalW = elSplit.getBoundingClientRect().width || 320;
  elDivider.classList.add("drag");
  if (elDivider.setPointerCapture && e.pointerId != null) { try { elDivider.setPointerCapture(e.pointerId); } catch (_) {} }
  if (e.preventDefault) e.preventDefault();
}
function dividerMove(e) {
  if (!splitDrag.active) return;
  var dx = (e.clientX != null ? e.clientX : 0) - splitDrag.startX;
  var w = splitDrag.startW + dx;
  var maxW = Math.max(160, splitDrag.totalW * 0.72);
  if (w < 118) w = 118; if (w > maxW) w = maxW;
  document.documentElement.style.setProperty("--split-left", w + "px");
}
function dividerUp() {
  if (!splitDrag.active) return;
  splitDrag.active = false; elDivider.classList.remove("drag");
  var w = Math.round(elPaneLeft.getBoundingClientRect().width);
  lsSet("amsfx_split", String(w));
  vgRelayoutSoon();
  redrawVisibleSoon();   /* re-flow / redraw sound cards after the width change */
}

/* collect ONLY the cards currently within (or just outside) the viewport */
function cardsInView() {
  if (visibleCards) {
    var out = [];
    visibleCards.forEach(function (c) { if (c._pk || c._failed) out.push(c); });
    return out;
  }
  /* fallback when Set is unavailable */
  var cards = elBody.querySelectorAll(".card.ready");
  if (!cards.length) return [];
  var br = elPaneRight.getBoundingClientRect();
  var top = br.top - 240, bot = br.bottom + 240;
  var res = [];
  for (var i = 0; i < cards.length; i++) {
    var r = cards[i].getBoundingClientRect();
    if (r.height && r.bottom > top && r.top < bot) res.push(cards[i]);
  }
  return res;
}
var redrawTimer = null;
function redrawVisibleSoon() {
  if (redrawTimer) return;
  redrawTimer = setTimeout(function () {
    redrawTimer = null;
    var cards = cardsInView();
    for (var i = 0; i < cards.length; i++) { cards[i]._drawn = false; drawCardSafe(cards[i], 8); }
  }, 40);
}

/* run fn at most once per animation frame, always with the latest value */
function rafThrottle(fn) {
  var pending = false, last = null;
  return function (arg) {
    last = arg;
    if (pending) return;
    pending = true;
    requestAnimationFrame(function () { pending = false; fn(last); });
  };
}
var sizeLive = rafThrottle(applySize);
var zoomLive = rafThrottle(applyZoom);

/* ===================== folder picker + library load ===================== */
function pickFromResult(res) {
  if (!res) return null;
  if (typeof res === "string") return res || null;
  if (res.data) { if (typeof res.data === "string") return res.data; if (res.data.length) return res.data[0]; }
  if (res.length) return res[0];
  return null;
}
function normPick(p) {
  if (!p) return p;
  if (p.indexOf("file://") === 0) {
    p = p.replace(/^file:\/\//, "");
    try { p = decodeURI(p); } catch (e) {}
    if (/^\/[A-Za-z]:/.test(p)) p = p.substring(1);
  }
  return p;
}
function lastPackPath() { return state.packs.length ? state.packs[state.packs.length - 1].path : ""; }
function chooseFolder() {
  var dir = null;
  try {
    if (window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx) {
      dir = pickFromResult(window.cep.fs.showOpenDialogEx(false, true, "Choose your sound pack folder", lastPackPath()));
    }
  } catch (e) {}
  if (!dir) {
    try {
      if (window.cep && window.cep.fs && window.cep.fs.showOpenDialog) {
        dir = pickFromResult(window.cep.fs.showOpenDialog(false, true, "Choose your sound pack folder", lastPackPath()));
      }
    } catch (e2) {}
  }
  if (dir) addPack(normPick(dir));
}

function showLoading(txt) {
  elLoadingTxt.innerHTML = txt || "Loading&hellip;";
  elEmpty.classList.remove("show");
  elSplit.style.display = "flex";
  elFolderView.style.display = "none"; elResults.style.display = "none";
  elLoading.style.display = "flex";
}
function hideLoading() { elLoading.style.display = "none"; }
function showEmpty() {
  elEmpty.classList.add("show");
  elSplit.style.display = "none";
  elLoading.style.display = "none";
}

/* rebuild the flat search index from whatever packs are loaded */
function rebuildAllFiles() {
  state.allFiles = [];
  for (var i = 0; i < state.packs.length; i++) collectFiles(state.packs[i].tree, state.allFiles);
}
function savePackPaths() {
  var paths = []; for (var i = 0; i < state.packs.length; i++) paths.push(state.packs[i].path);
  lsSet("amsfx_roots", JSON.stringify(paths));
}
function setLibName() {
  if (!elLibName) return;
  var n = state.packs.length;
  elLibName.textContent = n > 1 ? ("Library \u00b7 " + n) : "Library";
  elLibName.title = n + " pack" + (n === 1 ? "" : "s");
}
/* scan a list of folder paths into state.packs (rebuilds allFiles) */
function loadPacks(paths) {
  state.packs = []; state.allFiles = [];
  for (var i = 0; i < paths.length; i++) {
    try { var t = scanDir(paths[i]); if (t) state.packs.push({ path: paths[i], tree: t }); } catch (e) {}
  }
}
/* ADD another pack (does not replace the previous ones) */
function addPack(dir) {
  if (!fs) { toast("File access unavailable", true); return; }
  for (var i = 0; i < state.packs.length; i++) { if (state.packs[i].path === dir) { toast("That pack is already added"); return; } }
  showLoading("Scanning pack&hellip;");
  setTimeout(function () {
    var t = null; try { t = scanDir(dir); } catch (e) {}
    hideLoading();
    if (!t) { toast("Couldn't read folder", true); if (!state.packs.length) showEmpty(); return; }
    state.packs.push({ path: dir, tree: t });   /* scanDir already appended its files to state.allFiles */
    state.activePack = state.packs.length - 1;   /* show the pack you just added */
    savePackPaths(); setLibName();
    elEmpty.classList.remove("show"); elSplit.style.display = "flex";
    elSearch.value = ""; elSearchBox.classList.remove("has-text"); state.query = "";
    elResults.style.display = "none"; elFolderView.style.display = "";
    buildTree();
  }, 40);
}
/* remove a pack from the list (right-click on it) */
function removePack(dir) {
  for (var i = 0; i < state.packs.length; i++) { if (state.packs[i].path === dir) { state.packs.splice(i, 1); break; } }
  if (state.activePack >= state.packs.length) state.activePack = state.packs.length - 1;
  if (state.activePack < 0) state.activePack = 0;
  savePackPaths(); setLibName();
  rebuildAllFiles();
  clearSelection();
  stopPlay();
  if (!state.packs.length) { renderPackTabs(); showEmpty(); return; }
  buildTree();
  toast("Pack removed");
}

/* ===================== add to Premiere ===================== */
function callAddPath(path, atSeconds, doPlace, cb) {
  var esc = String(path).replace(/\\/g, "\\\\").replace(/'/g, "\\'");
  cs.evalScript("am_add('" + esc + "'," + atSeconds + "," + (doPlace ? "true" : "false") + ")", cb);
}

/* ---- render a faded copy of a sound, so the clip added to Premiere is faded ---- */
function fadeCacheDir() {
  try {
    var dir = pathMod.join(os.homedir(), ".amanow_sfx", "fades");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
  } catch (e) { return null; }
}
function sanitizeName(n) { return String(n).replace(/[^A-Za-z0-9._-]/g, "_").slice(0, 80); }
function applyFadeToBuffer(buf, fi, fo) {
  var sr = buf.sampleRate, len = buf.length;
  var nIn = Math.min(len, Math.round(fi * sr)), nOut = Math.min(len, Math.round(fo * sr));
  for (var c = 0; c < buf.numberOfChannels; c++) {
    var d = buf.getChannelData(c);
    if (nIn > 0) for (var i = 0; i < nIn; i++) d[i] *= i / nIn;
    if (nOut > 0) for (var j = 0; j < nOut; j++) { var k = len - 1 - j; if (k >= 0) d[k] *= j / nOut; }
  }
}
function audioBufToWav(buf) {
  var nCh = buf.numberOfChannels, len = buf.length, sr = buf.sampleRate;
  var blockAlign = nCh * 2, dataLen = len * blockAlign;
  var ab = new ArrayBuffer(44 + dataLen), dv = new DataView(ab);
  function wstr(off, s) { for (var i = 0; i < s.length; i++) dv.setUint8(off + i, s.charCodeAt(i)); }
  wstr(0, "RIFF"); dv.setUint32(4, 36 + dataLen, true); wstr(8, "WAVE");
  wstr(12, "fmt "); dv.setUint32(16, 16, true); dv.setUint16(20, 1, true);
  dv.setUint16(22, nCh, true); dv.setUint32(24, sr, true);
  dv.setUint32(28, sr * blockAlign, true); dv.setUint16(32, blockAlign, true);
  dv.setUint16(34, 16, true); wstr(36, "data"); dv.setUint32(40, dataLen, true);
  var chans = []; for (var c = 0; c < nCh; c++) chans.push(buf.getChannelData(c));
  var off = 44;
  for (var i = 0; i < len; i++) {
    for (var ch = 0; ch < nCh; ch++) {
      var s = chans[ch][i]; if (s > 1) s = 1; if (s < -1) s = -1;
      dv.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true); off += 2;
    }
  }
  return Buffer.from(ab);
}
function renderFadedToFile(f, cb) {
  var fi = state.fadeIn, fo = state.fadeOut;
  if (!(fi > 0 || fo > 0) || !fs || !pathMod || !os) { cb(f.path); return; }
  var dir = fadeCacheDir(); if (!dir) { cb(f.path); return; }
  var base = baseName(f.path).replace(/\.[^.]+$/, "");
  var out = pathMod.join(dir, sanitizeName(base) + "__in" + fi.toFixed(2) + "_out" + fo.toFixed(2) + ".wav");
  try { if (fs.existsSync(out)) { cb(out); return; } } catch (e) {}
  fs.readFile(f.path, function (err, buf) {
    if (err) { cb(f.path); return; }
    var ctx = audioCtx(); if (!ctx) { cb(f.path); return; }
    var ab = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength), done = false;
    try {
      ctx.decodeAudioData(ab, function (audioBuf) {
        if (done) return; done = true;
        try {
          applyFadeToBuffer(audioBuf, fi, fo);
          fs.writeFile(out, audioBufToWav(audioBuf), function (werr) { cb(werr ? f.path : out); });
        } catch (e2) { cb(f.path); }
      }, function () { if (done) return; done = true; cb(f.path); });
    } catch (e3) { cb(f.path); }
  });
}

function doAdd() {
  var files = [];
  for (var i = 0; i < state.selOrder.length; i++) { var f = state.sel[state.selOrder[i]]; if (f) files.push(f); }
  if (files.length === 0) return;
  var fading = (state.fadeIn > 0 || state.fadeOut > 0);
  if (elAddBtn) elAddBtn.disabled = true;
  if (fading) toast("Rendering fades\u2026");
  cs.evalScript("am_hasSeq()", function (hs) {
    var place = (String(hs) === "1");
    cs.evalScript("am_playhead()", function (ph) {
      var t = parseFloat(ph); if (!(t >= 0)) t = 0;
      var added = 0, failed = 0, idx = 0;
      function place1(f, dur) {
        renderFadedToFile(f, function (importPath) {
          callAddPath(importPath, place ? t : -1, place, function (res) {
            if (String(res).indexOf("OK") === 0) { added++; if (place) t += dur; } else failed++;
            next();
          });
        });
      }
      function next() {
        if (idx >= files.length) { finish(); return; }
        var f = files[idx++];
        ensurePeaks(f).then(function (pk) { place1(f, (pk && pk.dur) ? pk.dur : 0); },
                            function () { place1(f, 0); });
      }
      function finish() {
        if (elAddBtn) elAddBtn.disabled = false;
        clearSelection();
        var msg = (place ? "Placed " : "Imported ") + added + " sound" + (added === 1 ? "" : "s");
        if (failed > 0) msg += ", " + failed + " failed";
        toast(msg, failed > 0);
      }
      next();
    });
  });
}

/* ===================== toast ===================== */
var toastTimer = null;
function toast(msg, isErr) {
  elToast.textContent = msg;
  elToast.className = "toast show" + (isErr ? " err" : "");
  if (toastTimer) clearTimeout(toastTimer);
  toastTimer = setTimeout(function () { elToast.className = "toast" + (isErr ? " err" : ""); }, 2600);
}

/* ===================== init ===================== */
/* ===================== EFFECT tab ===================== */
/* All audio processing is pure JS (no Web Audio graph) so it is reliable and
   testable. Effects stack in a fixed order: speed -> soften -> volume -> repeat. */

var fx = { src: null, info: null, peaks: null,
           speedOn: false, speedS: 50, keepPitch: false,
           repeatOn: false, repeatN: 2,
           mutingOn: false, mutingS: 50 };
var fxActive = false;

/* ---- buffer helpers ---- */
function fxMakeBuf(nCh, len, sr) {
  var d = []; for (var c = 0; c < nCh; c++) d.push(new Float32Array(len));
  return { numberOfChannels: nCh, length: len, sampleRate: sr, _d: d,
           getChannelData: function (c) { return this._d[c]; } };
}
function fxMonoMix(buf) {
  var nCh = buf.numberOfChannels, len = buf.length, out = new Float32Array(len);
  for (var c = 0; c < nCh; c++) { var d = buf.getChannelData(c); for (var i = 0; i < len; i++) out[i] += d[i] / nCh; }
  return out;
}
function fxHann(N) { var w = new Float32Array(N); for (var i = 0; i < N; i++) w[i] = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / (N - 1)); return w; }
function fxSlice(buf, inSec, outSec) {
  var sr = buf.sampleRate;
  var s0 = Math.max(0, Math.floor(inSec * sr)), s1 = Math.min(buf.length, Math.floor(outSec * sr));
  if (s1 <= s0) { s0 = 0; s1 = buf.length; }
  var len = s1 - s0, nCh = buf.numberOfChannels, out = fxMakeBuf(nCh, len, sr);
  for (var c = 0; c < nCh; c++) out.getChannelData(c).set(buf.getChannelData(c).subarray(s0, s1));
  return out;
}

/* resample = speed + pitch change ("with distortion") */
function fxResample(buf, factor) {
  var inLen = buf.length, outLen = Math.max(1, Math.round(inLen / factor)), nCh = buf.numberOfChannels;
  var out = fxMakeBuf(nCh, outLen, buf.sampleRate);
  for (var c = 0; c < nCh; c++) {
    var src = buf.getChannelData(c), dst = out.getChannelData(c);
    for (var i = 0; i < outLen; i++) {
      var pos = i * factor, i0 = Math.floor(pos), frac = pos - i0;
      var a = (i0 < inLen) ? src[i0] : 0, b = (i0 + 1 < inLen) ? src[i0 + 1] : a;
      dst[i] = a + (b - a) * frac;
    }
  }
  return out;
}

/* WSOLA time-stretch = speed change, pitch preserved ("without distortion") */
function fxWsolaPlan(ref, ratio, sr) {
  var inLen = ref.length;
  var N = Math.round(0.046 * sr); if (N < 128) N = 128; if (N % 2) N++;
  if (N > inLen) { N = Math.max(4, inLen - (inLen % 2)); }
  var Hs = Math.round(N / 2), Ha = Math.max(1, Math.round(Hs / ratio));
  var seek = Math.round(0.010 * sr), outLen = Math.max(1, Math.round(inLen * ratio));
  var frames = [], anaPos = 0, synPos = 0, delta = 0;
  while (synPos < outLen) {
    var start = anaPos + delta;
    if (start < 0) start = 0; if (start + N > inLen) start = inLen - N; if (start < 0) start = 0;
    frames.push({ start: start, syn: synPos });
    var naturalNext = anaPos + Ha, L = N - Hs; if (L < 1) L = 1;
    var tmplStart = start + Hs, bestDelta = 0, bestCorr = -1e30;
    if (tmplStart >= 0 && tmplStart + L <= inLen) {
      for (var d = -seek; d <= seek; d++) {
        var cs = naturalNext + d; if (cs < 0 || cs + L > inLen) continue;
        var corr = 0; for (var j = 0; j < L; j += 2) corr += ref[tmplStart + j] * ref[cs + j];
        if (corr > bestCorr) { bestCorr = corr; bestDelta = d; }
      }
    }
    delta = bestDelta; anaPos = naturalNext; synPos += Hs;
  }
  return { frames: frames, N: N, outLen: outLen, win: fxHann(N) };
}
function fxWsolaSynth(x, plan) {
  var N = plan.N, win = plan.win, outLen = plan.outLen, frames = plan.frames, inLen = x.length;
  var y = new Float32Array(outLen + N), ws = new Float32Array(outLen + N);
  for (var f = 0; f < frames.length; f++) {
    var start = frames[f].start, syn = frames[f].syn;
    for (var k = 0; k < N; k++) {
      var xi = start + k; if (xi < 0 || xi >= inLen) continue;
      var yi = syn + k; if (yi >= y.length) break;
      y[yi] += x[xi] * win[k]; ws[yi] += win[k];
    }
  }
  var out = new Float32Array(outLen);
  for (var i = 0; i < outLen; i++) out[i] = ws[i] > 1e-6 ? y[i] / ws[i] : 0;
  return out;
}
function fxTimeStretch(buf, ratio) {
  var sr = buf.sampleRate, ref = fxMonoMix(buf), plan = fxWsolaPlan(ref, ratio, sr), nCh = buf.numberOfChannels;
  var out = fxMakeBuf(nCh, plan.outLen, sr);
  for (var c = 0; c < nCh; c++) out.getChannelData(c).set(fxWsolaSynth(buf.getChannelData(c), plan));
  return out;
}

/* RBJ biquad filter (Direct Form I) — used for the EQ-based softness */
function fxBiquad(buf, type, f0, dB, Q) {
  var A = Math.pow(10, dB / 40), w0 = 2 * Math.PI * f0 / buf.sampleRate;
  var cw = Math.cos(w0), sw = Math.sin(w0), al = sw / (2 * Q);
  var b0, b1, b2, a0, a1, a2, p, m, t;
  if (type === "peaking") {
    b0 = 1 + al * A; b1 = -2 * cw; b2 = 1 - al * A;
    a0 = 1 + al / A; a1 = -2 * cw; a2 = 1 - al / A;
  } else if (type === "highshelf") {
    p = A + 1; m = A - 1; t = 2 * Math.sqrt(A) * al;
    b0 = A * (p + m * cw + t); b1 = -2 * A * (m + p * cw); b2 = A * (p + m * cw - t);
    a0 = p - m * cw + t; a1 = 2 * (m - p * cw); a2 = p - m * cw - t;
  } else if (type === "lowshelf") {
    p = A + 1; m = A - 1; t = 2 * Math.sqrt(A) * al;
    b0 = A * (p - m * cw + t); b1 = 2 * A * (m - p * cw); b2 = A * (p - m * cw - t);
    a0 = p + m * cw + t; a1 = -2 * (m + p * cw); a2 = p + m * cw - t;
  } else if (type === "lowpass") {
    b0 = (1 - cw) / 2; b1 = 1 - cw; b2 = (1 - cw) / 2;
    a0 = 1 + al; a1 = -2 * cw; a2 = 1 - al;
  } else if (type === "highpass") {
    b0 = (1 + cw) / 2; b1 = -(1 + cw); b2 = (1 + cw) / 2;
    a0 = 1 + al; a1 = -2 * cw; a2 = 1 - al;
  } else { /* notch (band-reject) */
    b0 = 1; b1 = -2 * cw; b2 = 1;
    a0 = 1 + al; a1 = -2 * cw; a2 = 1 - al;
  }
  b0 /= a0; b1 /= a0; b2 /= a0; a1 /= a0; a2 /= a0;
  for (var c = 0; c < buf.numberOfChannels; c++) {
    var d = buf.getChannelData(c), x1 = 0, x2 = 0, y1 = 0, y2 = 0;
    for (var i = 0; i < d.length; i++) {
      var x0 = d[i], y0 = b0 * x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
      x2 = x1; x1 = x0; y2 = y1; y1 = y0; d[i] = y0;
    }
  }
  return buf;
}
function fxRms(buf) {
  var s = 0, n = 0;
  for (var c = 0; c < buf.numberOfChannels; c++) { var d = buf.getChannelData(c); for (var i = 0; i < d.length; i++) s += d[i] * d[i]; n += d.length; }
  return Math.sqrt(s / Math.max(n, 1));
}
function fxPeakVal(buf) {
  var m = 0;
  for (var c = 0; c < buf.numberOfChannels; c++) { var d = buf.getChannelData(c); for (var i = 0; i < d.length; i++) { var v = d[i] < 0 ? -d[i] : d[i]; if (v > m) m = v; } }
  return m;
}

/* transient softener — reduces sharp attack spikes so a hard click becomes a soft "pop" */
function fxTransSoften(buf, amount) {
  if (amount <= 0) return buf;
  var sr = buf.sampleRate;
  var aF = 1 - Math.exp(-1 / (0.0004 * sr));   /* fast envelope ~0.4 ms */
  var aS = 1 - Math.exp(-1 / (0.030 * sr));    /* slow envelope ~30 ms  */
  var aG = 1 - Math.exp(-1 / (0.002 * sr));    /* gain smoothing ~2 ms  */
  for (var c = 0; c < buf.numberOfChannels; c++) {
    var d = buf.getChannelData(c), ef = 0, es = 0, gs = 1;
    for (var i = 0; i < d.length; i++) {
      var a = d[i] < 0 ? -d[i] : d[i];
      ef += aF * (a - ef); es += aS * (a - es);
      var tr = ef > es ? (ef - es) / (ef + 1e-9) : 0;
      var gt = 1 - amount * tr; if (gt < 0.15) gt = 0.15;
      gs += aG * (gt - gs); d[i] *= gs;
    }
  }
  return buf;
}

/* MELLOW (dropdown effect) — rounds a hard/sharp sound into a soft "pop":
   tames the harsh top edge and softens the sharp attack, keeping loudness. */
function fxMellow(buf, amountPct, tamePct) {
  var amount = amountPct / 100, tame = tamePct / 100;
  if (amount <= 0 && tame <= 0) return buf;
  var inR = fxRms(buf);
  fxBiquad(buf, "highpass", 150, 0, 0.7);
  if (tame > 0) fxBiquad(buf, "highshelf", 8000, -22 * tame, 0.7);
  if (amount > 0) fxTransSoften(buf, 0.75 * amount);
  var outR = fxRms(buf);
  if (outR > 1e-6) { var mk = inR / outR; if (mk > 10) mk = 10; fxGain(buf, mk); }
  var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk);
  return buf;
}

/* COMPRESSOR — feed-forward peak compressor with smoothed gain (attack/release),
   threshold, ratio and makeup. Stereo-linked (one gain for all channels). */
function fxCompress(buf, threshDb, ratio, attMs, relMs, makeupDb) {
  if (ratio < 1) ratio = 1;
  var sr = buf.sampleRate, len = buf.length, nCh = buf.numberOfChannels;
  var inR = fxRms(buf);
  var thr = Math.pow(10, threshDb / 20), makeup = Math.pow(10, makeupDb / 20);
  var att = Math.exp(-1 / (Math.max(0.1, attMs) / 1000 * sr));
  var rel = Math.exp(-1 / (Math.max(1, relMs) / 1000 * sr));
  var slope = 1 / ratio - 1;   /* <= 0 */
  var ch = []; for (var c = 0; c < nCh; c++) ch.push(buf.getChannelData(c));
  var g = 1;
  for (var i = 0; i < len; i++) {
    var x = 0;
    for (var c2 = 0; c2 < nCh; c2++) { var a = ch[c2][i]; if (a < 0) a = -a; if (a > x) x = a; }
    var desired = 1;
    if (x > thr && x > 0) desired = Math.pow(x / thr, slope);
    var coef = desired < g ? att : rel;       /* attack when clamping down */
    g = coef * g + (1 - coef) * desired;
    for (var c3 = 0; c3 < nCh; c3++) ch[c3][i] *= g;
  }
  /* auto level restore: bring most of the lost loudness back, so the loud
     parts stay calmed while the quiet parts come up. Makeup adds on top. */
  var outR = fxRms(buf);
  var auto = 1;
  if (outR > 1e-6 && inR > 0) { auto = Math.pow(inR / outR, 0.85); if (auto > 8) auto = 8; if (auto < 1) auto = 1; }
  fxGain(buf, auto * makeup);
  var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk);
  return buf;
}

/* ECHO — delay with feedback, wet/dry mix, and a tone (low-pass) on the repeats.
   The buffer is extended so the echo tail rings out and fades naturally
   instead of being cut off at the end of the clip. */
function fxEcho(buf, timeMs, fbPct, mixPct, tonePct) {
  var sr = buf.sampleRate;
  var d = Math.max(1, Math.round(timeMs / 1000 * sr));
  var fb = Math.min(0.95, Math.max(0, fbPct / 100 * 0.95));
  var mix = Math.max(0, Math.min(1, mixPct / 100));
  if (mix <= 0) return buf;
  /* how many repeats stay audible (down to ~-48 dB), then pad for that tail */
  var audible = 0.004, reps = 1;
  if (fb > 0.01) {
    reps = Math.ceil(Math.log(audible / Math.max(audible, mix)) / Math.log(fb));
    if (!(reps >= 1)) reps = 1; if (reps > 60) reps = 60;
  }
  var tail = Math.min(Math.round(10 * sr), d * (reps + 1));
  buf = fxPadTo(buf, buf.length + tail);
  var len = buf.length, nCh = buf.numberOfChannels;
  var lpCut = 600 + (tonePct / 100) * (9000 - 600);
  var lpA = 1 - Math.exp(-2 * Math.PI * lpCut / sr);
  for (var c = 0; c < nCh; c++) {
    var x = buf.getChannelData(c);
    var line = new Float32Array(d), lp = 0, wi = 0;
    for (var i = 0; i < len; i++) {
      var ds = line[wi];                 /* delayed (echo) sample */
      var into = x[i] + ds * fb;         /* feedback into the delay line */
      lp += lpA * (into - lp);           /* tone: low-pass the repeats */
      line[wi] = lp;
      x[i] = x[i] + mix * ds;            /* mix the echo back in */
      wi++; if (wi >= d) wi = 0;
    }
  }
  var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk);
  return buf;
}

/* SOFTNESS (built-in) — smooth low-pass "muffle" that softens the sound.
   Q=0.5 per stage = critically damped: no resonance, no ringing on transients,
   so there are NO "bubble/water" artifacts. */
function fxMuting(buf, amount) {
  if (amount <= 0) return buf;
  var inR = fxRms(buf);
  var cut = 6000 * Math.pow(380 / 6000, amount);   /* 6000 Hz -> 380 Hz */
  fxBiquad(buf, "lowpass", cut, 0, 0.5);
  fxBiquad(buf, "lowpass", cut, 0, 0.5);           /* clean, smooth, no bubbles */
  var outR = fxRms(buf);
  if (outR > 1e-6) { var mk = Math.pow(inR / outR, 0.9); if (mk > 12) mk = 12; fxGain(buf, mk); }
  var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk);
  return buf;
}
/* ---- shared helpers for effects ---- */
function fxCloneBuf(buf) {
  var o = fxMakeBuf(buf.numberOfChannels, buf.length, buf.sampleRate);
  for (var c = 0; c < buf.numberOfChannels; c++) o.getChannelData(c).set(buf.getChannelData(c));
  return o;
}
function fxPeakGuard(buf) { var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk); }
function fxFixLevel(buf, inR) {
  var o = fxRms(buf);
  if (o > 1e-6 && inR > 0) { var mk = inR / o; if (mk > 8) mk = 8; if (mk < 0.2) mk = 0.2; fxGain(buf, mk); }
  fxPeakGuard(buf);
}

/* NOTCH FILTER — remove a narrow band (hum / whistle); depth blends dry<->notched. */
function fxNotch(buf, freq, depthPct, q) {
  var depth = Math.max(0, Math.min(1, depthPct / 100));
  if (depth <= 0) return buf;
  var nCh = buf.numberOfChannels, len = buf.length, dry = [];
  for (var c = 0; c < nCh; c++) { var cp = new Float32Array(len); cp.set(buf.getChannelData(c)); dry.push(cp); }
  fxBiquad(buf, "notch", freq, 0, Math.max(0.3, q));
  for (var c2 = 0; c2 < nCh; c2++) { var d = buf.getChannelData(c2), dd = dry[c2]; for (var i = 0; i < len; i++) d[i] = dd[i] * (1 - depth) + d[i] * depth; }
  return buf;
}

/* HARD LIMITER — drive up, then a lookahead brick-wall to a ceiling.
   The gain is lowered ~2 ms BEFORE each peak arrives (moving-minimum
   lookahead), so the wall is transparent: no crack or distortion. */
function fxLimiter(buf, ceilDb, driveDb, relMs) {
  var sr = buf.sampleRate, len = buf.length, nCh = buf.numberOfChannels;
  if (len < 2) return buf;
  var ceil = Math.min(0.99, Math.pow(10, ceilDb / 20)), drive = Math.pow(10, driveDb / 20);
  var rel = Math.exp(-1 / (Math.max(1, relMs) / 1000 * sr));
  var ch = []; for (var c = 0; c < nCh; c++) ch.push(buf.getChannelData(c));
  /* 1) apply drive and compute the per-sample target gain */
  var tg = new Float32Array(len);
  for (var i = 0; i < len; i++) {
    var x = 0;
    for (var c2 = 0; c2 < nCh; c2++) { var v = ch[c2][i] * drive; ch[c2][i] = v; var a = v < 0 ? -v : v; if (a > x) x = a; }
    tg[i] = x > ceil ? ceil / x : 1;
  }
  /* 2) lookahead: minimum target over the next L samples (monotonic deque) */
  var L = Math.max(1, Math.round(0.002 * sr));
  var mg = new Float32Array(len);
  var qi = new Int32Array(len), qh = 0, qt = 0;
  for (var j = 0; j < len; j++) {
    while (qt > qh && tg[j] <= tg[qi[qt - 1]]) qt--;
    qi[qt++] = j;
    var w0 = j - L;
    if (w0 >= 0) { while (qh < qt && qi[qh] < w0) qh++; mg[w0] = tg[qi[qh]]; }
  }
  var run = 1;
  for (var e = len - 1; e >= Math.max(0, len - L); e--) { if (tg[e] < run) run = tg[e]; mg[e] = run; }
  /* 3) smooth: fast dip toward the lookahead minimum, slow release back up */
  var attS = Math.exp(-1 / (0.0007 * sr));
  var g = 1;
  for (var k = 0; k < len; k++) {
    var t = mg[k];
    if (t < g) g = attS * g + (1 - attS) * t; else g = rel * g + (1 - rel) * t;
    if (g > 1) g = 1;
    for (var c3 = 0; c3 < nCh; c3++) {
      var y = ch[c3][k] * g;
      if (y > ceil) y = ceil; else if (y < -ceil) y = -ceil;   /* safety clamp */
      ch[c3][k] = y;
    }
  }
  return buf;
}

/* BALANCE — stereo pan left/right (no effect on mono clips). */
function fxBalance(buf, balPct) {
  if (buf.numberOfChannels < 2) return buf;
  var b = Math.max(-100, Math.min(100, balPct)) / 100;
  var lg = b > 0 ? (1 - b) : 1, rg = b < 0 ? (1 + b) : 1;
  var L = buf.getChannelData(0), R = buf.getChannelData(1), len = buf.length;
  for (var i = 0; i < len; i++) { L[i] *= lg; R[i] *= rg; }
  return buf;
}

/* EXCITER — adds bright harmonics for sparkle / air on the top end. */
function fxExciter(buf, amountPct, freq, mixPct) {
  var amount = amountPct / 100, mix = mixPct / 100;
  if (amount <= 0 || mix <= 0) return buf;
  var nCh = buf.numberOfChannels, len = buf.length;
  var wet = fxCloneBuf(buf);
  fxBiquad(wet, "highpass", freq, 0, 0.7);
  for (var c = 0; c < nCh; c++) {
    var d = buf.getChannelData(c), w = wet.getChannelData(c);
    for (var i = 0; i < len; i++) { var s = Math.tanh(w[i] * (1 + 5 * amount)); d[i] = d[i] + mix * amount * 0.8 * s; }
  }
  fxPeakGuard(buf);
  return buf;
}

/* VOCAL ENHANCER — clarity for voice: cut rumble + mud, lift presence, gentle leveling. */
function fxVocal(buf, amountPct, presencePct, warmthPct) {
  var amount = amountPct / 100, pres = presencePct / 100, warm = warmthPct / 100;
  var inR = fxRms(buf);
  fxBiquad(buf, "highpass", 90, 0, 0.7);
  fxBiquad(buf, "peaking", 300, -4 * amount, 1.0);
  fxBiquad(buf, "peaking", 4500, 8 * pres, 0.9);
  if (warm > 0) fxBiquad(buf, "lowshelf", 200, 3 * warm, 0.7);
  fxCompress(buf, -26, 3, 15, 160, 0);
  fxFixLevel(buf, inR);
  return buf;
}

/* LOFI — vintage / telephone: bit-crush + sample-rate reduce + band-limit. */
function fxLofi(buf, crushPct, srReducePct, tonePct) {
  var crush = crushPct / 100, srr = srReducePct / 100, tone = tonePct / 100;
  var nCh = buf.numberOfChannels, len = buf.length;
  var bits = Math.round(16 - crush * 12); if (bits < 2) bits = 2; var levels = Math.pow(2, bits);
  var hold = 1 + Math.round(srr * 15);
  fxBiquad(buf, "highpass", 200 + tone * 300, 0, 0.7);
  fxBiquad(buf, "lowpass", 6000 - tone * 4200, 0, 0.7);
  for (var c = 0; c < nCh; c++) {
    var d = buf.getChannelData(c), held = 0;
    for (var i = 0; i < len; i++) { if (i % hold === 0) held = d[i]; d[i] = Math.round(held * levels) / levels; }
  }
  fxPeakGuard(buf);
  return buf;
}

/* MULTITAP DELAY — several echoes at multiples of the base time.
   The buffer is extended so all taps and the feedback trail ring out fully. */
function fxMultitap(buf, timeMs, taps, fbPct, mixPct, tonePct) {
  var sr = buf.sampleRate;
  var base = Math.max(1, Math.round(timeMs / 1000 * sr));
  taps = Math.max(1, Math.min(8, Math.round(taps)));
  var fb = Math.min(0.9, Math.max(0, fbPct / 100 * 0.9));
  var mix = Math.max(0, Math.min(1, mixPct / 100));
  if (mix <= 0) return buf;
  var audible = 0.004, repsFb = 0;
  if (fb > 0.01) {
    repsFb = Math.ceil(Math.log(audible / Math.max(audible, mix)) / Math.log(fb));
    if (!(repsFb >= 0)) repsFb = 0; if (repsFb > 60) repsFb = 60;
  }
  var tail = Math.min(Math.round(10 * sr), base * (taps + repsFb + 1));
  buf = fxPadTo(buf, buf.length + tail);
  var len = buf.length, nCh = buf.numberOfChannels;
  var lpCut = 600 + (tonePct / 100) * (9000 - 600);
  var lpA = 1 - Math.exp(-2 * Math.PI * lpCut / sr);
  var size = base * (taps + 1) + 1;
  for (var c = 0; c < nCh; c++) {
    var x = buf.getChannelData(c);
    var dry = new Float32Array(len); dry.set(x);
    var line = new Float32Array(size), lp = 0, wi = 0;
    for (var i = 0; i < len; i++) {
      var wet = 0;
      for (var t = 1; t <= taps; t++) { var ri = wi - base * t; while (ri < 0) ri += size; wet += line[ri] * (1 - (t - 1) / taps); }
      var fbi = wi - base; while (fbi < 0) fbi += size;
      var into = dry[i] + line[fbi] * fb;
      lp += lpA * (into - lp);
      line[wi] = lp;
      x[i] = dry[i] + mix * wet;
      wi++; if (wi >= size) wi = 0;
    }
  }
  fxPeakGuard(buf);
  return buf;
}

/* eNOISER — adds light Lo-Fi hiss / noise texture (control, not removal). */
function fxENoiser(buf, amountPct, tonePct) {
  var amount = amountPct / 100;
  if (amount <= 0) return buf;
  var nCh = buf.numberOfChannels, len = buf.length, sr = buf.sampleRate;
  var lpCut = 1500 + (tonePct / 100) * (12000 - 1500);
  var lpA = 1 - Math.exp(-2 * Math.PI * lpCut / sr);
  var lvl = amount * 0.06, seed = 2246;
  for (var c = 0; c < nCh; c++) {
    var d = buf.getChannelData(c), lp = 0;
    for (var i = 0; i < len; i++) { seed = (seed * 1103515245 + 12345) & 0x7fffffff; var n = seed / 0x7fffffff * 2 - 1; lp += lpA * (n - lp); d[i] = d[i] + lp * lvl; }
  }
  fxPeakGuard(buf);
  return buf;
}

/* BASS BOOST — low-shelf lift for weight/power. */
function fxBassBoost(buf, freq, gainDb, width) {
  if (gainDb === 0) return buf;
  fxBiquad(buf, "lowshelf", freq, gainDb, Math.max(0.2, width));
  var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk);
  return buf;
}
/* PARAMETRIC EQ — one band: Bell / Low shelf / High shelf, with freq/gain/Q. */
function fxParamEq(buf, type, freq, gainDb, q) {
  var t = type === 1 ? "lowshelf" : (type === 2 ? "highshelf" : "peaking");
  if (gainDb === 0 && t === "peaking") return buf;
  fxBiquad(buf, t, freq, gainDb, Math.max(0.2, q));
  var pk = fxPeakVal(buf); if (pk > 0.985) fxGain(buf, 0.985 / pk);
  return buf;
}

/* ============================ effect registry ============================ */
/* Each effect: a display name, a list of fully-adjustable params, and a pure
   DSP function process(buf, values). New effects get added here in step 2. */
var FX_ORDER = ["compressor", "limiter", "peq", "bass", "vocal", "exciter", "lofi", "mellow", "echo", "multitap", "notch", "balance", "enoiser"];
var FX_DEFS = {
  compressor: {
    name: "Compressor",
    params: [
      { key: "thresh",  label: "Threshold", min: -60, max: 0,  def: -24, unit: " dB" },
      { key: "ratio",   label: "Ratio",     min: 1,   max: 20, def: 4,  step: 0.1, unit: ":1" },
      { key: "attack",  label: "Attack",    min: 1,   max: 120, def: 12, unit: " ms" },
      { key: "release", label: "Release",   min: 20,  max: 600, def: 140, unit: " ms" },
      { key: "makeup",  label: "Makeup",    min: 0,   max: 24, def: 0,  step: 0.1, unit: " dB" }
    ],
    process: function (buf, v) { return fxCompress(buf, v.thresh, v.ratio, v.attack, v.release, v.makeup); }
  },
  peq: {
    name: "Parametric EQ",
    params: [
      { key: "loFreq",  label: "Low freq",   min: 30,   max: 500,   def: 120,  log: true, unit: " Hz" },
      { key: "loGain",  label: "Low gain",   min: -18,  max: 18,    def: 0,    step: 0.5, unit: " dB" },
      { key: "midFreq", label: "Mid freq",   min: 200,  max: 6000,  def: 1200, log: true, unit: " Hz" },
      { key: "midGain", label: "Mid gain",   min: -18,  max: 18,    def: 5,    step: 0.5, unit: " dB" },
      { key: "midQ",    label: "Mid width",  min: 0.3,  max: 6,     def: 1,    step: 0.1 },
      { key: "hiFreq",  label: "High freq",  min: 2000, max: 18000, def: 8000, log: true, unit: " Hz" },
      { key: "hiGain",  label: "High gain",  min: -18,  max: 18,    def: 0,    step: 0.5, unit: " dB" }
    ],
    process: function (buf, v) {
      var inR = fxRms(buf);
      if (v.loGain) fxBiquad(buf, "lowshelf", v.loFreq, v.loGain, 0.7);
      if (v.midGain) fxBiquad(buf, "peaking", v.midFreq, v.midGain, Math.max(0.3, v.midQ));
      if (v.hiGain) fxBiquad(buf, "highshelf", v.hiFreq, v.hiGain, 0.7);
      fxFixLevel(buf, inR);   /* match loudness so the change is heard as TONE, not volume */
      return buf;
    }
  },
  bass: {
    name: "Bass Boost",
    params: [
      { key: "freq",  label: "Frequency", min: 40, max: 300, def: 90, unit: " Hz" },
      { key: "gain",  label: "Amount",    min: 0, max: 18, def: 6, step: 0.1, unit: " dB" },
      { key: "width", label: "Width",     min: 0.3, max: 2, def: 0.9, step: 0.05 }
    ],
    process: function (buf, v) { return fxBassBoost(buf, v.freq, v.gain, v.width); }
  },
  echo: {
    name: "Echo",
    params: [
      { key: "time",     label: "Time",     min: 20, max: 1000, def: 260, unit: " ms" },
      { key: "feedback", label: "Feedback", min: 0, max: 95, def: 35, unit: " %" },
      { key: "mix",      label: "Mix",      min: 0, max: 100, def: 35, unit: " %" },
      { key: "tone",     label: "Tone",     min: 0, max: 100, def: 55, unit: " %" }
    ],
    process: function (buf, v) { return fxEcho(buf, v.time, v.feedback, v.mix, v.tone); }
  },
  mellow: {
    name: "Mellow",
    params: [
      { key: "amount", label: "Smoothness", min: 0, max: 100, def: 60, unit: " %" },
      { key: "tame",   label: "High tame",  min: 0, max: 100, def: 50, unit: " %" }
    ],
    process: function (buf, v) { return fxMellow(buf, v.amount, v.tame); }
  },
  limiter: {
    name: "Hard Limiter",
    params: [
      { key: "ceiling", label: "Ceiling", min: -12, max: 0, def: -0.5, step: 0.1, unit: " dB" },
      { key: "drive",   label: "Drive",   min: 0, max: 24, def: 4, step: 0.5, unit: " dB" },
      { key: "release", label: "Release", min: 10, max: 400, def: 80, unit: " ms" }
    ],
    process: function (buf, v) { return fxLimiter(buf, v.ceiling, v.drive, v.release); }
  },
  vocal: {
    name: "Vocal Enhancer",
    params: [
      { key: "amount",   label: "Clarity",  min: 0, max: 100, def: 60, unit: " %" },
      { key: "presence", label: "Presence", min: 0, max: 100, def: 55, unit: " %" },
      { key: "warmth",   label: "Warmth",   min: 0, max: 100, def: 25, unit: " %" }
    ],
    process: function (buf, v) { return fxVocal(buf, v.amount, v.presence, v.warmth); }
  },
  exciter: {
    name: "Exciter",
    params: [
      { key: "amount", label: "Amount",    min: 0, max: 100, def: 45, unit: " %" },
      { key: "freq",   label: "Frequency", min: 1000, max: 12000, def: 4000, log: true, unit: " Hz" },
      { key: "mix",    label: "Mix",       min: 0, max: 100, def: 50, unit: " %" }
    ],
    process: function (buf, v) { return fxExciter(buf, v.amount, v.freq, v.mix); }
  },
  lofi: {
    name: "LoFi",
    params: [
      { key: "crush", label: "Bit crush",   min: 0, max: 100, def: 45, unit: " %" },
      { key: "rate",  label: "Rate reduce", min: 0, max: 100, def: 40, unit: " %" },
      { key: "tone",  label: "Tone",        min: 0, max: 100, def: 50, unit: " %" }
    ],
    process: function (buf, v) { return fxLofi(buf, v.crush, v.rate, v.tone); }
  },
  multitap: {
    name: "Multitap Delay",
    params: [
      { key: "time",     label: "Time",     min: 40, max: 600, def: 180, unit: " ms" },
      { key: "taps",     label: "Taps",     min: 1, max: 8, def: 4 },
      { key: "feedback", label: "Feedback", min: 0, max: 90, def: 25, unit: " %" },
      { key: "mix",      label: "Mix",      min: 0, max: 100, def: 40, unit: " %" },
      { key: "tone",     label: "Tone",     min: 0, max: 100, def: 55, unit: " %" }
    ],
    process: function (buf, v) { return fxMultitap(buf, v.time, v.taps, v.feedback, v.mix, v.tone); }
  },
  notch: {
    name: "Notch Filter",
    params: [
      { key: "freq",  label: "Frequency", min: 50, max: 16000, def: 1000, log: true, unit: " Hz" },
      { key: "depth", label: "Depth",     min: 0, max: 100, def: 80, unit: " %" },
      { key: "q",     label: "Width",     min: 1, max: 30, def: 12, step: 0.5 }
    ],
    process: function (buf, v) { return fxNotch(buf, v.freq, v.depth, v.q); }
  },
  balance: {
    name: "Balance",
    params: [
      { key: "bal", label: "Balance  L / R", min: -100, max: 100, def: 0, unit: "" }
    ],
    process: function (buf, v) { return fxBalance(buf, v.bal); }
  },
  enoiser: {
    name: "eNoiser",
    params: [
      { key: "amount", label: "Amount", min: 0, max: 100, def: 30, unit: " %" },
      { key: "tone",   label: "Tone",   min: 0, max: 100, def: 50, unit: " %" }
    ],
    process: function (buf, v) { return fxENoiser(buf, v.amount, v.tone); }
  }
};

/* live list of effect instances the user has added (processed in this order) */
var fxChain = [];

var FX_SVG_CHEVRON = '<svg viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"/></svg>';
var FX_SVG_X = '<svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg>';

function fxNum(x) { return typeof x === "number" && !isNaN(x); }
function fxFmt(pdef, v) {
  var u = pdef.unit || "";
  var dec = pdef.step && pdef.step < 1 ? (pdef.step <= 0.05 ? 2 : 1) : 0;
  var p = Math.pow(10, dec);
  return (Math.round(v * p) / p) + u;
}
function fxLogPos(v, lo, hi) { return Math.round(1000 * Math.log(v / lo) / Math.log(hi / lo)); }
function fxLogVal(pos, lo, hi) { return lo * Math.pow(hi / lo, pos / 1000); }

function fxChainChanged() { fxStopPreview(); }

/* apply the whole user chain to a buffer (in render order) */
function fxRenderChain(buf) {
  for (var i = 0; i < fxChain.length; i++) {
    var inst = fxChain[i]; if (!inst.on) continue;
    var def = FX_DEFS[inst.defId]; if (!def) continue;
    var r = def.process(buf, inst.values); if (r) buf = r;
  }
  return buf;
}

function fxBuildParam(inst, pdef) {
  var wrap = document.createElement("div"); wrap.className = "fx-param";
  var head = document.createElement("div"); head.className = "fx-param-head";
  var lab = document.createElement("span"); lab.className = "fx-param-label"; lab.textContent = pdef.label;
  var val = document.createElement("span"); val.className = "fx-param-val";
  head.appendChild(lab); head.appendChild(val); wrap.appendChild(head);

  if (pdef.type === "select") {
    var sel = document.createElement("select"); sel.className = "fx-select";
    for (var i = 0; i < pdef.options.length; i++) {
      var o = document.createElement("option"); o.value = i; o.textContent = pdef.options[i]; sel.appendChild(o);
    }
    sel.value = inst.values[pdef.key];
    val.textContent = pdef.options[inst.values[pdef.key]];
    sel.addEventListener("change", function () {
      inst.values[pdef.key] = parseInt(sel.value, 10) || 0;
      val.textContent = pdef.options[inst.values[pdef.key]];
      fxChainChanged();
    });
    wrap.appendChild(sel);
  } else {
    var input = document.createElement("input"); input.type = "range"; input.className = "fx-slider";
    var isLog = !!pdef.log;
    if (isLog) { input.min = 0; input.max = 1000; input.step = 1; input.value = fxLogPos(inst.values[pdef.key], pdef.min, pdef.max); }
    else { input.min = pdef.min; input.max = pdef.max; input.step = pdef.step || 1; input.value = inst.values[pdef.key]; }
    val.textContent = fxFmt(pdef, inst.values[pdef.key]);
    input.addEventListener("input", function () {
      var v = isLog ? fxLogVal(parseFloat(input.value), pdef.min, pdef.max) : parseFloat(input.value);
      if (!fxNum(v)) v = pdef.def;
      inst.values[pdef.key] = v; val.textContent = fxFmt(pdef, v); fxChainChanged();
    });
    wrap.appendChild(input);
  }
  return wrap;
}

function fxBuildCard(inst) {
  var def = FX_DEFS[inst.defId];
  var card = document.createElement("div");
  card.className = "fx-card fx-dyn" + (inst.on ? "" : " off") + (inst.collapsed ? " collapsed" : "");
  card._inst = inst;

  var head = document.createElement("div"); head.className = "fx-card-head";
  var sw = document.createElement("label"); sw.className = "fx-switch";
  var swi = document.createElement("input"); swi.type = "checkbox"; swi.checked = inst.on;
  var knob = document.createElement("span"); knob.className = "fx-knob";
  sw.appendChild(swi); sw.appendChild(knob);
  swi.addEventListener("change", function () { inst.on = swi.checked; card.classList.toggle("off", !inst.on); fxChainChanged(); });

  var title = document.createElement("span"); title.className = "fx-title"; title.textContent = def.name;
  var spacer = document.createElement("span"); spacer.className = "fx-spacer";
  var col = document.createElement("button"); col.className = "fx-iconbtn fx-collapse"; col.type = "button"; col.innerHTML = FX_SVG_CHEVRON; col.title = "Collapse / expand";
  var rm = document.createElement("button"); rm.className = "fx-iconbtn fx-remove"; rm.type = "button"; rm.innerHTML = FX_SVG_X; rm.title = "Remove effect";

  col.addEventListener("click", function (e) { e.stopPropagation(); inst.collapsed = !inst.collapsed; card.classList.toggle("collapsed", inst.collapsed); });
  rm.addEventListener("click", function (e) { e.stopPropagation(); fxRemoveEffect(inst, card); });

  head.appendChild(sw); head.appendChild(title); head.appendChild(spacer); head.appendChild(col); head.appendChild(rm);
  head.addEventListener("click", function (e) {
    if (sw.contains(e.target) || col.contains(e.target) || rm.contains(e.target)) return;
    inst.collapsed = !inst.collapsed; card.classList.toggle("collapsed", inst.collapsed);
  });
  card.appendChild(head);

  var body = document.createElement("div"); body.className = "fx-body";
  for (var i = 0; i < def.params.length; i++) body.appendChild(fxBuildParam(inst, def.params[i]));
  card.appendChild(body);
  return card;
}

function fxAddEffect(defId) {
  var def = FX_DEFS[defId]; if (!def) return;
  var inst = { defId: defId, on: true, collapsed: false, values: {} };
  for (var i = 0; i < def.params.length; i++) { var p = def.params[i]; inst.values[p.key] = p.def; }
  fxChain.push(inst);
  var card = fxBuildCard(inst); inst._card = card;
  if (elFxChain) elFxChain.appendChild(card);
  fxAddClose();
  fxChainChanged();
}

function fxRemoveEffect(inst, card) {
  var idx = fxChain.indexOf(inst); if (idx >= 0) fxChain.splice(idx, 1);
  if (card && card.parentNode) card.parentNode.removeChild(card);
  fxChainChanged();
}

function fxAddBuildMenu() {
  if (!elFxAddMenu) return;
  elFxAddMenu.innerHTML = "";
  for (var i = 0; i < FX_ORDER.length; i++) {
    (function (k) {
      var it = document.createElement("div"); it.className = "fx-add-item"; it.textContent = FX_DEFS[k].name;
      it.addEventListener("click", function () { fxAddEffect(k); });
      elFxAddMenu.appendChild(it);
    })(FX_ORDER[i]);
  }
}
function fxAddOpen() { if (!elFxAddMenu) return; fxAddBuildMenu(); elFxAddMenu.classList.add("open"); if (elFxAddBtn) elFxAddBtn.classList.add("open"); }
function fxAddClose() { if (elFxAddMenu) elFxAddMenu.classList.remove("open"); if (elFxAddBtn) elFxAddBtn.classList.remove("open"); }
function fxAddToggle() { if (elFxAddMenu && elFxAddMenu.classList.contains("open")) fxAddClose(); else fxAddOpen(); }

/* effect-card scale (mirrors the Library size slider) */
function fxApplyScale(v) {
  var z = 0.7 + (v / 100) * 0.55;   /* 0.70 .. 1.25 */
  document.documentElement.style.setProperty("--fx-zoom", z.toFixed(3));
}

/* ===================== Instruction / help panel ===================== */
var FX_HELP_ORDER = ["speed", "repeat", "softness", "compressor", "limiter", "peq", "bass", "vocal", "exciter", "lofi", "mellow", "echo", "multitap", "notch", "balance", "enoiser"];
var FX_HELP = {
  speed:      { name: "Speed", text: "Changes how fast the sound plays. Move left to slow down, right to speed up. Turn on \"Keep pitch\" to change the speed without making the sound higher or lower." },
  repeat:     { name: "Repeat", text: "Plays the sound several times in a row, one after another. The slider sets how many times it repeats." },
  softness:   { name: "Softness", text: "Gently muffles the sound to make it softer and warmer, rounding off the sharp top. Higher value = softer and more muffled." },
  compressor: { name: "Compressor", text: "Evens out the volume \u2014 calms the loud parts and lifts the quiet parts so the sound is steady. Threshold = where it starts working, Ratio = how strongly it squeezes, Attack/Release = how fast it reacts, Makeup = adds the volume back." },
  limiter:    { name: "Hard Limiter", text: "A safety wall for volume. It pushes the sound louder (Drive) but never lets the peaks pass the Ceiling, so nothing distorts or hits the ears too hard." },
  peq:        { name: "Parametric EQ", text: "Shapes the tone by boosting or cutting three areas \u2014 Low, Mid and High. Add body, bring out the middle (an \"old radio\" sound), or tame harshness. Each area has its own frequency and amount; the Mid also has a width." },
  bass:       { name: "Bass Boost", text: "Adds weight and power to the low end, making the sound fuller and bigger. Frequency = how high the boost reaches, Amount = how strong, Width = how broad." },
  vocal:      { name: "Vocal Enhancer", text: "Makes a voice clearer and easier to understand \u2014 removes low rumble and muddiness, lifts the presence, and gently evens the level. Warmth adds a little low-end body." },
  exciter:    { name: "Exciter", text: "Adds sparkle and air by creating bright harmonics on top. Great for making a dull sound crisp and lively. Amount = strength, Frequency = where the sparkle starts, Mix = how much is blended in." },
  lofi:       { name: "LoFi", text: "Gives a vintage, low-quality character \u2014 like an old phone, radio or tape. Bit crush and Rate reduce add the \"digital grit\"; Tone narrows the sound into that retro band." },
  mellow:     { name: "Mellow", text: "Softens a hard, sharp sound into a gentle \"pop\" by rounding the attack and taming the harsh highs, while keeping it loud. Smoothness rounds the hit, High tame removes the sharp top." },
  echo:       { name: "Echo", text: "Repeats the sound as a fading echo. Time = the gap between repeats, Feedback = how many repeats and how long they last, Mix = how loud the echo is, Tone = how bright or dull the repeats are." },
  multitap:   { name: "Multitap Delay", text: "A richer echo with several repeats at once, creating a rhythmic or spacious tail. Time = base gap, Taps = number of repeats, Feedback = the lasting trail, Mix = the level, Tone = the brightness." },
  notch:      { name: "Notch Filter", text: "Removes one narrow annoying frequency \u2014 a hum, whistle or ring \u2014 while leaving the rest of the sound intact. Frequency = the exact spot, Depth = how much to remove, Width = how narrow." },
  balance:    { name: "Balance", text: "Moves the sound left or right in the stereo field. Center is normal; slide toward L or R to pan. (Only affects stereo clips.)" },
  enoiser:    { name: "eNoiser", text: "Adds a light layer of hiss or noise on purpose \u2014 useful for Lo-Fi texture and warmth. Amount = the noise level, Tone = its color (darker or brighter)." }
};
function fxBuildHelp() {
  if (!elFxHelpList) return;
  elFxHelpList.innerHTML = "";
  for (var i = 0; i < FX_HELP_ORDER.length; i++) {
    (function (k) {
      var item = FX_HELP[k]; if (!item) return;
      var row = document.createElement("div"); row.className = "fx-help-item";
      var head = document.createElement("button"); head.type = "button"; head.className = "fx-help-head";
      var nm = document.createElement("span"); nm.className = "fx-help-name"; nm.textContent = item.name;
      var ar = document.createElement("span"); ar.className = "fx-help-arrow"; ar.innerHTML = FX_SVG_CHEVRON;
      head.appendChild(nm); head.appendChild(ar);
      var body = document.createElement("div"); body.className = "fx-help-text"; body.textContent = item.text;
      head.addEventListener("click", function () { row.classList.toggle("open"); });
      row.appendChild(head); row.appendChild(body);
      elFxHelpList.appendChild(row);
    })(FX_HELP_ORDER[i]);
  }
}
function fxHelpOpen() { fxBuildHelp(); if (elFxHelp) elFxHelp.classList.add("open"); }
function fxHelpClose() { if (elFxHelp) elFxHelp.classList.remove("open"); }
function fxHelpToggle() { if (elFxHelp && elFxHelp.classList.contains("open")) fxHelpClose(); else fxHelpOpen(); }

function fxGain(buf, g) {
  if (g === 1) return buf;
  for (var c = 0; c < buf.numberOfChannels; c++) { var d = buf.getChannelData(c); for (var i = 0; i < d.length; i++) d[i] *= g; }
  return buf;
}
function fxRepeat(buf, n) {
  if (n <= 1) return buf;
  var nCh = buf.numberOfChannels, len = buf.length, sr = buf.sampleRate;
  /* micro-fade the copy edges (3 ms in / 8 ms out) so the junctions never click */
  var fi = Math.min(Math.round(0.003 * sr), len >> 2);
  var fo = Math.min(Math.round(0.008 * sr), len >> 2);
  var out = fxMakeBuf(nCh, len * n, sr);
  for (var c = 0; c < nCh; c++) {
    var src = new Float32Array(len); src.set(buf.getChannelData(c));
    for (var i = 0; i < fi; i++) src[i] *= i / fi;
    for (var k = 0; k < fo; k++) src[len - 1 - k] *= k / fo;
    var dst = out.getChannelData(c);
    for (var r = 0; r < n; r++) dst.set(src, r * len);
  }
  return out;
}
function fxPadTo(buf, target) {
  if (buf.length >= target) return buf;
  var out = fxMakeBuf(buf.numberOfChannels, target, buf.sampleRate);
  for (var c = 0; c < buf.numberOfChannels; c++) out.getChannelData(c).set(buf.getChannelData(c), 0);
  return out;
}
/* tiny fades at the very edges of the final result — kills boundary clicks
   without audibly changing the sound (2 ms in / 6 ms out) */
function fxEdgeSmooth(buf, inMs, outMs) {
  var sr = buf.sampleRate, len = buf.length;
  var nIn = Math.min(len >> 2, Math.round((inMs || 2) / 1000 * sr));
  var nOut = Math.min(len >> 2, Math.round((outMs || 6) / 1000 * sr));
  for (var c = 0; c < buf.numberOfChannels; c++) {
    var d = buf.getChannelData(c);
    for (var i = 0; i < nIn; i++) d[i] *= i / nIn;
    for (var k = 0; k < nOut; k++) d[len - 1 - k] *= k / nOut;
  }
  return buf;
}
function fxToAudioBuffer(buf) {
  var ctx = audioCtx(); if (!ctx) return null;
  var ab = ctx.createBuffer(buf.numberOfChannels, buf.length, buf.sampleRate);
  for (var c = 0; c < buf.numberOfChannels; c++) {
    if (ab.copyToChannel) { try { ab.copyToChannel(buf.getChannelData(c), c); continue; } catch (e) {} }
    ab.getChannelData(c).set(buf.getChannelData(c));
  }
  return ab;
}

/* ---- parameter mappings ---- */
function fxSpeedFactor() { var s = fx.speedS; return s < 50 ? (0.25 + (s / 50) * 0.75) : (1.0 + ((s - 50) / 50) * 3.0); }
function fxSpeedActive() { return Math.abs(fxSpeedFactor() - 1) > 0.001; }

/* ---- the full render (synchronous). Order: speed -> softness -> chain -> repeat ---- */
function fxRender(forApply) {
  if (!fx.src || !fx.info) return null;
  var seg = fxSlice(fx.src, fx.info.in, fx.info.out);
  var segLen = seg.length, buf = seg, f = fxSpeedFactor();
  if (fx.speedOn && Math.abs(f - 1) > 0.001) {
    /* anti-alias: when speeding up without pitch-keep, remove the frequencies
       that would fold back as harsh metallic noise after resampling */
    if (!fx.keepPitch && f > 1.05) {
      var cut = 0.45 * seg.sampleRate / f;
      fxBiquad(seg, "lowpass", cut, 0, 0.6);
      fxBiquad(seg, "lowpass", cut, 0, 0.6);
    }
    buf = fx.keepPitch ? fxTimeStretch(seg, 1 / f) : fxResample(seg, f);
  }
  if (fx.mutingOn && fx.mutingS > 0) fxMuting(buf, fx.mutingS / 100);
  buf = fxRenderChain(buf);
  if (fx.repeatOn && fx.repeatN > 1) buf = fxRepeat(buf, fx.repeatN);
  fxEdgeSmooth(buf, 2, 6);
  if (forApply && buf.length < segLen) buf = fxPadTo(buf, segLen);
  return buf;
}

/* ---- preview (play the processed result) ---- */
var fxPrev = { node: null, raf: null, start: 0, dur: 0, playing: false, offset: 0 };
function fxSetProg(fr) { if (fr < 0) fr = 0; if (fr > 1) fr = 1; var w = elFxCanvas.clientWidth || 1; if (elFxProg) elFxProg.style.left = (9 + fr * w) + "px"; }
function fxSetPlayIcon(on) { if (!elFxPreviewBtn) return; elFxPreviewBtn.innerHTML = on ? SVG_PAUSE : SVG_PLAY; elFxPreviewBtn.classList.add("play-state"); }
function fxStopPreview() {
  if (fxPrev.raf) { cancelAnimationFrame(fxPrev.raf); fxPrev.raf = null; }
  if (fxPrev.node) { try { fxPrev.node.onended = null; fxPrev.node.stop(0); } catch (e) {} try { fxPrev.node.disconnect(); } catch (e) {} fxPrev.node = null; }
  fxPrev.playing = false; fxSetPlayIcon(false);
}
function fxTick() {
  if (!fxPrev.playing) return;
  var ctx = audioCtx(); var el = ctx.currentTime - fxPrev.start, fr = fxPrev.dur > 0 ? el / fxPrev.dur : 0;
  fxSetProg(fr); fxPrev.raf = requestAnimationFrame(fxTick);
}
function fxStartPreview() {
  fxStopPreview();
  if (!fx.src) { fxStatus("Load a clip first", true); return; }
  var buf = fxRender(false); if (!buf) return;
  var ctx = audioCtx(); if (!ctx) { fxStatus("Audio engine off", true); return; }
  resumeCtx();
  var ab = fxToAudioBuffer(buf); if (!ab) return;
  var node = ctx.createBufferSource(); node.buffer = ab; node.connect(ctx.destination);
  var offsetSec = (fxPrev.offset || 0) * ab.duration;
  if (offsetSec >= ab.duration - 0.02) offsetSec = 0;        /* if parked at the end, play from start */
  fxPrev.node = node; fxPrev.dur = ab.duration; fxPrev.start = ctx.currentTime - offsetSec; fxPrev.playing = true;
  node.onended = function () { if (fxPrev.node === node) { fxStopPreview(); fxPrev.offset = 0; fxSetProg(0); } };
  try { node.start(0, offsetSec); } catch (e) { return; }
  fxSetPlayIcon(true); fxTick();
}
function fxTogglePreview() { if (fxPrev.playing) fxStopPreview(); else fxStartPreview(); }

/* ---- scrub: click / drag on the waveform to move the play position ---- */
var fxScrub = { active: false, wasPlaying: false };
function fxFracFromEvent(e) {
  if (!elFxCanvas) return 0;
  var rect = elFxCanvas.getBoundingClientRect();
  var x = (e.clientX != null ? e.clientX : 0) - rect.left;
  var fr = rect.width > 0 ? x / rect.width : 0;
  if (fr < 0) fr = 0; if (fr > 1) fr = 1;
  return fr;
}
function fxScrubStart(e) {
  if (!fx.src) return;
  fxScrub.active = true; fxScrub.wasPlaying = fxPrev.playing;
  if (fxPrev.playing) fxStopPreview();
  var fr = fxFracFromEvent(e); fxPrev.offset = fr; fxSetProg(fr);
}
function fxScrubMove(e) { if (!fxScrub.active) return; var fr = fxFracFromEvent(e); fxPrev.offset = fr; fxSetProg(fr); }
function fxScrubEnd() { if (!fxScrub.active) return; fxScrub.active = false; if (fxScrub.wasPlaying) fxStartPreview(); }

/* ---- apply (render -> WAV -> replace the clip in Premiere) ---- */
function fxOutDir() {
  try {
    var dir = pathMod.join(os.homedir(), ".amanow_sfx", "effects");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    return dir;
  } catch (e) { return null; }
}
function fxStatus(msg, err) {
  if (!elFxStatus) return;
  elFxStatus.textContent = msg || "";
  elFxStatus.style.color = err ? "#f87171" : "var(--txt-dim)";
}
function fxApply() {
  if (!fx.src || !fx.info) { fxStatus("Load a clip first", true); return; }
  if (!fs || !pathMod || !os) { fxStatus("File access is off", true); return; }
  var buf = fxRender(true); if (!buf) { fxStatus("Nothing to render", true); return; }
  var dir = fxOutDir(); if (!dir) { fxStatus("Cannot write temp file", true); return; }
  var base = (fx.info.name || "clip").replace(/\.[^.]+$/, "");
  var out = pathMod.join(dir, sanitizeName(base) + "_fx_" + Date.now() + ".wav");
  elFxApplyBtn.disabled = true; fxStatus("Rendering\u2026");
  try {
    fs.writeFile(out, audioBufToWav(buf), function (err) {
      if (err) { elFxApplyBtn.disabled = false; fxStatus("Write failed", true); return; }
      fxStatus("Applying to timeline\u2026");
      var esc = out.replace(/\\/g, "\\\\").replace(/'/g, "\\'");
      cs.evalScript("am_replaceSelected('" + esc + "')", function (res) {
        elFxApplyBtn.disabled = false;
        res = String(res);
        if (res.indexOf("OK") === 0) fxStatus("Done \u2014 clip replaced \u2713");
        else fxStatus(res.replace(/^ERR:\s*/, ""), true);
      });
    });
  } catch (e) { elFxApplyBtn.disabled = false; fxStatus("Error: " + e, true); }
}

/* ---- load the selected clip from the timeline ---- */
function fxShowEmpty(msg) {
  fx.src = null; fx.info = null; fx.peaks = null;
  if (elFxClip) elFxClip.style.display = "none";
  if (elFxEffects) elFxEffects.style.display = "none";
  if (elFxToolbar) elFxToolbar.style.display = "none";
  if (elFxEmpty) { elFxEmpty.style.display = ""; elFxEmpty.innerHTML = msg || "Select an audio clip on your timeline, then press <b>Load</b>."; }
}
function fxShowClip(info, seg) {
  if (elFxEmpty) elFxEmpty.style.display = "none";
  if (elFxClip) elFxClip.style.display = "";
  if (elFxToolbar) elFxToolbar.style.display = "";
  if (elFxEffects) elFxEffects.style.display = "";
  if (elFxClipName) { elFxClipName.textContent = info.name || "clip"; elFxClipName.title = info.name || ""; }
  if (elFxDur) elFxDur.textContent = fmtDur(seg.length / seg.sampleRate);
  fxDraw();
  fxSetProg(0);
  fxStatus("");
}
function fxDraw() {
  if (!fx.peaks || !elFxCanvas) return;
  drawWave(elFxCanvas, fx.peaks, "#cdd3db");
}
function fxLoad() {
  fxStopPreview();
  if (elFxClipName) elFxClipName.textContent = "Loading\u2026";
  cs.evalScript("am_getSelectedAudio()", function (res) {
    res = String(res);
    if (res.indexOf("{") !== 0) { fxShowEmpty(res.replace(/^ERR:\s*/, "")); return; }
    var info; try { info = JSON.parse(res); } catch (e) { fxShowEmpty("Could not read the selection"); return; }
    if (!fs) { fxShowEmpty("File access is off"); return; }
    fs.readFile(info.path, function (err, b) {
      if (err) { fxShowEmpty("Cannot read the source file"); return; }
      var ab = b.buffer.slice(b.byteOffset, b.byteOffset + b.byteLength);
      var ctx = audioCtx(); if (!ctx) { fxShowEmpty("Audio engine is off"); return; }
      ctx.decodeAudioData(ab, function (audioBuf) {
        fx.src = audioBuf; fx.info = info;
        var seg = fxSlice(audioBuf, info.in, info.out);
        fx.peaks = computePeaks(seg);
        fxShowClip(info, seg);
      }, function () { fxShowEmpty("This audio format can't be decoded here"); });
    });
  });
}

/* ---- UI sync ---- */
function fxUpdateLabels() {
  if (elFxSpeedVal) elFxSpeedVal.innerHTML = fxSpeedFactor().toFixed(2) + "&times;";
  if (elFxCardSpeed) elFxCardSpeed.classList.toggle("off", !fx.speedOn);
  if (elFxKeepPitch) elFxKeepPitch.disabled = !fx.speedOn;
  if (elFxRepeatVal) elFxRepeatVal.innerHTML = fx.repeatN + "&times;";
  if (elFxMutingVal) elFxMutingVal.textContent = Math.round(fx.mutingS) + "%";
  var repCard = elFxRepeat ? elFxRepeat.parentNode : null;
  if (repCard) repCard.classList.toggle("off", !fx.repeatOn);
  var mutCard = elFxMuting ? elFxMuting.parentNode : null;
  if (mutCard) mutCard.classList.toggle("off", !fx.mutingOn);
}

/* ---- tab switching ---- */
function switchTab(which) {
  var fxOn = (which === "effect");
  fxActive = fxOn;
  if (elTabLibrary) elTabLibrary.classList.toggle("active", !fxOn);
  if (elTabEffect) elTabEffect.classList.toggle("active", fxOn);
  if (elLibView) elLibView.classList.toggle("active", !fxOn);
  if (elFxView) elFxView.classList.toggle("active", fxOn);
  if (fxOn) {
    if (!fx.src) fxLoad();          /* auto-grab the current selection */
    else fxDraw();
  } else {
    fxStopPreview();
    vgRelayoutSoon();
    redrawVisibleSoon();            /* repaint library waveforms after being hidden */
  }
}

function syncFadeLabels() {
  if (elFadeInVal) elFadeInVal.textContent = state.fadeIn.toFixed(1) + "s";
  if (elFadeOutVal) elFadeOutVal.textContent = state.fadeOut.toFixed(1) + "s";
}

/* ===================== LICENSE (3-day local trial + same-server key activation) ===================== */
function am_lic_call(expr){ try{ cs.evalScript(expr, function(){}); }catch(e){} }
function am_lic_callR(expr, cb){ try{ cs.evalScript(expr, function(r){ cb(r); }); }catch(e){ cb(""); } }
function am_sha256(asciiOrBytes){
  function utf8(s){var b=[];for(var i=0;i<s.length;i++){var c=s.charCodeAt(i);if(c<128)b.push(c);else if(c<2048){b.push(192|(c>>6));b.push(128|(c&63));}else{b.push(224|(c>>12));b.push(128|((c>>6)&63));b.push(128|(c&63));}}return b;}
  var K=[0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2];
  var bytes=(typeof asciiOrBytes==="string")?utf8(asciiOrBytes):asciiOrBytes;
  var l=bytes.length,w1=bytes.slice();w1.push(0x80);while(w1.length%64!=56)w1.push(0);
  var bl=l*8;for(var i=7;i>=0;i--){w1.push((bl/Math.pow(2,i*8))&255);}
  var H=[0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  function rotr(x,n){return (x>>>n)|(x<<(32-n));}
  for(var off=0;off<w1.length;off+=64){
    var w=[];for(var t=0;t<16;t++){w[t]=(w1[off+t*4]<<24)|(w1[off+t*4+1]<<16)|(w1[off+t*4+2]<<8)|(w1[off+t*4+3]);}
    for(var t=16;t<64;t++){var s0=rotr(w[t-15],7)^rotr(w[t-15],18)^(w[t-15]>>>3);var s1=rotr(w[t-2],17)^rotr(w[t-2],19)^(w[t-2]>>>10);w[t]=(w[t-16]+s0+w[t-7]+s1)|0;}
    var a=H[0],b=H[1],c=H[2],d=H[3],e=H[4],f=H[5],g=H[6],h=H[7];
    for(var t=0;t<64;t++){var S1=rotr(e,6)^rotr(e,11)^rotr(e,25);var ch=(e&f)^((~e)&g);var t1=(h+S1+ch+K[t]+w[t])|0;var S0=rotr(a,2)^rotr(a,13)^rotr(a,22);var maj=(a&b)^(a&c)^(b&c);var t2=(S0+maj)|0;h=g;g=f;f=e;e=(d+t1)|0;d=c;c=b;b=a;a=(t1+t2)|0;}
    H[0]=(H[0]+a)|0;H[1]=(H[1]+b)|0;H[2]=(H[2]+c)|0;H[3]=(H[3]+d)|0;H[4]=(H[4]+e)|0;H[5]=(H[5]+f)|0;H[6]=(H[6]+g)|0;H[7]=(H[7]+h)|0;
  }
  var out="";for(var i=0;i<8;i++){var hx=(H[i]>>>0).toString(16);while(hx.length<8)hx="0"+hx;out+=hx;}return out;
}
/* Product-salted device code.
   The raw machine id is the same in both plugins (it is the real hardware UUID),
   so hashing it plainly gave AmanowTools and AmanowSFX the SAME code and one key
   unlocked both. Mixing a product tag into the hash makes the SFX code completely
   different on the very same computer, while the format (16 hex chars) stays the
   same -> the key server and the KeyGen keep working with no changes. */
var AM_DEV_SALT = "AMANOW-SFX-PREMIERE-v1|";
function am_devCode(raw){ return am_sha256(AM_DEV_SALT+String(raw)).toUpperCase().substr(0,16); }
function am_fmtDev(d){ return d.substr(0,4)+"-"+d.substr(4,4)+"-"+d.substr(8,4)+"-"+d.substr(12,4); }
function am_normKey(k){ return String(k).toUpperCase().replace(/[^A-Z0-9-]/g,""); }
function am_storedKey(){ try{ return localStorage.getItem("amanowsfx_license")||""; }catch(e){ return ""; } }
function am_saveKey(k){ try{ localStorage.setItem("amanowsfx_license", k); }catch(e){} }
function am_lsTrialGet(){ try{ return localStorage.getItem("amanowsfx_trial")||""; }catch(e){ return ""; } }
function am_lsTrialSet(v){ try{ localStorage.setItem("amanowsfx_trial", v); }catch(e){} }
function am_srvCacheGet(){ try{ return JSON.parse(localStorage.getItem("amanowsfx_srv")||"null"); }catch(e){ return null; } }
function am_srvCacheSet(o){ try{ localStorage.setItem("amanowsfx_srv", JSON.stringify(o)); }catch(e){} }

var AM_TRIAL_DAYS = 3;
var AM_SERVER = "https://amanowtools.aamanow1509.workers.dev";   /* same server as AmanowTools */
var AM_PRODUCT = "sfx";
var AM_DEV = "";
var am_activated = false;
var am_locked = false;

function am_post(path, body, cb){
  if(!AM_SERVER){ cb(null); return; }
  try{
    var x=new XMLHttpRequest();
    x.open("POST", AM_SERVER.replace(/\/+$/,"")+path, true);
    x.setRequestHeader("Content-Type","application/json");
    x.timeout=8000;
    x.onreadystatechange=function(){ if(x.readyState===4){ var r=null; try{ r=JSON.parse(x.responseText); }catch(e){ r=null; } cb(r); } };
    x.ontimeout=function(){ cb(null); };
    x.onerror=function(){ cb(null); };
    x.send(JSON.stringify(body));
  }catch(e){ cb(null); }
}
function am_unlock(){ var g=document.getElementById("licenseGate"); if(g) g.classList.remove("show"); }
function am_lock(){ am_locked=true; var g=document.getElementById("licenseGate"); if(g) g.classList.add("show"); var lt=document.getElementById("licLater"); if(lt) lt.style.display="none"; }
function am_hasAccess(){ if(am_activated) return true; return !am_locked; }
function am_openGate(){
  var g=document.getElementById("licenseGate"); if(g) g.classList.add("show");
  var lt=document.getElementById("licLater"); if(lt) lt.style.display=am_hasAccess()?"block":"none";
  var sub=document.getElementById("licSub");
  if(sub){ sub.textContent=am_activated ? "This copy is already activated." : "Have a key? Enter it below to activate the full version now \u2014 or tap Later to keep using your trial."; }
  var m=document.getElementById("licMsg"); if(m && !am_activated){ m.className="lic-msg"; m.textContent=""; }
}
function am_trialPill(){
  var p=document.getElementById("amTrialPill");
  if(!p){
    p=document.createElement("div"); p.id="amTrialPill"; p.title="Click to enter your key";
    p.addEventListener("click", function(){ am_openGate(); });
    document.body.appendChild(p);
  }
  return p;
}
function am_trialBadge(daysLeft){
  var p=am_trialPill();
  if(daysLeft<=0){ p.classList.remove("show"); return; }   /* activated (-1) or expired (0) -> hide pill */
  p.textContent="Trial \u00b7 "+daysLeft+(daysLeft===1?" day left":" days left");
  p.classList.add("show");
}
function am_applyTrial(){
  am_lic_callR('amTrialStamp()', function(ts){
    var now=Date.now();
    var fI=0,fL=0; if(ts&&String(ts).indexOf("|")>=0){ var p=String(ts).split("|"); fI=parseFloat(p[0])||0; fL=parseFloat(p[1])||0; }
    var ls=am_lsTrialGet(), lI=0,lL=0; if(ls&&ls.indexOf("|")>=0){ var q=ls.split("|"); lI=parseFloat(q[0])||0; lL=parseFloat(q[1])||0; }
    var install=Math.min(fI||now, lI||now);
    var last=Math.max(fL||now, lL||now, now);
    am_lsTrialSet(install+"|"+last);
    am_lic_call('amTrialSet('+install+','+last+')');
    var used=(last-install)/86400000;
    var left=Math.ceil(AM_TRIAL_DAYS-used);
    if(used<AM_TRIAL_DAYS){ am_locked=false; am_unlock(); am_trialBadge(left); }
    else {
      var sub=document.getElementById("licSub");
      if(sub) sub.textContent="Your "+AM_TRIAL_DAYS+"-day free trial has ended. Send your device code to the seller to get your personal key, then paste it below.";
      am_lock(); am_trialBadge(0);
    }
  });
}
function am_doActivate(){
  var inp=document.getElementById("licKey"), msg=document.getElementById("licMsg");
  if(!msg) return;
  var k=inp?am_normKey(inp.value):"";
  if(!AM_DEV){ msg.className="lic-msg err"; msg.textContent="Device code not ready yet \u2014 wait a second and retry."; return; }
  if(!k){ msg.className="lic-msg err"; msg.textContent="Enter your key."; return; }
  if(!AM_SERVER){ msg.className="lic-msg err"; msg.textContent="Activation server is not configured."; return; }
  msg.className="lic-msg"; msg.textContent="Checking\u2026";
  am_post("/activate", { device:AM_DEV, key:k, product:AM_PRODUCT }, function(res){
    if(!res){ msg.className="lic-msg err"; msg.textContent="No connection. Go online and try again."; return; }
    if(res.status==="licensed"){ am_saveKey(k); am_activated=true; am_srvCacheSet({status:"licensed",ts:Date.now()}); am_trialBadge(-1); msg.className="lic-msg ok"; msg.textContent="Activated. Welcome!"; setTimeout(am_unlock,600); return; }
    if(res.error==="bad_key"){ msg.className="lic-msg err"; msg.textContent="Invalid key for this device."; return; }
    msg.className="lic-msg err"; msg.textContent="Activation failed. Try again.";
  });
}
function am_initLicense(){
  am_lic_callR('amDeviceRaw()', function(raw){
    raw=(raw&&String(raw).length)?String(raw):"UNKNOWN-DEVICE";
    AM_DEV=am_devCode(raw);
    var dc=document.getElementById("licDevice"); if(dc) dc.textContent=am_fmtDev(AM_DEV);
    var stored=am_storedKey();
    if(stored && AM_SERVER){
      am_post("/activate", { device:AM_DEV, key:am_normKey(stored), product:AM_PRODUCT }, function(res){
        if(res && res.status==="licensed"){ am_activated=true; am_srvCacheSet({status:"licensed",ts:Date.now()}); am_unlock(); am_trialBadge(-1); return; }
        if(!res){ var c=am_srvCacheGet(); if(c && c.status==="licensed"){ am_activated=true; am_unlock(); am_trialBadge(-1); return; } }
        am_applyTrial();
      });
    } else {
      am_applyTrial();
    }
  });
}
function initLicense(){
  var btn=document.getElementById("licActivate"), inp=document.getElementById("licKey");
  var cp=document.getElementById("licCopy"), later=document.getElementById("licLater");
  if(cp) cp.addEventListener("click", function(){ try{ var t=document.getElementById("licDevice").textContent; if(navigator.clipboard) navigator.clipboard.writeText(t); }catch(e){} });
  if(btn) btn.addEventListener("click", am_doActivate);
  if(inp) inp.addEventListener("keydown", function(e){ if(e.key==="Enter"||e.keyCode===13) am_doActivate(); });
  if(later) later.addEventListener("click", function(){ if(am_hasAccess()) am_unlock(); });
  am_initLicense();
}

function init() {
  initCache();
  state.favorites = favLoad();
  state.favCats = favCatsLoad();
  initLicense();   /* 3-day trial gate + key activation */
  var sm = lsGet("amsfx_sort", "order"); state.sortMode = (sm === "favfirst") ? "favfirst" : "order";
  updateSortButtons();
  if (elSortOrder) elSortOrder.addEventListener("click", function () { setSortMode("order"); });
  if (elSortFav) elSortFav.addEventListener("click", function () { setSortMode("favfirst"); });

  var sz = parseInt(lsGet("amsfx_size", "38"), 10); if (isNaN(sz)) sz = 38;
  elSizeSlider.value = sz; applySize(sz);

  var zm = parseInt(lsGet("amsfx_zoom", "31"), 10); if (isNaN(zm)) zm = 31;
  elZoomSlider.value = zm; applyZoom(zm); settleZoom(zm);
  setFooterPlayIcon(false);

  var sp = parseInt(lsGet("amsfx_split", ""), 10);
  if (!isNaN(sp) && sp >= 118) document.documentElement.style.setProperty("--split-left", sp + "px");

  var fIn = parseInt(lsGet("amsfx_fadein", "0"), 10); if (isNaN(fIn)) fIn = 0;
  var fOut = parseInt(lsGet("amsfx_fadeout", "0"), 10); if (isNaN(fOut)) fOut = 0;
  if (fIn < 0) fIn = 0; if (fIn > 50) fIn = 50;
  if (fOut < 0) fOut = 0; if (fOut > 50) fOut = 50;
  elFadeInSlider.value = fIn; elFadeOutSlider.value = fOut;
  state.fadeIn = fIn / 10; state.fadeOut = fOut / 10;
  syncFadeLabels();

  elAddLib.addEventListener("click", chooseFolder);
  elEmptyAdd.addEventListener("click", chooseFolder);
  if (elLibBtn) elLibBtn.addEventListener("click", function () {
    if (!state.packs.length) { chooseFolder(); return; }
    elSearch.value = ""; elSearchBox.classList.remove("has-text"); runSearch("");
  });
  elSearch.addEventListener("input", onSearchInput);
  elSearchClear.addEventListener("click", function () {
    elSearch.value = ""; elSearchBox.classList.remove("has-text"); runSearch(""); elSearch.focus();
  });
  elSizeSlider.addEventListener("input", function () {
    sizeLive(parseInt(elSizeSlider.value, 10) || 38);
    vgRelayoutSoon();
  });
  elSizeSlider.addEventListener("change", function () {
    var v = parseInt(elSizeSlider.value, 10) || 38;
    lsSet("amsfx_size", String(v));
    applySize(v); vgRelayout(); redrawVisibleSoon();
  });
  elZoomSlider.addEventListener("input", function () {
    elBody.classList.add("zooming");
    zoomLive(parseInt(elZoomSlider.value, 10) || 31);
    if (activeVG) vgRender(false);
  });
  elZoomSlider.addEventListener("change", function () {
    var v = parseInt(elZoomSlider.value, 10) || 31;
    lsSet("amsfx_zoom", String(v));
    applyZoom(v); settleZoom(v); vgRelayoutSoon(); redrawVisibleSoon();
    setTimeout(function () { elBody.classList.remove("zooming"); }, 120);
  });
  elPlayPauseBtn.addEventListener("click", footerPlayPause);
  elReplayBtn.addEventListener("click", replayPreview);
  elFadeBtn.addEventListener("click", function (ev) {
    ev.stopPropagation();
    var open = !elFadePop.classList.contains("show");
    elFadePop.classList.toggle("show", open);
    elFadeBtn.classList.toggle("on", open);
  });
  document.addEventListener("click", function (ev) {
    if (!elFadePop.classList.contains("show")) return;
    if (elFadePop.contains(ev.target) || elFadeBtn.contains(ev.target)) return;
    elFadePop.classList.remove("show"); elFadeBtn.classList.remove("on");
  });
  elFadeInSlider.addEventListener("input", function () {
    var raw = parseInt(elFadeInSlider.value, 10) || 0;
    state.fadeIn = raw / 10; lsSet("amsfx_fadein", String(raw)); syncFadeLabels();
  });
  elFadeOutSlider.addEventListener("input", function () {
    var raw = parseInt(elFadeOutSlider.value, 10) || 0;
    state.fadeOut = raw / 10; lsSet("amsfx_fadeout", String(raw)); syncFadeLabels();
  });
  elCancelBtn.addEventListener("click", clearSelection);
  if (elAddBtn) elAddBtn.addEventListener("click", doAdd);
  if (elDivider) {
    elDivider.addEventListener("pointerdown", dividerDown);
    window.addEventListener("pointermove", dividerMove);
    window.addEventListener("pointerup", dividerUp);
  }

  /* ---- Effect tab wiring ---- */
  if (elTabLibrary) elTabLibrary.addEventListener("click", function () { switchTab("library"); });
  if (elTabEffect) elTabEffect.addEventListener("click", function () { switchTab("effect"); });
  if (elFxLoadBtn) elFxLoadBtn.addEventListener("click", fxLoad);
  if (elFxPreviewBtn) elFxPreviewBtn.addEventListener("click", fxTogglePreview);
  if (elFxReplayBtn) elFxReplayBtn.addEventListener("click", function () { fxPrev.offset = 0; fxStartPreview(); });
  if (elFxApplyBtn) elFxApplyBtn.addEventListener("click", fxApply);
  if (elFxHelpBtn) elFxHelpBtn.addEventListener("click", fxHelpToggle);
  if (elFxHelpClose) elFxHelpClose.addEventListener("click", fxHelpClose);
  if (elFxWaveWrap) {
    elFxWaveWrap.addEventListener("pointerdown", function (e) {
      fxScrubStart(e);
      if (elFxWaveWrap.setPointerCapture && e.pointerId != null) { try { elFxWaveWrap.setPointerCapture(e.pointerId); } catch (_) {} }
      if (e.preventDefault) e.preventDefault();
    });
    elFxWaveWrap.addEventListener("pointermove", fxScrubMove);
    window.addEventListener("pointerup", fxScrubEnd);
  }

  if (elFxSpeedOn) elFxSpeedOn.addEventListener("change", function () {
    fx.speedOn = !!elFxSpeedOn.checked; fxStopPreview(); fxUpdateLabels();
  });
  if (elFxSpeed) elFxSpeed.addEventListener("input", function () {
    fx.speedS = parseInt(elFxSpeed.value, 10) || 0; fxStopPreview(); fxUpdateLabels();
  });
  if (elFxKeepPitch) elFxKeepPitch.addEventListener("change", function () {
    fx.keepPitch = !!elFxKeepPitch.checked; fxStopPreview();
  });
  if (elFxRepeat) elFxRepeat.addEventListener("input", function () {
    fx.repeatN = parseInt(elFxRepeat.value, 10) || 1; fxStopPreview(); fxUpdateLabels();
  });
  if (elFxRepeatOn) elFxRepeatOn.addEventListener("change", function () {
    fx.repeatOn = !!elFxRepeatOn.checked; fxStopPreview(); fxUpdateLabels();
  });
  if (elFxMuting) elFxMuting.addEventListener("input", function () {
    fx.mutingS = parseInt(elFxMuting.value, 10) || 0; fxStopPreview(); fxUpdateLabels();
  });
  if (elFxMutingOn) elFxMutingOn.addEventListener("change", function () {
    fx.mutingOn = !!elFxMutingOn.checked; fxStopPreview(); fxUpdateLabels();
  });
  if (elFxAddBtn) elFxAddBtn.addEventListener("click", function (e) { e.stopPropagation(); fxAddToggle(); });
  document.addEventListener("click", function (e) {
    if (!elFxAddMenu || !elFxAddMenu.classList.contains("open")) return;
    if (elFxAddMenu.contains(e.target) || (elFxAddBtn && elFxAddBtn.contains(e.target))) return;
    fxAddClose();
  });
  if (elFxScale) {
    elFxScale.addEventListener("input", function () { fxApplyScale(parseInt(elFxScale.value, 10) || 40); });
    fxApplyScale(parseInt(elFxScale.value, 10) || 40);
  }
  fxUpdateLabels();
  fxSetPlayIcon(false);

  window.addEventListener("resize", function () {
    vgRelayoutSoon();
    redrawVisibleSoon();
    if (fxActive && fx.peaks) fxDraw();
  });

  /* virtualized list: recompute the visible window as the user scrolls / resizes */
  elPaneRight.addEventListener("scroll", vgScroll, { passive: true });
  if (typeof ResizeObserver === "function") {
    try { new ResizeObserver(function () { vgRelayoutSoon(); }).observe(elPaneRight); } catch (e) {}
  }

  if (!fs) {
    if (elEmptySub) elEmptySub.innerHTML =
      "File access is off. Enable <b>Node.js</b> (PlayerDebugMode) and reload the panel.";
    showEmpty();
    return;
  }

  var roots = [];
  try { roots = JSON.parse(lsGet("amsfx_roots", "[]")); } catch (e) { roots = []; }
  if (Object.prototype.toString.call(roots) !== "[object Array]") roots = [];
  if (!roots.length) { var old = lsGet("amsfx_root", ""); if (old) roots = [old]; }   /* migrate old single library */
  var valid = [];
  for (var ri = 0; ri < roots.length; ri++) { try { if (fs.existsSync && fs.existsSync(roots[ri])) valid.push(roots[ri]); } catch (e) {} }

  if (valid.length) {
    showLoading("Scanning library&hellip;");
    setTimeout(function () {
      loadPacks(valid); savePackPaths(); setLibName(); hideLoading();
      if (!state.packs.length) { showEmpty(); return; }
      elEmpty.classList.remove("show"); elSplit.style.display = "flex";
      elResults.style.display = "none"; elFolderView.style.display = "";
      buildTree();
    }, 40);
  } else showEmpty();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
else init();

})();
